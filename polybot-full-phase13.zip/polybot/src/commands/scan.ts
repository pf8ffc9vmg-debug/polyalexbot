import { loadEnv } from "../config/env.js";
import { createGammaClient } from "../lib/gammaClient.js";
import { ClobClient } from "../lib/clobClient.js";
import { MarketScanner } from "../lib/marketScanner.js";

/**
 * npm run scan
 *
 * Демонстрация Phase 4 (MarketScanner) + Phase 5 (weather classifier) +
 * часть Phase 6 (свежий orderbook per token). Полностью read-only, без
 * авторизации не требует ничего из .env.
 *
 * ВАЖНО: это НЕ observe mode из раздела 24 ТЗ — там нужен ещё
 * EntrySignalEngine (score, expected profit, recommended quantity), который
 * будет отдельной фазой. Здесь только "что бот вообще видит на рынке".
 */

async function main() {
  const env = loadEnv();
  const gamma = createGammaClient(env);
  const clob = new ClobClient(env.CLOB_API_URL, env.CLOB_CHAIN_ID);
  const scanner = new MarketScanner(gamma, clob);

  console.log("Сканирую активные рынки Gamma и классифицирую weather markets...\n");

  const results = await scanner.scanActiveWeatherMarkets({ maxMarketsToScan: 300 });

  const tradable = results.filter((r) => r.classification.tradableByCurrentStrategy);
  const untradableWeather = results.filter((r) => !r.classification.tradableByCurrentStrategy);

  console.log(`Найдено weather markets: ${results.length}`);
  console.log(`  из них temperature (торгуемо текущей стратегией): ${tradable.length}`);
  console.log(`  из них другие типы погоды (детектированы, НЕ торгуются): ${untradableWeather.length}\n`);

  console.log("=== Temperature markets ===");
  for (const m of tradable) {
    const ttr = m.timeToResolutionMs !== null ? `${(m.timeToResolutionMs / 3_600_000).toFixed(1)}h` : "?";
    console.log(
      `- [${m.classification.kind}] ${m.question}\n` +
        `    city=${m.classification.city ?? "?"} time_to_resolution=${ttr} liquidity=${m.liquidityNum ?? "?"}\n` +
        `    YES bid/ask=${fmt(m.yes?.bestBid)}/${fmt(m.yes?.bestAsk)} mid=${fmt(m.yes?.midpoint)}  ` +
        `NO bid/ask=${fmt(m.no?.bestBid)}/${fmt(m.no?.bestAsk)} mid=${fmt(m.no?.midpoint)}`
    );
  }

  if (untradableWeather.length > 0) {
    console.log("\n=== Другие weather markets (детектированы, не торгуются в v1) ===");
    for (const m of untradableWeather) {
      console.log(`- [${m.classification.kind}] ${m.question}`);
    }
  }

  console.log("\n=== Ни один ордер не был создан. Это read-only сканирование. ===");
}

function fmt(v: number | null | undefined): string {
  return v === null || v === undefined ? "—" : v.toFixed(3);
}

main().catch((err) => {
  console.error("Ошибка сканирования:", err);
  process.exit(1);
});
