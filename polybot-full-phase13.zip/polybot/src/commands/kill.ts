import { loadEnv } from "../config/env.js";
import { TradingControlStore } from "../lib/tradingControlStore.js";
import { PaperStateStore } from "../lib/paperStateStore.js";

/**
 * npm run kill
 *
 * Раздел 32 ТЗ: emergency kill switch.
 *
 * Делает:
 *  - stop strategy / disable new orders: пишет персистентный флаг
 *    (TRADING_CONTROL_FILE), который проверяется ПЕРЕД открытием любой
 *    новой позиции в `npm run paper` (и будет проверяться в будущем
 *    live executor) — независимо от текущего значения ENABLE_TRADING в .env.
 *  - сохранить state: state уже персистентен (PaperStateStore, Phase 9) —
 *    kill switch ничего не удаляет, только показывает текущее состояние.
 *
 * ЧЕСТНОЕ ОГРАНИЧЕНИЕ: "cancel open orders" в буквальном смысле раздела 32
 * (отмена реальных ордеров на бирже) пока НЕ применимо — реальное исполнение
 * ордеров (Phase 13) ещё не реализовано, значит и отменять на бирже нечего.
 * Когда Phase 13 появится, её execution-модуль ОБЯЗАН проверять этот же
 * TradingControlStore перед каждой отправкой ордера — это заложено
 * архитектурно уже сейчас, а не как отложенная задача.
 *
 * Открытые PAPER-позиции этой командой НЕ закрываются автоматически —
 * kill switch останавливает НОВЫЙ риск, а не принудительно фиксирует
 * текущий (это осознанное решение: паническая ликвидация по факту
 * добавляет риск, а не убирает его). Текущие открытые позиции просто
 * показываются, решение о них — за вами.
 */

async function main() {
  const env = loadEnv();

  const controlStore = new TradingControlStore(env.TRADING_CONTROL_FILE);
  const reason = process.argv.slice(2).join(" ") || "manual kill switch";
  await controlStore.disable(reason);

  console.log("=== KILL SWITCH АКТИВИРОВАН ===");
  console.log(`Причина: ${reason}`);
  console.log(`Флаг записан в: ${env.TRADING_CONTROL_FILE}`);
  console.log("Все последующие запуски `npm run paper` (и будущий live) откажутся открывать новые позиции.\n");

  const paperStore = new PaperStateStore(env.PAPER_STATE_FILE);
  const paperState = await paperStore.load(env.PAPER_STARTING_BALANCE_USD);

  if (paperState.openPositions.length > 0) {
    console.log(`⚠️  Открытых PAPER-позиций: ${paperState.openPositions.length} (НЕ закрыты автоматически):`);
    for (const p of paperState.openPositions) {
      const remaining = p.filledQty - p.exitedQty;
      console.log(`  ${p.outcome} ${p.question} — qty=${remaining.toFixed(1)} avgEntry=${p.avgEntryPrice.toFixed(3)}`);
    }
    console.log("\nОни продолжат отслеживаться (exit-логика в paper trading не блокируется kill switch —");
    console.log("останавливаются только НОВЫЕ входы). Чтобы снова разрешить торговлю: npm run resume");
  } else {
    console.log("Открытых позиций нет.");
  }
}

main().catch((err) => {
  console.error("Ошибка kill switch:", err);
  process.exit(1);
});
