import { loadEnv } from "../config/env.js";
import { createGammaClient } from "../lib/gammaClient.js";
import { ClobClient } from "../lib/clobClient.js";
import { DataApiClient, type DataApiPosition } from "../lib/dataApiClient.js";
import { MarketScanner } from "../lib/marketScanner.js";
import { EntrySignalEngine } from "../lib/entrySignalEngine.js";
import { PositionSizer } from "../lib/positionSizer.js";
import { accountFromPrivateKey, signClobAuthL1 } from "../lib/clobAuth.js";
import type { EntrySignal } from "../types/signal.js";

/**
 * npm run observe
 *
 * Phase 12, раздел 24 ТЗ. Требует BOT_MODE=observe (симметрично paper/live —
 * защита от путаницы режимов).
 *
 * В отличие от `npm run signals` (Phase 7-8 превью), эта команда пытается
 * использовать РЕАЛЬНЫЙ баланс и РЕАЛЬНЫЕ открытые позиции аккаунта (через
 * те же read-only вызовы, что и `npm run account`, Phase 3) — если заданы
 * credentials. Без них честно откатывается на ASSUMED_CAPITAL_USD и
 * предупреждает, что duplicate-position проверка недоступна без реального
 * адреса.
 *
 * Показывает ровно то, что требует раздел 24 ТЗ: market, token, side,
 * best bid, best ask, spread, liquidity, score, expected profit,
 * recommended quantity, reason.
 *
 * НИКОГДА не создаёт и не отменяет ордера — этот файл физически не
 * импортирует ничего, что умеет POST /order.
 */

async function main() {
  const env = loadEnv();

  if (env.BOT_MODE !== "observe") {
    console.log(
      `BOT_MODE=${env.BOT_MODE}, но команда \`observe\` требует BOT_MODE=observe в .env.\n` +
        "Установите BOT_MODE=observe и запустите снова."
    );
    return;
  }

  const gamma = createGammaClient(env);
  const clob = new ClobClient(env.CLOB_API_URL, env.CLOB_CHAIN_ID);
  const dataApi = new DataApiClient(env.DATA_API_URL);
  const scanner = new MarketScanner(gamma, clob);

  const signalEngine = new EntrySignalEngine({
    entryMin: env.ENTRY_MIN,
    entryMax: env.ENTRY_MAX,
    exitTarget: env.EXIT_TARGET,
    minNetProfitPct: env.MIN_NET_PROFIT_PCT,
    feeRateBps: env.FEE_RATE_BPS,
    slippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
    minLiquidityUsd: env.MIN_LIQUIDITY_USD,
    minTimeToResolutionMs: env.MIN_TIME_TO_RESOLUTION_MS,
    maxTimeToResolutionMs: env.MAX_TIME_TO_RESOLUTION_MS,
    orderbookMaxAgeMs: env.ORDERBOOK_MAX_AGE_MS,
  });

  const sizer = new PositionSizer({
    model: env.POSITION_SIZING_MODEL,
    fixedPositionUsd: env.FIXED_POSITION_USD,
    positionPctCapital: env.POSITION_PCT_CAPITAL,
    liquiditySizingFactor: env.LIQUIDITY_SIZING_FACTOR,
    spreadSizingReference: env.SPREAD_SIZING_REFERENCE,
    edgeSizingReferencePct: env.EDGE_SIZING_REFERENCE_PCT,
    hybridLiquidityWeight: env.HYBRID_LIQUIDITY_WEIGHT,
    maxPositionUsd: env.MAX_POSITION_USD,
    maxLiquidityUsage: env.MAX_LIQUIDITY_USAGE,
    maxTotalExposureUsd: env.MAX_TOTAL_EXPOSURE_USD,
    maxMarketExposureUsd: env.MAX_MARKET_EXPOSURE_USD,
    allowPositionScaling: env.ALLOW_POSITION_SCALING,
  });

  // --- Попытка получить реальный баланс/позиции (как в npm run account) ---
  let availableCapitalUsd = env.ASSUMED_CAPITAL_USD;
  let realPositions: DataApiPosition[] = [];
  let usingRealData = false;

  if (env.POLYMARKET_PRIVATE_KEY) {
    try {
      const account = accountFromPrivateKey(env.POLYMARKET_PRIVATE_KEY);
      const funderAddress = env.POLYMARKET_FUNDER_ADDRESS || account.address;

      realPositions = await dataApi.getPositions(funderAddress);

      if (env.POLYMARKET_API_KEY && env.POLYMARKET_API_SECRET && env.POLYMARKET_API_PASSPHRASE) {
        const creds = {
          apiKey: env.POLYMARKET_API_KEY,
          secret: env.POLYMARKET_API_SECRET,
          passphrase: env.POLYMARKET_API_PASSPHRASE,
        };
        const balance = await clob.getBalanceAllowance(funderAddress, creds, "COLLATERAL");
        availableCapitalUsd = Number(balance.balance);
        usingRealData = true;
      } else {
        // L1-подпись сработает, но без сохранённых L2 credentials не будем
        // создавать новые прямо здесь (это делает `npm run account` явно) —
        // observe mode честно откатывается на ASSUMED_CAPITAL_USD.
        console.log(
          "Есть POLYMARKET_PRIVATE_KEY, но нет L2 credentials в .env — баланс не запрошен.\n" +
            "Запустите `npm run account` один раз, чтобы получить и сохранить L2 credentials."
        );
      }
    } catch (err) {
      console.log(`Не удалось получить реальные данные аккаунта: ${(err as Error).message}`);
    }
  }

  console.log(
    usingRealData
      ? `Используется РЕАЛЬНЫЙ баланс: $${availableCapitalUsd.toFixed(2)}, реальных позиций: ${realPositions.length}`
      : `⚠️  Реальные credentials не заданы (или неполные) — используется ASSUMED_CAPITAL_USD=$${availableCapitalUsd}, ` +
        `duplicate-position проверка недоступна (realPositions=0).`
  );
  console.log();

  const markets = await scanner.scanActiveWeatherMarkets({ maxMarketsToScan: 300 });
  const signals: EntrySignal[] = markets.flatMap((m) => signalEngine.evaluateMarket(m));

  let runningTotalExposure = sumRealExposure(realPositions);
  const marketExposureByCondition = groupExposureByConditionId(realPositions);

  console.log("=== market | token | side | bid | ask | spread | liquidity | score | exp.profit | rec.qty | reason ===");
  for (const s of signals.sort((a, b) => (b.signalScore ?? -1) - (a.signalScore ?? -1))) {
    const hasExisting = realPositions.some((p) => p.asset === s.tokenId && (p.size ?? 0) > 0);

    let recommendedQty = 0;
    if (s.decision === "BUY_CANDIDATE") {
      const sizing = sizer.size(s, {
        availableCapitalUsd,
        currentTotalExposureUsd: runningTotalExposure,
        currentMarketExposureUsd: marketExposureByCondition.get(s.conditionId) ?? 0,
        hasExistingOpenPosition: hasExisting,
      });
      recommendedQty = sizing.finalShares ?? 0;
      if (!sizing.blocked) runningTotalExposure += sizing.finalNotionalUsd;
    }

    const reason =
      s.decision === "BUY_CANDIDATE"
        ? hasExisting
          ? "BUY (но уже есть открытая позиция — см. ALLOW_POSITION_SCALING)"
          : "BUY"
        : `NO_TRADE: ${s.reasons.join(", ")}`;

    const quote = marketOf(markets, s);
    const sideQuote = s.outcome === "YES" ? quote?.yes : quote?.no;

    console.log(
      `${truncate(s.question, 50)} | ${s.outcome} | bid=${fmt(sideQuote?.bestBid)} | ask=${fmt(sideQuote?.bestAsk)} | ` +
        `spread=${s.spread?.toFixed(3) ?? "—"} | liq=$${s.availableLiquidity?.toFixed(0) ?? "—"} | ` +
        `score=${s.signalScore?.toFixed(0) ?? "—"} | expProfit=${s.expectedNetProfitPerShare?.toFixed(4) ?? "—"} | ` +
        `recQty=${recommendedQty.toFixed(1)} | ${reason}`
    );
  }

  console.log(`\nВсего сигналов: ${signals.length}. BUY-кандидатов: ${signals.filter((s) => s.decision === "BUY_CANDIDATE").length}.`);
  console.log("=== Ни один ордер не был создан (observe mode). ===");
}

function fmt(v: number | null | undefined): string {
  return v === null || v === undefined ? "—" : v.toFixed(3);
}

function truncate(s: string, n: number): string {
  return s.length > n ? s.slice(0, n - 1) + "…" : s.padEnd(n);
}

function marketOf(markets: Awaited<ReturnType<MarketScanner["scanActiveWeatherMarkets"]>>, s: EntrySignal) {
  return markets.find((m) => m.marketId === s.marketId);
}

function sumRealExposure(positions: DataApiPosition[]): number {
  return positions.reduce((sum, p) => sum + (p.size ?? 0) * (p.curPrice ?? p.avgPrice ?? 0), 0);
}

function groupExposureByConditionId(positions: DataApiPosition[]): Map<string, number> {
  const map = new Map<string, number>();
  for (const p of positions) {
    if (!p.conditionId) continue;
    const notional = (p.size ?? 0) * (p.curPrice ?? p.avgPrice ?? 0);
    map.set(p.conditionId, (map.get(p.conditionId) ?? 0) + notional);
  }
  return map;
}

main().catch((err) => {
  console.error("Ошибка observe mode:", err);
  process.exit(1);
});
