import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { loadEnv } from "../config/env.js";
import { getPool, closePool } from "../db/client.js";
import { PostgresSnapshotStore } from "../lib/postgresSnapshotStore.js";
import { BacktestRunner } from "../lib/backtestRunner.js";
import { runGridSearch } from "../lib/backtestGrid.js";
import type { MarketSnapshot } from "../types/market.js";
import type { BacktestResult } from "../types/backtest.js";

/**
 * npm run backtest
 *
 * Phase 11. Загружает все накопленные MarketSnapshot (из PostgreSQL, если
 * DATABASE_URL задан, иначе из всех *.jsonl файлов в SNAPSHOTS_DIR) и
 * прогоняет через BacktestRunner — тот же пайплайн, что paper trading.
 *
 * BACKTEST_GRID=true включает grid search по ENTRY_MIN × EXIT_TARGET
 * (раздел 36 ТЗ) вместо одного прогона с текущими .env параметрами.
 *
 * Ничего не покупает и не продаёт по-настоящему — работает только с уже
 * собранными историческими данными.
 */

async function loadSnapshotsFromJsonlDir(dir: string): Promise<MarketSnapshot[]> {
  let files: string[];
  try {
    files = (await readdir(dir)).filter((f) => f.endsWith(".jsonl"));
  } catch {
    return [];
  }

  const all: MarketSnapshot[] = [];
  for (const f of files) {
    const content = await readFile(path.join(dir, f), "utf-8");
    for (const line of content.split("\n")) {
      if (line.trim().length === 0) continue;
      all.push(JSON.parse(line) as MarketSnapshot);
    }
  }
  return all;
}

async function main() {
  const env = loadEnv();

  let snapshots: MarketSnapshot[];
  let pool = undefined as ReturnType<typeof getPool> | undefined;

  if (env.DATABASE_URL) {
    pool = getPool(env.DATABASE_URL);
    snapshots = await new PostgresSnapshotStore(pool).loadAll();
  } else {
    snapshots = await loadSnapshotsFromJsonlDir(env.SNAPSHOTS_DIR);
  }

  console.log(`Загружено snapshot'ов: ${snapshots.length}`);
  if (snapshots.length === 0) {
    console.log(
      "Нет данных для backtest. Сначала запустите `npm run collect` (Phase 6/10) — backtest " +
        "работает только на реально собранных исторических snapshot'ах, не на выдуманных данных."
    );
    if (pool) await closePool();
    return;
  }

  const baseConfig = {
    signalEngine: {
      entryMin: env.ENTRY_MIN,
      entryMax: env.ENTRY_MAX,
      exitTarget: env.EXIT_TARGET,
      minNetProfitPct: env.MIN_NET_PROFIT_PCT,
      feeRateBps: env.FEE_RATE_BPS,
      slippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
      minLiquidityUsd: env.MIN_LIQUIDITY_USD,
      minTimeToResolutionMs: env.MIN_TIME_TO_RESOLUTION_MS,
      maxTimeToResolutionMs: env.MAX_TIME_TO_RESOLUTION_MS,
      orderbookMaxAgeMs: env.ORDERBOOK_MAX_AGE_MS,
    },
    positionSizer: {
      model: env.POSITION_SIZING_MODEL,
      fixedPositionUsd: env.FIXED_POSITION_USD,
      positionPctCapital: env.POSITION_PCT_CAPITAL,
      liquiditySizingFactor: env.LIQUIDITY_SIZING_FACTOR,
      spreadSizingReference: env.SPREAD_SIZING_REFERENCE,
      edgeSizingReferencePct: env.EDGE_SIZING_REFERENCE_PCT,
      hybridLiquidityWeight: env.HYBRID_LIQUIDITY_WEIGHT,
      maxPositionUsd: env.MAX_POSITION_USD,
      maxLiquidityUsage: env.MAX_LIQUIDITY_USAGE,
      maxTotalExposureUsd: env.MAX_TOTAL_EXPOSURE_USD,
      maxMarketExposureUsd: env.MAX_MARKET_EXPOSURE_USD,
      allowPositionScaling: env.ALLOW_POSITION_SCALING,
    },
    paperEngine: {
      feeRateBps: env.FEE_RATE_BPS,
      slippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
      exitTarget: env.EXIT_TARGET,
      allowPositionScaling: env.ALLOW_POSITION_SCALING,
    },
    startingBalanceUsd: env.PAPER_STARTING_BALANCE_USD,
    cycleBucketMs: env.BACKTEST_CYCLE_BUCKET_MS,
    minDistinctDaysForConfidence: env.BACKTEST_MIN_DISTINCT_DAYS,
  };

  if (env.BACKTEST_GRID) {
    const entryMinValues = env.BACKTEST_ENTRY_MIN_RANGE.split(",").map(Number);
    const exitTargetValues = env.BACKTEST_EXIT_TARGET_RANGE.split(",").map(Number);
    console.log(
      `Grid search: ENTRY_MIN ∈ [${entryMinValues.join(", ")}] × EXIT_TARGET ∈ [${exitTargetValues.join(", ")}]\n`
    );

    const results = await runGridSearch(snapshots, { entryMinValues, exitTargetValues, base: baseConfig }, pool);

    console.log("=== Топ-10 комбинаций по net PnL ===");
    for (const r of results.slice(0, 10)) {
      printResultLine(r);
    }

    if (results[0]?.overfitWarning) {
      console.log(`\n⚠️  ${results[0].overfitWarning}`);
    }
  } else {
    const runner = new BacktestRunner(baseConfig);
    const result = await runner.run(snapshots);

    console.log("=== Backtest (текущие параметры из .env) ===");
    printResultLine(result);
    console.log(`\nМаксимальная просадка: $${result.maxDrawdownUsd.toFixed(2)} (${(result.maxDrawdownPct * 100).toFixed(1)}%)`);
    console.log(`Итоговый equity: $${result.finalEquityUsd.toFixed(2)}`);

    if (result.overfitWarning) {
      console.log(`\n⚠️  ${result.overfitWarning}`);
    }
  }

  if (pool) await closePool();
}

function printResultLine(r: BacktestResult) {
  console.log(
    `  ENTRY_MIN=${r.params.entryMin} EXIT=${r.params.exitTarget}  ` +
      `trades=${r.tradesCount} winRate=${r.winRate !== null ? (r.winRate * 100).toFixed(0) + "%" : "—"}  ` +
      `netPnL=$${r.netPnlUsd.toFixed(2)}  maxDD=${(r.maxDrawdownPct * 100).toFixed(1)}%  days=${r.distinctDaysCovered}`
  );
}

main().catch((err) => {
  console.error("Ошибка backtest:", err);
  process.exit(1);
});
