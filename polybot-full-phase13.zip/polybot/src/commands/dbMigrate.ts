import { readFile } from "node:fs/promises";
import { loadEnv } from "../config/env.js";
import { getPool, closePool } from "../db/client.js";

/**
 * npm run db:migrate
 *
 * Phase 10. Применяет db/schema.sql (все 13 таблиц из раздела 27 ТЗ).
 * Идемпотентно — CREATE TABLE IF NOT EXISTS, безопасно запускать повторно.
 */

async function main() {
  const env = loadEnv();
  if (!env.DATABASE_URL) {
    console.log(
      "DATABASE_URL не задан в .env — миграцию применять некуда.\n" +
        "Пример: DATABASE_URL=postgres://user:pass@localhost:5432/polybot"
    );
    return;
  }

  const pool = getPool(env.DATABASE_URL);
  const sql = await readFile(new URL("../../db/schema.sql", import.meta.url), "utf-8");

  console.log("Применяю db/schema.sql...");
  await pool.query(sql);
  console.log("Готово. Все таблицы из раздела 27 ТЗ созданы (или уже существовали).");

  const { rows } = await pool.query<{ table_name: string }>(
    `SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name`
  );
  console.log("Таблицы в схеме public:");
  for (const r of rows) console.log(`  - ${r.table_name}`);

  await closePool();
}

main().catch((err) => {
  console.error("Ошибка миграции:", err);
  process.exit(1);
});
