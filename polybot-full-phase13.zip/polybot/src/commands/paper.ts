import { loadEnv } from "../config/env.js";
import { createGammaClient } from "../lib/gammaClient.js";
import { ClobClient } from "../lib/clobClient.js";
import { MarketScanner } from "../lib/marketScanner.js";
import { EntrySignalEngine } from "../lib/entrySignalEngine.js";
import { PositionSizer } from "../lib/positionSizer.js";
import { PaperTradingEngine } from "../lib/paperTradingEngine.js";
import { PaperStateStore } from "../lib/paperStateStore.js";
import { RiskManager } from "../lib/riskManager.js";
import { TradingControlStore } from "../lib/tradingControlStore.js";

/**
 * npm run paper
 *
 * Phase 9. Единственная команда в проекте, которая ведёт state между
 * запусками (позиции, PnL) — потому что это реально нужно для paper trading:
 * иначе нельзя проверить, что открытая вчера позиция сегодня закрылась по
 * 0.99.
 *
 * BOT_MODE должен быть 'paper', иначе команда откажется работать — так же,
 * как live требует явного BOT_MODE=live (симметрично, чтобы не перепутать
 * режимы по ошибке).
 *
 * Реальные ордера НЕ отправляются никогда, независимо от значений в .env —
 * этот файл физически не импортирует ничего, что умеет POST /order.
 */

async function main() {
  const env = loadEnv();

  if (env.BOT_MODE !== "paper") {
    console.log(
      `BOT_MODE=${env.BOT_MODE}, но команда \`paper\` требует BOT_MODE=paper в .env.\n` +
        "Это защита от путаницы режимов — установите BOT_MODE=paper и запустите снова."
    );
    return;
  }

  const gamma = createGammaClient(env);
  const clob = new ClobClient(env.CLOB_API_URL, env.CLOB_CHAIN_ID);
  const scanner = new MarketScanner(gamma, clob);

  const signalEngine = new EntrySignalEngine({
    entryMin: env.ENTRY_MIN,
    entryMax: env.ENTRY_MAX,
    exitTarget: env.EXIT_TARGET,
    minNetProfitPct: env.MIN_NET_PROFIT_PCT,
    feeRateBps: env.FEE_RATE_BPS,
    slippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
    minLiquidityUsd: env.MIN_LIQUIDITY_USD,
    minTimeToResolutionMs: env.MIN_TIME_TO_RESOLUTION_MS,
    maxTimeToResolutionMs: env.MAX_TIME_TO_RESOLUTION_MS,
    orderbookMaxAgeMs: env.ORDERBOOK_MAX_AGE_MS,
  });

  const sizer = new PositionSizer({
    model: env.POSITION_SIZING_MODEL,
    fixedPositionUsd: env.FIXED_POSITION_USD,
    positionPctCapital: env.POSITION_PCT_CAPITAL,
    liquiditySizingFactor: env.LIQUIDITY_SIZING_FACTOR,
    spreadSizingReference: env.SPREAD_SIZING_REFERENCE,
    edgeSizingReferencePct: env.EDGE_SIZING_REFERENCE_PCT,
    hybridLiquidityWeight: env.HYBRID_LIQUIDITY_WEIGHT,
    maxPositionUsd: env.MAX_POSITION_USD,
    maxLiquidityUsage: env.MAX_LIQUIDITY_USAGE,
    maxTotalExposureUsd: env.MAX_TOTAL_EXPOSURE_USD,
    maxMarketExposureUsd: env.MAX_MARKET_EXPOSURE_USD,
    allowPositionScaling: env.ALLOW_POSITION_SCALING,
  });

  const paperEngine = new PaperTradingEngine(sizer, {
    feeRateBps: env.FEE_RATE_BPS,
    slippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
    exitTarget: env.EXIT_TARGET,
    allowPositionScaling: env.ALLOW_POSITION_SCALING,
  });

  const riskManager = new RiskManager({
    maxOpenPositions: env.MAX_OPEN_POSITIONS,
    maxDailyLossUsd: env.MAX_DAILY_LOSS_USD,
    maxDrawdownPct: env.MAX_DRAWDOWN_PCT,
    maxTotalExposureUsd: env.MAX_TOTAL_EXPOSURE_USD,
    maxMarketExposureUsd: env.MAX_MARKET_EXPOSURE_USD,
    minLiquidityUsd: env.MIN_LIQUIDITY_USD,
    minNetProfitPct: env.MIN_NET_PROFIT_PCT,
    maxSlippagePct: env.MAX_SLIPPAGE_PCT,
    configuredSlippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
    orderbookMaxAgeMs: env.ORDERBOOK_MAX_AGE_MS,
    minTimeToResolutionMs: env.MIN_TIME_TO_RESOLUTION_MS,
    maxTimeToResolutionMs: env.MAX_TIME_TO_RESOLUTION_MS,
    allowPositionScaling: env.ALLOW_POSITION_SCALING,
  });

  const controlStore = new TradingControlStore(env.TRADING_CONTROL_FILE);

  const stateStore = new PaperStateStore(env.PAPER_STATE_FILE);
  let state = await stateStore.load(env.PAPER_STARTING_BALANCE_USD);
  state.equityPeakUsd = state.equityPeakUsd ?? state.startingBalanceUsd;

  console.log(`=== Paper trading (state: ${env.PAPER_STATE_FILE}) ===`);
  console.log(`Стартовый баланс: $${state.startingBalanceUsd}  Текущий cash: $${state.cashBalanceUsd.toFixed(2)}`);
  console.log(`Открытых позиций: ${state.openPositions.length}  Закрытых сделок: ${state.closedTrades.length}\n`);

  // --- Kill switch (раздел 32 ТЗ): проверяется независимо от ENABLE_TRADING в .env ---
  const controlState = await controlStore.load();
  const tradingEnabled = env.ENABLE_TRADING && controlState.enabled;
  if (!tradingEnabled) {
    console.log(
      `⚠️  ТОРГОВЛЯ ОТКЛЮЧЕНА (ENABLE_TRADING=${env.ENABLE_TRADING}, kill switch enabled=${controlState.enabled}` +
        (controlState.reason ? `, reason="${controlState.reason}"` : "") +
        `). Новые позиции открываться НЕ будут. Существующие продолжат отслеживаться для exit.\n`
    );
  }

  const markets = await scanner.scanActiveWeatherMarkets({ maxMarketsToScan: 300 });
  const allSignals = markets.flatMap((m) => signalEngine.evaluateMarket(m));
  const signalCandidates = allSignals.filter((s) => s.decision === "BUY_CANDIDATE");

  // --- RiskManager (раздел 31 ТЗ): финальный гейт перед тем, как сигнал
  // вообще попадёт в PaperTradingEngine. Считается ДО цикла, на состоянии
  // "как есть сейчас" — exits в этом же цикле могут освободить капитал, но
  // RiskManager сознательно консервативен и не учитывает ещё не случившиеся
  // exits (лучше недооценить доступный капитал, чем пропустить duplicate/
  // exposure проверку).
  const today = new Date().toISOString().slice(0, 10);
  const dailyRealizedPnlUsd = state.closedTrades
    .filter((t) => new Date(t.exitTime).toISOString().slice(0, 10) === today)
    .reduce((sum, t) => sum + t.netProfit, 0);

  const preCycleEquity =
    state.cashBalanceUsd + state.openPositions.reduce((sum, p) => sum + (p.filledQty - p.exitedQty) * p.avgEntryPrice, 0);
  const currentDrawdownPct =
    state.equityPeakUsd! > 0 ? Math.max(0, (state.equityPeakUsd! - preCycleEquity) / state.equityPeakUsd!) : 0;

  const marketExposureByMarket = new Map<string, number>();
  for (const p of state.openPositions) {
    marketExposureByMarket.set(
      p.marketId,
      (marketExposureByMarket.get(p.marketId) ?? 0) + (p.filledQty - p.exitedQty) * p.avgEntryPrice
    );
  }
  const totalExposureUsd = [...marketExposureByMarket.values()].reduce((a, b) => a + b, 0);

  const buyCandidates = [];
  for (const s of signalCandidates) {
    const hasExisting = state.openPositions.some((p) => p.tokenId === s.tokenId);
    const sizing = sizer.size(s, {
      availableCapitalUsd: state.cashBalanceUsd,
      currentTotalExposureUsd: totalExposureUsd,
      currentMarketExposureUsd: marketExposureByMarket.get(s.marketId) ?? 0,
      hasExistingOpenPosition: hasExisting,
    });

    if (sizing.blocked) continue; // уже заблокировано PositionSizer (caps раздела 30) — RiskManager не нужен

    const riskCheck = riskManager.checkBuy(s, sizing.finalNotionalUsd, {
      availableCapitalUsd: state.cashBalanceUsd,
      currentTotalExposureUsd: totalExposureUsd,
      currentMarketExposureUsd: marketExposureByMarket.get(s.marketId) ?? 0,
      openPositionsCount: state.openPositions.length,
      dailyRealizedPnlUsd,
      currentDrawdownPct,
      hasExistingOpenPosition: hasExisting,
      tradingEnabled,
      orderbookBookAgeMs: 0, // orderbook только что получен сканером в этом же цикле — свежий по построению
    });

    if (riskCheck.passed) {
      buyCandidates.push(s);
    } else {
      console.log(`🛑 RISK BLOCK: ${s.outcome} ${s.question.slice(0, 60)} — ${riskCheck.blockedBy.join(", ")}`);
    }
  }

  const { state: newState, summary } = await paperEngine.runCycle(state, markets, buyCandidates);
  state = newState;

  const postCycleEquity = summary.cashBalanceUsd + summary.totalExposureUsd + summary.unrealizedPnlUsd;
  state.equityPeakUsd = Math.max(state.equityPeakUsd ?? env.PAPER_STARTING_BALANCE_USD, postCycleEquity);

  await stateStore.save(state);

  console.log("=== Итог цикла ===");
  console.log(`  Открыто новых позиций: ${summary.entriesOpened}`);
  console.log(`  Пропущено (нет fill/недостаточно средств/партиал): ${summary.entriesSkippedNoFill}`);
  console.log(`  Exit-исполнений: ${summary.exitFillsExecuted}`);
  console.log(`  Полностью закрыто позиций: ${summary.positionsClosed}`);
  console.log(`  Cash balance: $${summary.cashBalanceUsd.toFixed(2)}`);
  console.log(`  Суммарная экспозиция (открытые): $${summary.totalExposureUsd.toFixed(2)}`);
  console.log(`  Realized PnL (все время): $${summary.realizedPnlUsd.toFixed(2)}`);
  console.log(`  Unrealized PnL (открытые): $${summary.unrealizedPnlUsd.toFixed(2)}`);
  console.log(
    `  Total equity: $${(summary.cashBalanceUsd + summary.totalExposureUsd + summary.unrealizedPnlUsd).toFixed(2)}`
  );

  if (state.openPositions.length > 0) {
    console.log("\n=== Открытые позиции ===");
    for (const p of state.openPositions) {
      const remaining = p.filledQty - p.exitedQty;
      console.log(
        `  ${p.outcome} ${p.question} — qty=${remaining.toFixed(1)}/${p.filledQty.toFixed(1)} avgEntry=${p.avgEntryPrice.toFixed(3)}`
      );
    }
  }

  console.log("\n=== Ни один реальный ордер не был создан (paper mode). ===");
}

main().catch((err) => {
  console.error("Ошибка paper trading:", err);
  process.exit(1);
});
