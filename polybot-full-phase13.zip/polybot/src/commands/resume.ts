import { loadEnv } from "../config/env.js";
import { TradingControlStore } from "../lib/tradingControlStore.js";

/**
 * npm run resume
 *
 * Не упомянуто буквально в ТЗ (раздел 32 описывает только выключение), но
 * операционно необходимая парная команда к `npm run kill` — иначе kill switch
 * необратим без ручного удаления файла. Требует явного запуска, ничего не
 * делает автоматически/по таймеру.
 */

async function main() {
  const env = loadEnv();
  const controlStore = new TradingControlStore(env.TRADING_CONTROL_FILE);

  const prev = await controlStore.load();
  await controlStore.enable("manual resume");

  console.log("=== Торговля снова разрешена ===");
  if (!prev.enabled) {
    console.log(`(была выключена: "${prev.reason}", ${new Date(prev.changedAt).toISOString()})`);
  }
}

main().catch((err) => {
  console.error("Ошибка resume:", err);
  process.exit(1);
});
