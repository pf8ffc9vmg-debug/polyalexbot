import { loadEnv, mask } from "../config/env.js";
import { accountFromPrivateKey, signClobAuthL1 } from "../lib/clobAuth.js";
import { ClobClient } from "../lib/clobClient.js";
import { DataApiClient } from "../lib/dataApiClient.js";

/**
 * npm run account
 *
 * Read-only диагностика:
 *   1. Определяет адрес signer'а из приватного ключа (L1).
 *   2. Создаёт/деривирует L2 API credentials (единственный "мутирующий" вызов —
 *      создание пары ключей на стороне Polymarket, это НЕ торговая операция).
 *   3. Читает balance-allowance через CLOB (L2, GET).
 *   4. Читает positions через Data API (публично, по адресу).
 *   5. Читает open orders через CLOB (L2, GET).
 *
 * Ни один вызов в этом файле не отправляет POST /order и не может создать сделку.
 */

async function main() {
  const env = loadEnv();

  console.log("=== Polymarket Account Diagnostic (read-only) ===\n");
  console.log(`BOT_MODE: ${env.BOT_MODE}`);
  console.log(`CLOB_API_URL: ${env.CLOB_API_URL}`);
  console.log(`DATA_API_URL: ${env.DATA_API_URL}\n`);

  if (!env.POLYMARKET_PRIVATE_KEY) {
    console.log(
      "POLYMARKET_PRIVATE_KEY не задан в .env — показываю только структуру команды.\n" +
        "Заполните .env (см. .env.example) и запустите снова, чтобы увидеть реальные данные."
    );
    return;
  }

  const account = accountFromPrivateKey(env.POLYMARKET_PRIVATE_KEY);
  const funderAddress = env.POLYMARKET_FUNDER_ADDRESS || account.address;

  console.log(`Signer address: ${account.address}`);
  console.log(
    `Funder address (адрес со средствами): ${funderAddress}` +
      (env.POLYMARKET_FUNDER_ADDRESS ? "" : "  (не задан отдельно — использую signer address)")
  );
  console.log();

  const clob = new ClobClient(env.CLOB_API_URL, env.CLOB_CHAIN_ID);
  const dataApi = new DataApiClient(env.DATA_API_URL);

  // --- Шаг 1: L2 credentials (создать/деривировать при необходимости) ---
  let creds =
    env.POLYMARKET_API_KEY && env.POLYMARKET_API_SECRET && env.POLYMARKET_API_PASSPHRASE
      ? {
          apiKey: env.POLYMARKET_API_KEY,
          secret: env.POLYMARKET_API_SECRET,
          passphrase: env.POLYMARKET_API_PASSPHRASE,
        }
      : null;

  if (!creds) {
    console.log("L2 credentials не заданы в .env — создаю/деривирую через L1-подпись...");
    try {
      const l1 = await signClobAuthL1(account, env.CLOB_CHAIN_ID, 0);
      creds = await clob.createOrDeriveApiKey(account, l1);
      console.log("Получены L2 credentials (сохраните их в .env, чтобы не пересоздавать каждый раз):");
      console.log(`  POLYMARKET_API_KEY=${creds.apiKey}`);
      console.log(`  POLYMARKET_API_SECRET=${mask(creds.secret)}  (полное значение выведено один раз — see above/API)`);
      console.log(`  POLYMARKET_API_PASSPHRASE=${mask(creds.passphrase)}\n`);
    } catch (err) {
      console.error("Не удалось получить L2 credentials:", (err as Error).message);
      console.error(
        "Возможные причины: неверный приватный ключ, сетевые ограничения, либо ваш IP находится\n" +
          "в регионе, где Polymarket блокирует API (см. https://polymarket.com/api/geoblock)."
      );
      return;
    }
  } else {
    console.log(`L2 API key: ${mask(creds.apiKey)}\n`);
  }

  // --- Шаг 2: баланс/allowance ---
  try {
    const balance = await clob.getBalanceAllowance(funderAddress, creds, "COLLATERAL");
    console.log("=== Баланс (collateral, обычно USDC.e / pUSD) ===");
    console.log(`  balance:   ${balance.balance}`);
    console.log(`  allowance: ${balance.allowance}\n`);
  } catch (err) {
    console.error("Не удалось получить balance-allowance:", (err as Error).message);
  }

  // --- Шаг 3: открытые позиции (Data API, публично) ---
  try {
    const positions = await dataApi.getPositions(funderAddress);
    console.log(`=== Открытые позиции: ${positions.length} ===`);
    for (const p of positions.slice(0, 20)) {
      console.log(`  asset=${p.asset ?? "?"} size=${p.size ?? "?"} avgPrice=${p.avgPrice ?? "?"} curPrice=${p.curPrice ?? "?"}`);
    }
    console.log();
  } catch (err) {
    console.error("Не удалось получить positions:", (err as Error).message);
  }

  // --- Шаг 4: открытые ордера (CLOB L2) ---
  try {
    const openOrders = await clob.getOpenOrders(funderAddress, creds);
    console.log(`=== Открытые ордера: ${openOrders.length} ===`);
    console.log(openOrders.slice(0, 20));
  } catch (err) {
    console.error("Не удалось получить open orders:", (err as Error).message);
  }

  console.log("\n=== Диагностика завершена. Ни один ордер не был создан. ===");
}

main().catch((err) => {
  console.error("Ошибка диагностики:", err);
  process.exit(1);
});
