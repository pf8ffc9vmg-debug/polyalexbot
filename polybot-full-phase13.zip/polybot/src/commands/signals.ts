import { loadEnv } from "../config/env.js";
import { createGammaClient } from "../lib/gammaClient.js";
import { ClobClient } from "../lib/clobClient.js";
import { MarketScanner } from "../lib/marketScanner.js";
import { EntrySignalEngine } from "../lib/entrySignalEngine.js";
import { PositionSizer } from "../lib/positionSizer.js";
import type { EntrySignal } from "../types/signal.js";

/**
 * npm run signals
 *
 * Phase 7 (EntrySignalEngine) + Phase 8 (PositionSizer) превью.
 * Показывает, что бот решил бы купить и в каком объёме — БЕЗ реального
 * исполнения. Read-only.
 *
 * ЭТО ЕЩЁ НЕ observe mode (раздел 24 ТЗ) в полном смысле — там ожидается
 * интеграция с реальным балансом/позициями (Phase 9-12). Здесь sizing
 * считается либо от реального баланса (если заданы credentials в .env),
 * либо от ASSUMED_CAPITAL_USD — это явно помечается в выводе, чтобы не
 * спутать превью с реальными рекомендациями.
 */

async function main() {
  const env = loadEnv();
  const gamma = createGammaClient(env);
  const clob = new ClobClient(env.CLOB_API_URL, env.CLOB_CHAIN_ID);
  const scanner = new MarketScanner(gamma, clob);

  const engine = new EntrySignalEngine({
    entryMin: env.ENTRY_MIN,
    entryMax: env.ENTRY_MAX,
    exitTarget: env.EXIT_TARGET,
    minNetProfitPct: env.MIN_NET_PROFIT_PCT,
    feeRateBps: env.FEE_RATE_BPS,
    slippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
    minLiquidityUsd: env.MIN_LIQUIDITY_USD,
    minTimeToResolutionMs: env.MIN_TIME_TO_RESOLUTION_MS,
    maxTimeToResolutionMs: env.MAX_TIME_TO_RESOLUTION_MS,
    orderbookMaxAgeMs: env.ORDERBOOK_MAX_AGE_MS,
  });

  const sizer = new PositionSizer({
    model: env.POSITION_SIZING_MODEL,
    fixedPositionUsd: env.FIXED_POSITION_USD,
    positionPctCapital: env.POSITION_PCT_CAPITAL,
    liquiditySizingFactor: env.LIQUIDITY_SIZING_FACTOR,
    spreadSizingReference: env.SPREAD_SIZING_REFERENCE,
    edgeSizingReferencePct: env.EDGE_SIZING_REFERENCE_PCT,
    hybridLiquidityWeight: env.HYBRID_LIQUIDITY_WEIGHT,
    maxPositionUsd: env.MAX_POSITION_USD,
    maxLiquidityUsage: env.MAX_LIQUIDITY_USAGE,
    maxTotalExposureUsd: env.MAX_TOTAL_EXPOSURE_USD,
    maxMarketExposureUsd: env.MAX_MARKET_EXPOSURE_USD,
    allowPositionScaling: env.ALLOW_POSITION_SCALING,
  });

  console.log("Параметры (из .env, все конфигурируемы):");
  console.log(
    `  ENTRY [${env.ENTRY_MIN}, ${env.ENTRY_MAX}]  EXIT_TARGET=${env.EXIT_TARGET}  ` +
      `MIN_NET_PROFIT_PCT=${env.MIN_NET_PROFIT_PCT}  MIN_LIQUIDITY_USD=${env.MIN_LIQUIDITY_USD}`
  );
  console.log(
    `  POSITION_SIZING_MODEL=${env.POSITION_SIZING_MODEL}  MAX_POSITION_USD=${env.MAX_POSITION_USD}  ` +
      `MAX_TOTAL_EXPOSURE_USD=${env.MAX_TOTAL_EXPOSURE_USD}  ASSUMED_CAPITAL_USD=${env.ASSUMED_CAPITAL_USD} ` +
      `(превью-капитал, НЕ реальный баланс — реальный баланс не запрашивается в этой команде)`
  );
  console.log();

  const markets = await scanner.scanActiveWeatherMarkets({ maxMarketsToScan: 300 });
  const allSignals: EntrySignal[] = markets.flatMap((m) => engine.evaluateMarket(m));

  const buyCandidates = allSignals
    .filter((s) => s.decision === "BUY_CANDIDATE")
    .sort((a, b) => (b.signalScore ?? 0) - (a.signalScore ?? 0));

  const noTrade = allSignals.filter((s) => s.decision === "NO_TRADE");

  // Превью sizing: считаем "с нуля" (без учёта уже открытых позиций внутри
  // этого запуска) — реальный учёт текущей экспозиции появится в Phase 9
  // (paper trading), где позиции реально отслеживаются между вызовами.
  let runningTotalExposure = 0;
  const marketExposure = new Map<string, number>();

  console.log(`=== BUY-кандидаты: ${buyCandidates.length} (отранжировано по signalScore) ===`);
  for (const s of buyCandidates) {
    const sizing = sizer.size(s, {
      availableCapitalUsd: env.ASSUMED_CAPITAL_USD - runningTotalExposure,
      currentTotalExposureUsd: runningTotalExposure,
      currentMarketExposureUsd: marketExposure.get(s.marketId) ?? 0,
      hasExistingOpenPosition: false, // нет реального position tracking до Phase 9
    });

    console.log(
      `- [score=${s.signalScore?.toFixed(1)}] ${s.outcome} @ ${s.entryPrice?.toFixed(3)} → target ${s.targetPrice}\n` +
        `    ${s.question}\n` +
        `    net_edge=${((s.expectedNetProfitPct ?? 0) * 100).toFixed(2)}%  liquidity=$${s.availableLiquidity?.toFixed(0)}  ` +
        `confidence=${s.confidenceScore?.toFixed(0)}  risk=${s.riskScore?.toFixed(0)}  ` +
        `ttr=${s.timeToResolutionMs ? (s.timeToResolutionMs / 3_600_000).toFixed(1) + "h" : "?"}\n` +
        `    recommended: $${sizing.finalNotionalUsd.toFixed(2)} (${sizing.finalShares?.toFixed(1)} shares)` +
        (sizing.appliedCaps.length > 0 ? `  [capped by: ${sizing.appliedCaps.join(", ")}]` : "")
    );

    if (!sizing.blocked) {
      runningTotalExposure += sizing.finalNotionalUsd;
      marketExposure.set(s.marketId, (marketExposure.get(s.marketId) ?? 0) + sizing.finalNotionalUsd);
    }
  }

  const reasonCounts = new Map<string, number>();
  for (const s of noTrade) {
    for (const r of s.reasons) reasonCounts.set(r, (reasonCounts.get(r) ?? 0) + 1);
  }

  console.log(`\n=== NO_TRADE: ${noTrade.length}, причины (сигнал может иметь несколько причин) ===`);
  for (const [reason, count] of [...reasonCounts.entries()].sort((a, b) => b[1] - a[1])) {
    console.log(`  ${reason}: ${count}`);
  }

  console.log(`\n=== Итоговая превью-экспозиция при исполнении всех кандидатов: $${runningTotalExposure.toFixed(2)} ===`);
  console.log("=== Ни один ордер не был создан. Исполнение (execution) ещё не реализовано. ===");
}

main().catch((err) => {
  console.error("Ошибка расчёта сигналов:", err);
  process.exit(1);
});

