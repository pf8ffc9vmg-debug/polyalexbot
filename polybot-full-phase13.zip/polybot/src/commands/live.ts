import { createInterface } from "node:readline/promises";
import { loadEnv } from "../config/env.js";
import { createGammaClient } from "../lib/gammaClient.js";
import { ClobClient } from "../lib/clobClient.js";
import { DataApiClient } from "../lib/dataApiClient.js";
import { MarketScanner } from "../lib/marketScanner.js";
import { EntrySignalEngine } from "../lib/entrySignalEngine.js";
import { PositionSizer } from "../lib/positionSizer.js";
import { RiskManager } from "../lib/riskManager.js";
import { TradingControlStore } from "../lib/tradingControlStore.js";
import { PaperStateStore } from "../lib/paperStateStore.js";
import { createLiveClient } from "../lib/liveClient.js";
import { LiveExecutionEngine, type LiveBuyCandidate } from "../lib/liveExecutionEngine.js";
import { accountFromPrivateKey } from "../lib/clobAuth.js";

/**
 * npm run live
 *
 * Phase 13, раздел 22 ТЗ — LIVE ACTIVATION, реализовано буквально:
 *   1. Требует BOT_MODE=live И LIVE_CONFIRM=true одновременно.
 *   2. Печатает предупреждающий баннер.
 *   3. Требует интерактивный ввод РОВНО "LIVE" (регистр важен) — любой
 *      другой ввод останавливает выполнение БЕЗ единого запроса к бирже.
 *   4. Только после этого создаётся live client и запускается один цикл.
 *
 * Дальше используется РОВНО ТА ЖЕ последовательность проверок, что в
 * `npm run paper` (Phase 9) — kill switch → RiskManager → PositionSizer —
 * ни одна проверка не пропущена и не ослаблена для live. Разница только в
 * последнем шаге: вместо PaperTradingEngine вызывается LiveExecutionEngine,
 * которая отправляет РЕАЛЬНЫЕ ордера через официальный @polymarket/client SDK.
 */

async function main() {
  const env = loadEnv();

  if (env.BOT_MODE !== "live" || !env.LIVE_CONFIRM) {
    console.log(
      `Требуется BOT_MODE=live И LIVE_CONFIRM=true в .env (сейчас: BOT_MODE=${env.BOT_MODE}, LIVE_CONFIRM=${env.LIVE_CONFIRM}).\n` +
        "Это намеренная защита от случайного включения реальной торговли (раздел 22 ТЗ)."
    );
    return;
  }

  console.log("==========================================");
  console.log("WARNING: LIVE TRADING");
  console.log("REAL MONEY WILL BE USED");
  console.log("==========================================\n");

  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const answer = await rl.question("Type LIVE to continue: ");
  rl.close();

  if (answer !== "LIVE") {
    console.log("\nПодтверждение не получено (нужно ввести ровно 'LIVE'). Остановлено, ни один запрос к бирже не отправлен.");
    return;
  }

  console.log("\nПодтверждено. Запускаю live cycle...\n");

  if (!env.POLYMARKET_PRIVATE_KEY) {
    console.log("POLYMARKET_PRIVATE_KEY не задан — невозможно торговать. Остановлено.");
    return;
  }

  const account = accountFromPrivateKey(env.POLYMARKET_PRIVATE_KEY);
  const funderAddress = env.POLYMARKET_FUNDER_ADDRESS || account.address;

  const gamma = createGammaClient(env);
  const clob = new ClobClient(env.CLOB_API_URL, env.CLOB_CHAIN_ID);
  const dataApi = new DataApiClient(env.DATA_API_URL);
  const scanner = new MarketScanner(gamma, clob);

  const signalEngine = new EntrySignalEngine({
    entryMin: env.ENTRY_MIN,
    entryMax: env.ENTRY_MAX,
    exitTarget: env.EXIT_TARGET,
    minNetProfitPct: env.MIN_NET_PROFIT_PCT,
    feeRateBps: env.FEE_RATE_BPS,
    slippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
    minLiquidityUsd: env.MIN_LIQUIDITY_USD,
    minTimeToResolutionMs: env.MIN_TIME_TO_RESOLUTION_MS,
    maxTimeToResolutionMs: env.MAX_TIME_TO_RESOLUTION_MS,
    orderbookMaxAgeMs: env.ORDERBOOK_MAX_AGE_MS,
  });

  const sizer = new PositionSizer({
    model: env.POSITION_SIZING_MODEL,
    fixedPositionUsd: env.FIXED_POSITION_USD,
    positionPctCapital: env.POSITION_PCT_CAPITAL,
    liquiditySizingFactor: env.LIQUIDITY_SIZING_FACTOR,
    spreadSizingReference: env.SPREAD_SIZING_REFERENCE,
    edgeSizingReferencePct: env.EDGE_SIZING_REFERENCE_PCT,
    hybridLiquidityWeight: env.HYBRID_LIQUIDITY_WEIGHT,
    maxPositionUsd: env.MAX_POSITION_USD,
    maxLiquidityUsage: env.MAX_LIQUIDITY_USAGE,
    maxTotalExposureUsd: env.MAX_TOTAL_EXPOSURE_USD,
    maxMarketExposureUsd: env.MAX_MARKET_EXPOSURE_USD,
    allowPositionScaling: env.ALLOW_POSITION_SCALING,
  });

  const riskManager = new RiskManager({
    maxOpenPositions: env.MAX_OPEN_POSITIONS,
    maxDailyLossUsd: env.MAX_DAILY_LOSS_USD,
    maxDrawdownPct: env.MAX_DRAWDOWN_PCT,
    maxTotalExposureUsd: env.MAX_TOTAL_EXPOSURE_USD,
    maxMarketExposureUsd: env.MAX_MARKET_EXPOSURE_USD,
    minLiquidityUsd: env.MIN_LIQUIDITY_USD,
    minNetProfitPct: env.MIN_NET_PROFIT_PCT,
    maxSlippagePct: env.MAX_SLIPPAGE_PCT,
    configuredSlippageBufferPct: env.SLIPPAGE_BUFFER_PCT,
    orderbookMaxAgeMs: env.ORDERBOOK_MAX_AGE_MS,
    minTimeToResolutionMs: env.MIN_TIME_TO_RESOLUTION_MS,
    maxTimeToResolutionMs: env.MAX_TIME_TO_RESOLUTION_MS,
    allowPositionScaling: env.ALLOW_POSITION_SCALING,
  });

  const controlStore = new TradingControlStore(env.TRADING_CONTROL_FILE);
  const controlState = await controlStore.load();
  const tradingEnabled = env.ENABLE_TRADING && controlState.enabled;

  if (!tradingEnabled) {
    console.log(
      `🛑 Kill switch активен (ENABLE_TRADING=${env.ENABLE_TRADING}, control.enabled=${controlState.enabled}` +
        (controlState.reason ? `, reason="${controlState.reason}"` : "") +
        `). Новые ордера НЕ отправляются. Останавливаюсь.`
    );
    return;
  }

  const stateStore = new PaperStateStore(env.LIVE_STATE_FILE);
  let state = await stateStore.load(0); // live: стартовый баланс не используется, реальный берётся с биржи
  state.equityPeakUsd = state.equityPeakUsd ?? 0;

  // Проверяем L2 credentials и получаем реальный баланс ДО создания live
  // client — createSecureClient() делает сетевой запрос на проверку/деплой
  // account wallet (relayer-v2.polymarket.com/deployed), это легитимное, но
  // отдельное от торговли действие. Явно фейлимся раньше, если credentials
  // вообще не заданы, а не тратим сетевой round-trip впустую.
  if (!env.POLYMARKET_API_KEY || !env.POLYMARKET_API_SECRET || !env.POLYMARKET_API_PASSPHRASE) {
    console.log("⚠️  Нет L2 credentials — запустите `npm run account` сначала. Останавливаюсь.");
    return;
  }

  const creds = {
    apiKey: env.POLYMARKET_API_KEY,
    secret: env.POLYMARKET_API_SECRET,
    passphrase: env.POLYMARKET_API_PASSPHRASE,
  };
  const balance = await clob.getBalanceAllowance(funderAddress, creds, "COLLATERAL");
  const availableCapitalUsd = Number(balance.balance);

  console.log(`Funder: ${funderAddress}  Доступный баланс: $${availableCapitalUsd.toFixed(2)}`);
  console.log(`Открытых позиций (по нашей памяти): ${state.openPositions.length}\n`);

  // Создаём live client только теперь, когда мы уже знаем, что у аккаунта
  // есть credentials и видимый баланс — не раньше.
  const liveClient = await createLiveClient(env);
  const executor = new LiveExecutionEngine(liveClient, dataApi, funderAddress, {
    exitTarget: env.EXIT_TARGET,
    maxEntrySlippagePct: env.MAX_ENTRY_SLIPPAGE_PCT,
    allowPositionScaling: env.ALLOW_POSITION_SCALING,
  });

  const markets = await scanner.scanActiveWeatherMarkets({ maxMarketsToScan: 300 });
  const allSignals = markets.flatMap((m) => signalEngine.evaluateMarket(m));
  const candidates = allSignals.filter((s) => s.decision === "BUY_CANDIDATE");

  const today = new Date().toISOString().slice(0, 10);
  const dailyRealizedPnlUsd = state.closedTrades
    .filter((t) => new Date(t.exitTime).toISOString().slice(0, 10) === today)
    .reduce((sum, t) => sum + t.netProfit, 0);

  const totalExposureUsd = state.openPositions.reduce(
    (sum, p) => sum + (p.filledQty - p.exitedQty) * p.avgEntryPrice,
    0
  );
  const marketExposureByMarket = new Map<string, number>();
  for (const p of state.openPositions) {
    marketExposureByMarket.set(
      p.marketId,
      (marketExposureByMarket.get(p.marketId) ?? 0) + (p.filledQty - p.exitedQty) * p.avgEntryPrice
    );
  }
  const currentDrawdownPct =
    state.equityPeakUsd! > 0
      ? Math.max(0, (state.equityPeakUsd! - (availableCapitalUsd + totalExposureUsd)) / state.equityPeakUsd!)
      : 0;

  const buyCandidates: LiveBuyCandidate[] = [];
  for (const signal of candidates) {
    const hasExisting = state.openPositions.some((p) => p.tokenId === signal.tokenId);
    const sizing = sizer.size(signal, {
      availableCapitalUsd,
      currentTotalExposureUsd: totalExposureUsd,
      currentMarketExposureUsd: marketExposureByMarket.get(signal.marketId) ?? 0,
      hasExistingOpenPosition: hasExisting,
    });
    if (sizing.blocked) continue;

    const riskCheck = riskManager.checkBuy(signal, sizing.finalNotionalUsd, {
      availableCapitalUsd,
      currentTotalExposureUsd: totalExposureUsd,
      currentMarketExposureUsd: marketExposureByMarket.get(signal.marketId) ?? 0,
      openPositionsCount: state.openPositions.length,
      dailyRealizedPnlUsd,
      currentDrawdownPct,
      hasExistingOpenPosition: hasExisting,
      tradingEnabled,
      orderbookBookAgeMs: 0,
    });

    if (riskCheck.passed) {
      buyCandidates.push({ signal, notionalUsd: sizing.finalNotionalUsd });
    } else {
      console.log(`🛑 RISK BLOCK: ${signal.outcome} ${signal.question.slice(0, 60)} — ${riskCheck.blockedBy.join(", ")}`);
    }
  }

  console.log(`\nBUY-кандидатов после RiskManager: ${buyCandidates.length}\n`);

  const { state: newState, summary } = await executor.runCycle(state, buyCandidates);
  state = newState;
  state.equityPeakUsd = Math.max(state.equityPeakUsd ?? 0, availableCapitalUsd + totalExposureUsd);
  await stateStore.save(state);

  console.log("\n=== Итог live-цикла ===");
  console.log(`  Entry попыток: ${summary.entriesAttempted}  Исполнено: ${summary.entriesFilled}  Отклонено: ${summary.entriesRejected}`);
  console.log(`  Exit-ордеров размещено: ${summary.exitOrdersPlaced}`);
  console.log(`  Realized PnL (всё время): $${summary.realizedPnlUsd.toFixed(2)}`);
  console.log(`  Закрытых сделок всего: ${state.closedTrades.length}`);
}

main().catch((err) => {
  console.error("Ошибка live execution:", err);
  process.exit(1);
});
