/**
 * npm run geocheck
 *
 * Polymarket блокирует размещение ордеров из ряда юрисдикций (полный блок или
 * close-only) по адресу IP. Официальный публичный эндпоинт для проверки:
 *   GET https://polymarket.com/api/geoblock
 * (это домен polymarket.com, НЕ clob.polymarket.com).
 *
 * Это read-only проверка, ничего не создаёт. Настоятельно рекомендуется запускать
 * её перед первым включением paper/live режима — см. docs/strategy-reverse-engineering.md
 * и README про гео-ограничения.
 */

async function main() {
  try {
    const res = await fetch("https://polymarket.com/api/geoblock");
    const data = await res.json();
    console.log("Geoblock-статус для текущего IP:");
    console.log(data);
    if ((data as { blocked?: boolean }).blocked) {
      console.log(
        "\nВНИМАНИЕ: этот IP помечен как заблокированный/ограниченный. " +
          "Размещение ордеров может быть отклонено независимо от того, что говорит остальной код."
      );
    }
  } catch (err) {
    console.error("Не удалось проверить geoblock:", (err as Error).message);
  }
}

main();
