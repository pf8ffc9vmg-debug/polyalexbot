import { loadEnv } from "../config/env.js";
import { createGammaClient } from "../lib/gammaClient.js";
import { ClobClient } from "../lib/clobClient.js";
import { MarketScanner } from "../lib/marketScanner.js";
import { JsonlSnapshotStore } from "../lib/snapshotStore.js";
import { PostgresSnapshotStore } from "../lib/postgresSnapshotStore.js";
import { OrderbookCollector } from "../lib/orderbookCollector.js";
import { getPool, closePool } from "../db/client.js";
import type { SnapshotStore } from "../lib/snapshotStore.js";

/**
 * npm run collect
 *
 * Phase 6 (OrderbookCollector) + раздел 29 ТЗ (DATA_COLLECTION_MODE) +
 * Phase 10 (PostgreSQL). Read-only: только сканирует и пишет snapshot'ы,
 * ничего не покупает и не продаёт.
 *
 * Хранилище выбирается автоматически: PostgreSQL, если задан DATABASE_URL
 * (не забудьте `npm run db:migrate` перед первым запуском), иначе JSONL-файл
 * (Phase 6 fallback) — интерфейс SnapshotStore одинаковый для обоих, код
 * коллектора не меняется.
 *
 * Останавливается по DATA_COLLECTION_HOURS или по Ctrl+C (SIGINT) — в обоих
 * случаях уже записанные snapshot'ы остаются сохранёнными.
 */

async function main() {
  const env = loadEnv();

  if (!env.DATA_COLLECTION_MODE) {
    console.log(
      "DATA_COLLECTION_MODE=false — команда `collect` предназначена именно для сбора данных.\n" +
        "Если вы уже прошли фазу сбора данных, следующий шаг — EntrySignalEngine (Phase 7), не эта команда."
    );
    return;
  }

  const gamma = createGammaClient(env);
  const clob = new ClobClient(env.CLOB_API_URL, env.CLOB_CHAIN_ID);
  const scanner = new MarketScanner(gamma, clob);

  const store = new JsonlSnapshotStore(env.SNAPSHOTS_DIR);
  await store.init();

  let activeStore: SnapshotStore = store;
  let storeDescription = `JSONL (${store.currentFilePath})`;

  if (env.DATABASE_URL) {
    const pool = getPool(env.DATABASE_URL);
    activeStore = new PostgresSnapshotStore(pool);
    storeDescription = "PostgreSQL (DATABASE_URL задан)";
  }

  const collector = new OrderbookCollector(scanner, activeStore, {
    scanIntervalMs: env.SCAN_INTERVAL_MS,
    orderbookMaxAgeMs: env.ORDERBOOK_MAX_AGE_MS,
    onCycle: (r) => {
      const ts = new Date().toISOString();
      console.log(
        `[${ts}] scanned=${r.scannedCount} weather markets, snapshots written=${r.snapshotsWritten} (stale=${r.staleCount})`
      );
    },
  });

  const durationMs = env.DATA_COLLECTION_HOURS * 60 * 60 * 1000;
  console.log(`Сбор данных: ${env.DATA_COLLECTION_HOURS}ч, интервал сканирования ${env.SCAN_INTERVAL_MS}мс`);
  console.log(`Хранилище: ${storeDescription}`);
  console.log("Ctrl+C — остановить досрочно (уже записанное сохранится).\n");

  process.on("SIGINT", () => {
    console.log("\nПолучен SIGINT, останавливаю сбор...");
    collector.stop();
  });

  await collector.runFor(durationMs);

  const all = await activeStore.loadAll();
  console.log(`\nСбор завершён. Всего snapshot'ов: ${all.length}`);
  console.log("Ни один ордер не был создан.");

  if (env.DATABASE_URL) await closePool();
}

main().catch((err) => {
  console.error("Ошибка сбора данных:", err);
  process.exit(1);
});
