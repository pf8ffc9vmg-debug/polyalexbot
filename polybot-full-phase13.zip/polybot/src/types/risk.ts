export type RiskBlockReason =
  | "TRADING_DISABLED" // раздел 32: kill switch / ENABLE_TRADING=false
  | "INSUFFICIENT_BALANCE" // 1
  | "MAX_TOTAL_EXPOSURE" // 2
  | "MAX_MARKET_EXPOSURE" // 3
  | "MAX_OPEN_POSITIONS" // 4
  | "DAILY_LOSS_LIMIT" // 5
  | "MAX_DRAWDOWN" // 6
  | "INSUFFICIENT_LIQUIDITY" // 7
  | "NET_PROFIT_TOO_LOW" // 8 (expected net profit)
  | "SLIPPAGE_TOO_HIGH" // 9
  | "ORDERBOOK_STALE" // 10 (freshness)
  | "TIME_TO_RESOLUTION_INVALID" // 11
  | "DUPLICATE_POSITION"; // 12

export interface RiskContext {
  availableCapitalUsd: number;
  currentTotalExposureUsd: number;
  currentMarketExposureUsd: number;
  openPositionsCount: number;
  dailyRealizedPnlUsd: number; // отрицательное = убыток
  currentDrawdownPct: number; // 0..1
  hasExistingOpenPosition: boolean;
  tradingEnabled: boolean; // ENABLE_TRADING && !killSwitchActive
  orderbookBookAgeMs: number;
}

export interface RiskCheckResult {
  passed: boolean;
  blockedBy: RiskBlockReason[];
}
