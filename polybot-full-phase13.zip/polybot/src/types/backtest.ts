import type { PaperTrade } from "./paperTrading.js";

export interface BacktestParams {
  entryMin: number;
  entryMax: number;
  exitTarget: number;
  positionSizingModel: string;
}

export interface BacktestResult {
  params: BacktestParams;
  cyclesProcessed: number;
  distinctDaysCovered: number;
  tradesCount: number;
  wins: number;
  losses: number;
  winRate: number | null;
  grossPnlUsd: number;
  feesUsd: number;
  netPnlUsd: number;
  maxDrawdownUsd: number;
  maxDrawdownPct: number;
  finalEquityUsd: number;
  equityCurve: number[];
  trades: PaperTrade[];
  /** раздел 37 ТЗ: явное предупреждение, если выборка слишком мала для доверия результату. */
  overfitWarning: string | null;
}
