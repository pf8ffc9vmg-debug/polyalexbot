export interface PaperFill {
  timestamp: number;
  side: "BUY" | "SELL";
  quotedPrice: number; // цена из orderbook на момент попытки
  filledPrice: number; // после симуляции slippage
  qty: number;
  notional: number; // filledPrice * qty
  fee: number;
}

/**
 * Открытая (или уже закрытая) позиция. `fills` (BUY) и `exitFills` (SELL)
 * хранятся отдельно, чтобы честно отражать partial fills (раздел 18 ТЗ) —
 * позиция может закрываться несколькими отдельными exit-исполнениями, как
 * это было видно в реальных данных (Munich 20C/21C — один BUY, пять SELL).
 */
export interface PaperPosition {
  marketId: string;
  conditionId: string;
  question: string;
  tokenId: string;
  outcome: "YES" | "NO";
  openedAt: number;
  fills: PaperFill[];
  exitFills: PaperFill[];
  filledQty: number; // сумма BUY qty
  exitedQty: number; // сумма SELL qty
  avgEntryPrice: number; // weighted по fills
  totalEntryNotional: number;
  totalEntryFee: number;
  status: "OPEN" | "CLOSED";
  signalScoreAtEntry: number | null;
  riskScoreAtEntry: number | null;
  timeToResolutionAtEntryMs: number | null;
  liquidityAtEntry: number | null;
}

/** Закрытая сделка — поля ровно по разделу 26 ТЗ (TRADE RECORD). */
export interface PaperTrade {
  tradeId: string;
  marketId: string;
  conditionId: string;
  tokenId: string;
  outcome: "YES" | "NO";
  entryPrice: number; // weighted avg
  exitPrice: number; // weighted avg
  requestedQuantity: number; // сколько рекомендовал PositionSizer
  filledQuantity: number; // сколько реально исполнено (может быть < requested)
  entryTime: number;
  exitTime: number;
  entryNotional: number;
  exitNotional: number;
  fees: number; // entry + exit fees
  slippage: number; // сумма |quotedPrice - filledPrice| * qty по всем fills
  grossProfit: number;
  netProfit: number;
  signalScore: number | null;
  riskScore: number | null;
  timeToResolutionMs: number | null;
  liquidity: number | null;
  reasonForEntry: string;
  reasonForExit: string;
}

export interface PaperState {
  cashBalanceUsd: number;
  startingBalanceUsd: number;
  openPositions: PaperPosition[];
  closedTrades: PaperTrade[];
  lastUpdated: number;
  /** High-water mark equity — для расчёта drawdown в RiskManager (раздел 31 ТЗ).
   *  Опционально для обратной совместимости со state-файлами из Phase 9,
   *  созданными до появления RiskManager. */
  equityPeakUsd?: number;
}

export interface PaperCycleSummary {
  entriesOpened: number;
  entriesSkippedNoFill: number;
  exitFillsExecuted: number;
  positionsClosed: number;
  cashBalanceUsd: number;
  totalExposureUsd: number;
  realizedPnlUsd: number;
  unrealizedPnlUsd: number;
}
