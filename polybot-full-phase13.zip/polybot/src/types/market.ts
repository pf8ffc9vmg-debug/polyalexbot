export type WeatherMarketKind =
  | "temperature_highest"
  | "temperature_lowest"
  | "temperature_range"
  | "rain"
  | "precipitation"
  | "snow"
  | "wind"
  | "humidity"
  | "unknown_weather";

/**
 * Результат классификации одного Gamma-рынка как weather market.
 * `kind` = "unknown_weather" означает "похоже на погоду, но конкретный тип не
 * распознан" — такие рынки не торгуются, но логируются, чтобы расширять
 * классификатор осознанно, а не наугад.
 */
export interface WeatherClassification {
  isWeather: boolean;
  kind: WeatherMarketKind | null;
  /** Город/локация, извлечённая из текста вопроса, если удалось распарсить. */
  city: string | null;
  /** Числовой порог/диапазон, извлечённый из текста, если применимо. */
  threshold: { low: number | null; high: number | null; unit: "F" | "C" | null };
  /** Поддерживается ли этот kind первой версией торговой стратегии (temperature-*). */
  tradableByCurrentStrategy: boolean;
}

export interface TokenQuote {
  tokenId: string;
  outcome: "YES" | "NO";
  bestBid: number | null;
  bestAsk: number | null;
  midpoint: number | null;
  spread: number | null;
  bidSize: number | null;
  askSize: number | null;
  bookAgeMs: number;
}

export interface ScannedWeatherMarket {
  marketId: string;
  conditionId: string;
  question: string;
  slug: string;
  classification: WeatherClassification;
  endDate: string | null;
  timeToResolutionMs: number | null;
  active: boolean | undefined;
  closed: boolean | undefined;
  liquidityNum: number | null;
  volumeNum: number | null;
  yes: TokenQuote | null;
  no: TokenQuote | null;
}

/**
 * Один снимок состояния одного токена в один момент времени.
 * Поля — ровно то, что перечислено в разделе 28 ТЗ, ни больше ни меньше:
 * timestamp, market, token, best_bid, best_ask, midpoint, spread,
 * available_bid_size, available_ask_size, volume, time_to_resolution.
 *
 * Это основной кирпичик для будущего reverse engineering (почему бот вошёл
 * или НЕ вошёл в конкретную сделку) и для backtest (Phase 11) — поэтому
 * пишется как можно более "сырым", без предвычисленных сигналов/score.
 */
export interface MarketSnapshot {
  timestamp: number; // unix ms, момент снятия snapshot
  marketId: string;
  conditionId: string;
  question: string;
  kind: WeatherMarketKind | null;
  tokenId: string;
  outcome: "YES" | "NO";
  bestBid: number | null;
  bestAsk: number | null;
  midpoint: number | null;
  spread: number | null;
  availableBidSize: number | null;
  availableAskSize: number | null;
  volumeNum: number | null;
  timeToResolutionMs: number | null;
  bookAgeMs: number;
  stale: boolean; // bookAgeMs > ORDERBOOK_MAX_AGE_MS на момент снятия
}
