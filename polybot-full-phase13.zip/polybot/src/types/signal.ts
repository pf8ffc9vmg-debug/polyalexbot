export type SignalDecision = "BUY_CANDIDATE" | "NO_TRADE";

/**
 * Причины отказа — перечислены явно, а не просто "false", чтобы наблюдатель
 * (observe mode, Phase 12) мог показать "почему не купили", как требует
 * раздел 24 ТЗ ("reason").
 */
export type NoTradeReason =
  | "PRICE_OUTSIDE_ENTRY_RANGE"
  | "ORDERBOOK_STALE"
  | "NO_ASK_LIQUIDITY"
  | "INSUFFICIENT_LIQUIDITY"
  | "NET_EDGE_TOO_LOW"
  | "TIME_TO_RESOLUTION_OUT_OF_RANGE"
  | "MARKET_NOT_TRADABLE_TYPE";

/**
 * Один сигнал = одна сторона (YES или NO) одного рынка на момент оценки.
 * Поля — ровно то, что перечислено в разделе 9 ТЗ:
 * entryPrice, targetPrice, spread, availableLiquidity, expectedProfit,
 * expectedNetProfit, timeToResolution, marketScore, confidenceScore,
 * riskScore, signalScore.
 *
 * ВАЖНО: marketScore/confidenceScore/riskScore/signalScore — это НАШИ
 * собственные эвристики для ранжирования кандидатов, а НЕ реконструкция
 * внутренней логики наблюдаемого бота (которую по 14-49 сделкам восстановить
 * невозможно — см. docs/strategy-reverse-engineering.md). Формулы прозрачны
 * и вынесены в комментарии entrySignalEngine.ts, чтобы их можно было
 * пересмотреть на реальных данных бэктеста (Phase 11).
 */
export interface EntrySignal {
  marketId: string;
  conditionId: string;
  question: string;
  tokenId: string;
  outcome: "YES" | "NO";

  entryPrice: number | null;
  targetPrice: number;
  spread: number | null; // targetPrice - entryPrice (gross edge)

  availableLiquidity: number | null; // $ на best ask (сколько можно купить по entryPrice)

  expectedProfitPerShare: number | null; // gross, до комиссий/slippage
  expectedNetProfitPerShare: number | null; // после FEE_RATE_BPS + SLIPPAGE_BUFFER_PCT
  expectedNetProfitPct: number | null; // % от entryPrice

  timeToResolutionMs: number | null;

  marketScore: number | null; // 0-100, привлекательность рынка независимо от текущей цены
  confidenceScore: number | null; // 0-100, насколько "почти решён" исход (proxy = близость цены к 1.0)
  riskScore: number | null; // 0-100, выше = рискованнее (широкое время до резолюции, тонкий edge, стейл-данные)
  signalScore: number | null; // 0-100, итоговый композитный скор для ранжирования BUY-кандидатов

  decision: SignalDecision;
  reasons: NoTradeReason[]; // пусто, если decision = BUY_CANDIDATE
}
