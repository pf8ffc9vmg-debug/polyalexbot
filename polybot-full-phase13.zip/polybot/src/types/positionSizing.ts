export type PositionSizingModel =
  | "fixed_usd" // Model A
  | "pct_capital" // Model B
  | "spread_proportional" // Model C
  | "liquidity_proportional" // Model D
  | "edge_proportional" // Model E
  | "hybrid"; // Model F

/** Причины, по которым итоговый размер был урезан относительно "сырого" расчёта модели. */
export type SizingCapReason =
  | "MAX_POSITION_USD"
  | "MAX_LIQUIDITY_USAGE"
  | "MAX_TOTAL_EXPOSURE"
  | "MAX_MARKET_EXPOSURE"
  | "AVAILABLE_CAPITAL"
  | "DUPLICATE_POSITION_BLOCKED";

export interface PositionSizingContext {
  /** Свободный баланс аккаунта (collateral), $. */
  availableCapitalUsd: number;
  /** Суммарная текущая экспозиция по всем открытым позициям, $. */
  currentTotalExposureUsd: number;
  /** Текущая экспозиция именно на этом рынке (для MAX_MARKET_EXPOSURE), $. */
  currentMarketExposureUsd: number;
  /** Есть ли уже открытая позиция по этому же market+token. */
  hasExistingOpenPosition: boolean;
}

export interface PositionSizingResult {
  model: PositionSizingModel;
  rawNotionalUsd: number; // до применения caps
  finalNotionalUsd: number; // после caps, то что реально рекомендуется
  finalShares: number | null; // finalNotionalUsd / entryPrice
  appliedCaps: SizingCapReason[]; // какие ограничения реально сработали (уменьшили размер)
  blocked: boolean; // true если finalNotionalUsd === 0 (например, DUPLICATE_POSITION_BLOCKED)
}
