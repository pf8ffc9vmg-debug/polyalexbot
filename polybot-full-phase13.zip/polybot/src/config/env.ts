import "dotenv/config";
import { z } from "zod";

/**
 * Единая точка загрузки конфигурации.
 * ВАЖНО: здесь нет ни одного хардкод-значения credentials.
 * Всё приходит из process.env / .env (который в .gitignore).
 */
const EnvSchema = z.object({
  POLYMARKET_PRIVATE_KEY: z.string().optional(),
  POLYMARKET_API_KEY: z.string().optional(),
  POLYMARKET_API_SECRET: z.string().optional(),
  POLYMARKET_API_PASSPHRASE: z.string().optional(),
  POLYMARKET_FUNDER_ADDRESS: z.string().optional(),
  POLYMARKET_SIGNATURE_TYPE: z.coerce.number().int().min(0).max(2).default(0),

  BOT_MODE: z.enum(["observe", "paper", "live"]).default("observe"),
  LIVE_CONFIRM: z
    .string()
    .default("false")
    .transform((v) => v.toLowerCase() === "true"),

  GAMMA_API_URL: z.string().url().default("https://gamma-api.polymarket.com"),
  CLOB_API_URL: z.string().url().default("https://clob.polymarket.com"),
  DATA_API_URL: z.string().url().default("https://data-api.polymarket.com"),
  CLOB_CHAIN_ID: z.coerce.number().int().default(137),

  // --- Раздел 27 ТЗ: PostgreSQL (Phase 10). Опционально — если не задан,
  // OrderbookCollector падает обратно на JsonlSnapshotStore (Phase 6).
  DATABASE_URL: z.string().optional(),

  // --- Раздел 8 ТЗ: orderbook staleness ---
  ORDERBOOK_MAX_AGE_MS: z.coerce.number().int().positive().default(5_000),

  // --- Раздел 6/29 ТЗ: orderbook collector / data collection mode ---
  SCAN_INTERVAL_MS: z.coerce.number().int().positive().default(30_000),
  DATA_COLLECTION_MODE: z
    .string()
    .default("true")
    .transform((v) => v.toLowerCase() === "true"),
  DATA_COLLECTION_HOURS: z.coerce.number().positive().default(1),
  SNAPSHOTS_DIR: z.string().default("./data/snapshots"),

  // --- Раздел 10-11 ТЗ: entry/exit. Дефолты — из reverse-engineering по 14
  // исходным сделкам (docs/strategy-reverse-engineering.md), НЕ доказанные
  // точные границы. Вторая пачка из 35 сделок показала входы вплоть до 0.79 —
  // по прямому указанию пользователя эта пачка сознательно не учтена в
  // текущей ревизии параметров, см. чат. Значения нужно откалибровать на
  // собранных Phase 6 snapshot'ах, а не считать окончательными.
  ENTRY_MIN: z.coerce.number().min(0).max(1).default(0.94),
  ENTRY_MAX: z.coerce.number().min(0).max(1).default(0.98),
  EXIT_TARGET: z.coerce.number().min(0).max(1).default(0.99),

  // --- Раздел 30 ТЗ: пороги прибыльности. Дефолты консервативны и явно
  // помечены как требующие калибровки — раздел 10 ТЗ (комиссии) UNKNOWN по
  // имеющимся данным, поэтому нельзя вывести "правильный" минимум аналитически.
  MIN_NET_PROFIT_PCT: z.coerce.number().min(0).default(0.003), // 0.3%, placeholder
  FEE_RATE_BPS: z.coerce.number().min(0).default(0), // Polymarket CLOB: 0 на большинстве рынков сейчас
  SLIPPAGE_BUFFER_PCT: z.coerce.number().min(0).default(0.002), // 0.2%, placeholder на округление/движение цены

  // --- Раздел 14 ТЗ: liquidity filter ---
  MIN_LIQUIDITY_USD: z.coerce.number().min(0).default(20), // placeholder, требует калибровки
  MAX_LIQUIDITY_USAGE: z.coerce.number().min(0).max(1).default(0.1),

  // --- Раздел 13 ТЗ: time to resolution. UNKNOWN точные границы (раздел 13
  // reverse-engineering doc) — дефолты широкие и явно placeholder.
  MIN_TIME_TO_RESOLUTION_MS: z.coerce.number().min(0).default(5 * 60_000), // 5 минут
  MAX_TIME_TO_RESOLUTION_MS: z.coerce.number().min(0).default(48 * 3_600_000), // 48 часов

  // --- Раздел 5/30 ТЗ: Position Sizing (Phase 8) ---
  // Reverse-engineering (docs/strategy-reverse-engineering.md) прямо говорит:
  // "Insufficient data to identify exact position sizing". Дефолтная модель —
  // консервативная fixed_usd, остальные модели доступны, но не доказаны.
  POSITION_SIZING_MODEL: z
    .enum(["fixed_usd", "pct_capital", "spread_proportional", "liquidity_proportional", "edge_proportional", "hybrid"])
    .default("fixed_usd"),
  FIXED_POSITION_USD: z.coerce.number().positive().default(50),
  POSITION_PCT_CAPITAL: z.coerce.number().min(0).max(1).default(0.02),
  LIQUIDITY_SIZING_FACTOR: z.coerce.number().min(0).max(1).default(0.05),
  SPREAD_SIZING_REFERENCE: z.coerce.number().positive().default(0.03),
  EDGE_SIZING_REFERENCE_PCT: z.coerce.number().positive().default(0.01),
  HYBRID_LIQUIDITY_WEIGHT: z.coerce.number().min(0).max(1).default(0.5),

  // --- Раздел 30-31 ТЗ: жёсткие risk-лимиты — применяются ПОСЛЕ модели,
  // независимо от того, какая модель выбрана.
  MAX_POSITION_USD: z.coerce.number().positive().default(100),
  MAX_TOTAL_EXPOSURE_USD: z.coerce.number().positive().default(500),
  MAX_MARKET_EXPOSURE_USD: z.coerce.number().positive().default(100),

  // --- Раздел 16 ТЗ: duplicate positions ---
  ALLOW_POSITION_SCALING: z
    .string()
    .default("false")
    .transform((v) => v.toLowerCase() === "true"),

  // Используется ТОЛЬКО в `npm run signals` для превью sizing, когда
  // .env не содержит credentials и реальный баланс не запрашивается.
  // НИКОГДА не используется как замена реального баланса в paper/live режимах.
  ASSUMED_CAPITAL_USD: z.coerce.number().positive().default(1000),

  // --- Раздел 23 ТЗ: Paper Trading (Phase 9) ---
  PAPER_STARTING_BALANCE_USD: z.coerce.number().positive().default(1000),
  PAPER_STATE_FILE: z.string().default("./data/paper-state.json"),

  // --- Раздел 36-37 ТЗ: Backtest (Phase 11) ---
  BACKTEST_CYCLE_BUCKET_MS: z.coerce.number().int().positive().default(10_000),
  BACKTEST_MIN_DISTINCT_DAYS: z.coerce.number().int().positive().default(5),
  BACKTEST_GRID: z
    .string()
    .default("false")
    .transform((v) => v.toLowerCase() === "true"),
  BACKTEST_ENTRY_MIN_RANGE: z.string().default("0.90,0.91,0.92,0.93,0.94,0.95,0.96,0.97,0.98"),
  BACKTEST_EXIT_TARGET_RANGE: z.string().default("0.985,0.99,0.995"),

  // --- Раздел 31 ТЗ: RiskManager ---
  MAX_OPEN_POSITIONS: z.coerce.number().int().positive().default(10),
  MAX_DAILY_LOSS_USD: z.coerce.number().positive().default(50),
  MAX_DRAWDOWN_PCT: z.coerce.number().min(0).max(1).default(0.2), // 20%
  MAX_SLIPPAGE_PCT: z.coerce.number().min(0).default(0.01), // 1%

  // --- Раздел 32 ТЗ: Kill Switch ---
  ENABLE_TRADING: z
    .string()
    .default("true")
    .transform((v) => v.toLowerCase() === "true"),
  TRADING_CONTROL_FILE: z.string().default("./data/trading-control.json"),

  // --- Phase 13: Live execution ---
  LIVE_STATE_FILE: z.string().default("./data/live-state.json"),
  // Защита от "цена изменилась до исполнения" (раздел 17 ТЗ): для FAK entry
  // ордера maxPrice = entryPrice * (1 + это значение). Если цена ушла дальше —
  // ордер просто не исполнится (или исполнится частично), а не купит по
  // худшей цене.
  MAX_ENTRY_SLIPPAGE_PCT: z.coerce.number().min(0).default(0.01),
});

export type BotEnv = z.infer<typeof EnvSchema>;

let cached: BotEnv | null = null;

export function loadEnv(): BotEnv {
  if (cached) return cached;
  const parsed = EnvSchema.safeParse(process.env);
  if (!parsed.success) {
    console.error("Некорректная конфигурация .env:");
    console.error(parsed.error.format());
    process.exit(1);
  }
  cached = parsed.data;
  return cached;
}

/** Маскирует секрет для логов: показывает только первые/последние символы. */
export function mask(value: string | undefined): string {
  if (!value) return "(не задано)";
  if (value.length <= 8) return "****";
  return `${value.slice(0, 4)}...${value.slice(-4)}`;
}
