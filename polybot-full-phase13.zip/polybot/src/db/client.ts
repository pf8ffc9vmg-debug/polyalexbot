import pg from "pg";

const { Pool } = pg;

let pool: pg.Pool | null = null;

/** Ленивая инициализация пула — вызывается только там, где реально нужна БД. */
export function getPool(databaseUrl: string): pg.Pool {
  if (!pool) {
    pool = new Pool({ connectionString: databaseUrl });
  }
  return pool;
}

export async function closePool(): Promise<void> {
  if (pool) {
    await pool.end();
    pool = null;
  }
}
