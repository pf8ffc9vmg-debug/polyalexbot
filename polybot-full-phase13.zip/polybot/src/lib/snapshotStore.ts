import { appendFile, mkdir, readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import type { MarketSnapshot } from "../types/market.js";

/**
 * Абстракция хранилища снимков рынка. Согласно исходному плану (раздел 40 ТЗ),
 * PostgreSQL — это Phase 10, которая идёт ПОСЛЕ orderbook collector (Phase 6) и
 * paper trading (Phase 9). Чтобы Phase 6 не блокировалась на ещё не
 * реализованной БД, здесь используется файловое JSONL-хранилище с тем же
 * интерфейсом, что будет у PostgreSQL-реализации — переключение на Postgres
 * в Phase 10 не потребует переписывать OrderbookCollector или backtest.
 */
export interface SnapshotStore {
  save(snapshot: MarketSnapshot): Promise<void>;
  saveMany(snapshots: MarketSnapshot[]): Promise<void>;
  loadAll(): Promise<MarketSnapshot[]>;
}

export class JsonlSnapshotStore implements SnapshotStore {
  private readonly filePath: string;

  constructor(dir: string, fileName?: string) {
    const name = fileName ?? `snapshots-${new Date().toISOString().slice(0, 10)}.jsonl`;
    this.filePath = path.join(dir, name);
  }

  async init(): Promise<void> {
    await mkdir(path.dirname(this.filePath), { recursive: true });
  }

  get currentFilePath(): string {
    return this.filePath;
  }

  async save(snapshot: MarketSnapshot): Promise<void> {
    await this.saveMany([snapshot]);
  }

  async saveMany(snapshots: MarketSnapshot[]): Promise<void> {
    if (snapshots.length === 0) return;
    await mkdir(path.dirname(this.filePath), { recursive: true });
    const lines = snapshots.map((s) => JSON.stringify(s)).join("\n") + "\n";
    await appendFile(this.filePath, lines, "utf-8");
  }

  async loadAll(): Promise<MarketSnapshot[]> {
    if (!existsSync(this.filePath)) return [];
    const content = await readFile(this.filePath, "utf-8");
    return content
      .split("\n")
      .filter((line) => line.trim().length > 0)
      .map((line) => JSON.parse(line) as MarketSnapshot);
  }
}

/** In-memory реализация — удобна для unit-тестов и для backtest на лету. */
export class InMemorySnapshotStore implements SnapshotStore {
  private readonly items: MarketSnapshot[] = [];

  async save(snapshot: MarketSnapshot): Promise<void> {
    this.items.push(snapshot);
  }

  async saveMany(snapshots: MarketSnapshot[]): Promise<void> {
    this.items.push(...snapshots);
  }

  async loadAll(): Promise<MarketSnapshot[]> {
    return [...this.items];
  }
}
