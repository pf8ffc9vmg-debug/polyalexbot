import type { PrivateKeyAccount } from "viem/accounts";
import { buildL2Headers, signClobRequestL2, type ClobCreds } from "./clobAuth.js";

/**
 * Клиент CLOB API (https://clob.polymarket.com).
 *
 * Публичные (без авторизации) эндпоинты — согласно docs.polymarket.com/quickstart/reference/endpoints:
 *   GET /price      — текущая цена токена
 *   GET /book        — orderbook по токену
 *   GET /midpoint     — midpoint
 *
 * Приватные (требуют L2, 5 заголовков POLY_*):
 *   POST /auth/api-key      — создать credentials (L1)
 *   GET  /auth/derive-api-key — деривировать существующие credentials (L1)
 *   GET  /balance-allowance   — баланс/allowance аккаунта (L2)
 *   GET  /data/orders        — открытые ордера аккаунта (L2)
 *
 * На этом этапе мы НЕ реализуем POST /order (создание ордеров) — согласно
 * FIRST TASK, это read-only фундамент.
 */

export interface OrderBookLevel {
  price: string;
  size: string;
}

export interface OrderBook {
  market: string;
  asset_id: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  timestamp?: string;
  [key: string]: unknown;
}

export class ClobClient {
  constructor(
    private readonly baseUrl: string,
    private readonly chainId: number
  ) {}

  // ---------- Публичные read-эндпоинты (без авторизации) ----------

  async getPrice(tokenId: string, side: "BUY" | "SELL"): Promise<number> {
    const url = new URL("/price", this.baseUrl);
    url.searchParams.set("token_id", tokenId);
    url.searchParams.set("side", side);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`CLOB /price вернул ${res.status}: ${await res.text()}`);
    const data = (await res.json()) as { price: string };
    return Number(data.price);
  }

  async getMidpoint(tokenId: string): Promise<number> {
    const url = new URL("/midpoint", this.baseUrl);
    url.searchParams.set("token_id", tokenId);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`CLOB /midpoint вернул ${res.status}: ${await res.text()}`);
    const data = (await res.json()) as { mid: string };
    return Number(data.mid);
  }

  async getOrderBook(tokenId: string): Promise<OrderBook> {
    const url = new URL("/book", this.baseUrl);
    url.searchParams.set("token_id", tokenId);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`CLOB /book вернул ${res.status}: ${await res.text()}`);
    return (await res.json()) as OrderBook;
  }

  // ---------- L1: создание/деривация L2 credentials ----------

  async createOrDeriveApiKey(
    account: PrivateKeyAccount,
    l1: { signature: string; timestamp: string; nonce: number }
  ): Promise<ClobCreds> {
    const headers = {
      POLY_ADDRESS: account.address,
      POLY_SIGNATURE: l1.signature,
      POLY_TIMESTAMP: l1.timestamp,
      POLY_NONCE: String(l1.nonce),
    };

    // Сначала пробуем derive (креды уже могли существовать), затем create.
    const deriveRes = await fetch(new URL("/auth/derive-api-key", this.baseUrl), {
      method: "GET",
      headers,
    });
    if (deriveRes.ok) {
      return (await deriveRes.json()) as ClobCreds;
    }

    const createRes = await fetch(new URL("/auth/api-key", this.baseUrl), {
      method: "POST",
      headers,
    });
    if (!createRes.ok) {
      throw new Error(
        `Не удалось создать/деривировать L2 credentials: ${createRes.status} ${await createRes.text()}`
      );
    }
    return (await createRes.json()) as ClobCreds;
  }

  // ---------- L2: приватные read-эндпоинты ----------

  private async l2Get<T>(path: string, address: string, creds: ClobCreds): Promise<T> {
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const signature = signClobRequestL2(creds.secret, timestamp, "GET", path);
    const headers = buildL2Headers({ address, creds, timestamp, signature });

    const res = await fetch(new URL(path, this.baseUrl), { method: "GET", headers });
    if (!res.ok) {
      throw new Error(`CLOB ${path} вернул ${res.status}: ${await res.text()}`);
    }
    return (await res.json()) as T;
  }

  async getBalanceAllowance(
    address: string,
    creds: ClobCreds,
    assetType: "COLLATERAL" | "CONDITIONAL" = "COLLATERAL",
    tokenId?: string
  ): Promise<{ balance: string; allowance: string }> {
    let path = `/balance-allowance?asset_type=${assetType}`;
    if (tokenId) path += `&token_id=${tokenId}`;
    return this.l2Get(path, address, creds);
  }

  async getOpenOrders(address: string, creds: ClobCreds): Promise<unknown[]> {
    return this.l2Get<unknown[]>("/data/orders", address, creds);
  }
}
