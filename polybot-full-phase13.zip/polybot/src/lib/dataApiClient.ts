/**
 * Data API (https://data-api.polymarket.com) — публичный, без авторизации.
 * Позволяет читать позиции и историю активности ЛЮБОГО адреса (это открытые
 * ончейн-производные данные), включая наш собственный funder address.
 */

export interface DataApiPosition {
  proxyWallet?: string;
  asset?: string; // token id
  conditionId?: string;
  size?: number;
  avgPrice?: number;
  curPrice?: number;
  [key: string]: unknown;
}

export interface DataApiTrade {
  proxyWallet?: string;
  asset?: string;
  side?: string;
  price?: number;
  size?: number;
  timestamp?: number;
  [key: string]: unknown;
}

export class DataApiClient {
  constructor(private readonly baseUrl: string) {}

  async getPositions(address: string): Promise<DataApiPosition[]> {
    const url = new URL("/positions", this.baseUrl);
    url.searchParams.set("user", address);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Data API /positions вернул ${res.status}: ${await res.text()}`);
    return (await res.json()) as DataApiPosition[];
  }

  async getTrades(address: string, limit = 50): Promise<DataApiTrade[]> {
    const url = new URL("/trades", this.baseUrl);
    url.searchParams.set("user", address);
    url.searchParams.set("limit", String(limit));
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Data API /trades вернул ${res.status}: ${await res.text()}`);
    return (await res.json()) as DataApiTrade[];
  }
}
