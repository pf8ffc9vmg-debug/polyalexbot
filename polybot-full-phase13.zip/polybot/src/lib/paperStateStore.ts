import { readFile, writeFile, mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import type { PaperState } from "../types/paperTrading.js";

/**
 * Персистентность paper trading состояния между запусками процесса — то, что
 * `npm run signals` (Phase 7-8) сознательно НЕ имело ("считает с нуля").
 * Файловое хранилище, как и SnapshotStore — до PostgreSQL (Phase 10).
 */
export class PaperStateStore {
  constructor(private readonly filePath: string) {}

  async load(startingBalanceUsd: number): Promise<PaperState> {
    if (!existsSync(this.filePath)) {
      return {
        cashBalanceUsd: startingBalanceUsd,
        startingBalanceUsd,
        openPositions: [],
        closedTrades: [],
        lastUpdated: Date.now(),
      };
    }
    const raw = await readFile(this.filePath, "utf-8");
    return JSON.parse(raw) as PaperState;
  }

  async save(state: PaperState): Promise<void> {
    await mkdir(path.dirname(this.filePath), { recursive: true });
    await writeFile(this.filePath, JSON.stringify(state, null, 2), "utf-8");
  }
}
