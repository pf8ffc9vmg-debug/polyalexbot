import { randomUUID } from "node:crypto";
import type pg from "pg";
import type { MarketSnapshot } from "../types/market.js";
import type { BacktestResult } from "../types/backtest.js";
import { BacktestRunner, type BacktestRunnerConfig } from "./backtestRunner.js";

export interface GridSearchConfig {
  entryMinValues: number[];
  exitTargetValues: number[];
  base: BacktestRunnerConfig; // entryMax и остальное берётся отсюда, entryMin/exitTarget перезаписываются
}

/**
 * Grid search (раздел 36 ТЗ): перебирает ENTRY и EXIT, для каждой комбинации
 * гоняет полный BacktestRunner.run(). Каждый прогон опционально пишется в
 * таблицу `backtest_runs` (раздел 27/36 ТЗ), если передан pg.Pool — так
 * результаты не теряются между запусками и их можно сравнивать позже.
 */
export async function runGridSearch(
  snapshots: MarketSnapshot[],
  grid: GridSearchConfig,
  pool?: pg.Pool
): Promise<BacktestResult[]> {
  const results: BacktestResult[] = [];

  for (const entryMin of grid.entryMinValues) {
    for (const exitTarget of grid.exitTargetValues) {
      if (entryMin > grid.base.signalEngine.entryMax) continue; // невалидная комбинация

      const runner = new BacktestRunner({
        ...grid.base,
        signalEngine: { ...grid.base.signalEngine, entryMin, exitTarget },
        paperEngine: { ...grid.base.paperEngine, exitTarget },
      });

      const result = await runner.run(snapshots);
      results.push(result);

      if (pool) {
        await pool.query(
          `INSERT INTO backtest_runs (run_id, finished_at, params_json, trades_count, win_rate, total_pnl, max_drawdown, notes)
           VALUES ($1, now(), $2, $3, $4, $5, $6, $7)`,
          [
            randomUUID(),
            JSON.stringify(result.params),
            result.tradesCount,
            result.winRate,
            result.netPnlUsd,
            result.maxDrawdownUsd,
            result.overfitWarning ?? null,
          ]
        );
      }
    }
  }

  return results.sort((a, b) => b.netPnlUsd - a.netPnlUsd);
}
