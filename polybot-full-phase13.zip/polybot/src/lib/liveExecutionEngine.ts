import { randomUUID } from "node:crypto";
import { OrderSide, OrderType } from "@polymarket/client";
import type { SecureClient, PublicActions, SecureActions } from "@polymarket/client";
import type { EntrySignal } from "../types/signal.js";
import type { PaperFill, PaperPosition, PaperState, PaperTrade } from "../types/paperTrading.js";
import type { DataApiClient } from "./dataApiClient.js";

/**
 * LiveExecutionEngine (Phase 13, разделы 17-19 ТЗ).
 *
 * ИСПОЛЬЗУЕТ РОВНО ТЕ ЖЕ ТИПЫ СОСТОЯНИЯ, что PaperTradingEngine
 * (PaperState/PaperPosition/PaperTrade из Phase 9) — сознательное решение:
 * структура позиции и сделки одинакова что в paper, что в live, разница
 * только в том, что здесь ордера реальные. Это позволяет переиспользовать
 * весь остальной pipeline (RiskManager, отчётность) без дублирования типов.
 *
 * Архитектура исполнения, отличная от PaperTradingEngine:
 *
 * ENTRY: FAK (Fill and Kill) market order, а не GTC limit.
 *   Почему: раздел 17 ТЗ требует "если цена изменилась до исполнения —
 *   отменить stale order". FAK делает это АТОМАРНО на стороне биржи —
 *   исполняет то, что доступно ПРЯМО СЕЙЧАС по цене не хуже `maxPrice`, и
 *   отменяет остаток сам. Это надёжнее, чем вручную отслеживать возраст
 *   отправленного ордера и присылать отдельный cancel — меньше окно для
 *   гонки состояний. `maxPrice = entryPrice * (1 + MAX_ENTRY_SLIPPAGE_PCT)`
 *   защищает от исполнения по существенно худшей цене, чем сигнал.
 *
 * EXIT: GTC limit order @ EXIT_TARGET — соответствует разделу 19 ТЗ дословно
 *   ("для exit: limit order @ 0.99"). Ордер лежит в стакане и может
 *   исполняться частями по мере появления встречной ликвидности — это и
 *   есть то поведение, что мы видели в реальных данных (Munich: 1 buy, 5
 *   sell fills). Перед каждым циклом проверяем, нет ли УЖЕ висящего exit
 *   ордера на этот токен — не дублируем.
 *
 * RECONCILIATION: реальные fills приходят асинхронно (кто-то может
 * исполнить наш resting limit ордер в любой момент, не только когда наш
 * процесс запущен). Поэтому перед каждым циклом мы: 1) спрашиваем реальный
 * текущий размер позиции у Data API (источник истины, не наша память);
 * 2) сверяем его с тем, что мы ожидали, и если позиция уменьшилась —
 * забираем реальные matched trades через listAccountTrades за период с
 * последней проверки, чтобы посчитать net_profit по разделу 26 честно, а
 * не оценочно.
 */

type LiveSecureClient = SecureClient<PublicActions, SecureActions>;

export interface LiveExecutionConfig {
  exitTarget: number;
  maxEntrySlippagePct: number;
  allowPositionScaling: boolean;
}

export interface LiveBuyCandidate {
  signal: EntrySignal;
  notionalUsd: number; // уже посчитан и провалидирован PositionSizer+RiskManager ДО вызова этого метода
}

export interface LiveCycleSummary {
  entriesAttempted: number;
  entriesFilled: number;
  entriesRejected: number;
  exitOrdersPlaced: number;
  positionsClosed: number;
  realizedPnlUsd: number;
}

export class LiveExecutionEngine {
  private lastReconciledAt = Date.now();

  constructor(
    private readonly client: LiveSecureClient,
    private readonly dataApi: DataApiClient,
    private readonly funderAddress: string,
    private readonly cfg: LiveExecutionConfig
  ) {}

  async runCycle(
    state: PaperState,
    buyCandidates: LiveBuyCandidate[]
  ): Promise<{ state: PaperState; summary: LiveCycleSummary }> {
    // --- 1) Reconciliation: сверить реальные позиции с тем, что мы помним ---
    await this.reconcilePositions(state);

    // --- 2) Управление exit-ордерами для уже открытых позиций ---
    let exitOrdersPlaced = 0;
    for (const pos of state.openPositions) {
      const remaining = pos.filledQty - pos.exitedQty;
      if (remaining <= 0) continue;

      const alreadyResting = await this.hasRestingExitOrder(pos.tokenId);
      if (alreadyResting) continue;

      const response = await this.client.placeLimitOrder({
        assetId: pos.tokenId,
        side: OrderSide.SELL,
        price: this.cfg.exitTarget,
        size: remaining,
      });

      if (response.ok) {
        exitOrdersPlaced++;
      } else {
        console.error(`⚠️  Не удалось разместить exit-ордер для ${pos.question}: ${response.message}`);
      }
    }

    // --- 3) Entries: FAK market-buy на каждый прошедший RiskManager сигнал ---
    let entriesAttempted = 0;
    let entriesFilled = 0;
    let entriesRejected = 0;

    for (const candidate of buyCandidates) {
      const { signal, notionalUsd } = candidate;
      if (signal.entryPrice === null) continue;

      const existing = state.openPositions.find((p) => p.tokenId === signal.tokenId);
      if (existing && !this.cfg.allowPositionScaling) continue;

      entriesAttempted++;
      if (!notionalUsd || notionalUsd <= 0) {
        entriesRejected++;
        continue;
      }

      const maxPrice = signal.entryPrice * (1 + this.cfg.maxEntrySlippagePct);

      const response = await this.client.placeMarketOrder({
        assetId: signal.tokenId,
        side: OrderSide.BUY,
        amount: notionalUsd,
        maxPrice,
        orderType: OrderType.FAK,
      });

      if (!response.ok) {
        console.error(`⚠️  Entry REJECTED: ${signal.outcome} ${signal.question} — ${response.message}`);
        entriesRejected++;
        continue;
      }

      const filledNotional = Number(response.makingAmount); // USD потрачено
      const filledQty = Number(response.takingAmount); // shares получено

      if (filledQty <= 0) {
        // FAK не нашёл ликвидности по приемлемой цене — не ошибка, просто
        // нечего исполнять прямо сейчас.
        entriesRejected++;
        continue;
      }

      entriesFilled++;
      const fill: PaperFill = {
        timestamp: Date.now(),
        side: "BUY",
        quotedPrice: signal.entryPrice,
        filledPrice: filledNotional / filledQty,
        qty: filledQty,
        notional: filledNotional,
        fee: 0, // комиссия неизвестна из ответа напрямую — уточняется через listAccountTrades при reconciliation
      };

      if (existing) {
        existing.fills.push(fill);
        existing.filledQty += filledQty;
        existing.totalEntryNotional += filledNotional;
        existing.avgEntryPrice = existing.totalEntryNotional / existing.filledQty;
      } else {
        state.openPositions.push({
          marketId: signal.marketId,
          conditionId: signal.conditionId,
          question: signal.question,
          tokenId: signal.tokenId,
          outcome: signal.outcome,
          openedAt: Date.now(),
          fills: [fill],
          exitFills: [],
          filledQty: filledQty,
          exitedQty: 0,
          avgEntryPrice: fill.filledPrice,
          totalEntryNotional: filledNotional,
          totalEntryFee: 0,
          status: "OPEN",
          signalScoreAtEntry: signal.signalScore,
          riskScoreAtEntry: signal.riskScore,
          timeToResolutionAtEntryMs: signal.timeToResolutionMs,
          liquidityAtEntry: signal.availableLiquidity,
        });
      }

      console.log(
        `✅ ENTRY FILLED: ${signal.outcome} ${signal.question} — ${filledQty.toFixed(2)} @ ${fill.filledPrice.toFixed(4)} ($${filledNotional.toFixed(2)}), orderId=${response.orderId}`
      );
    }

    state.lastUpdated = Date.now();

    const realizedPnlUsd = state.closedTrades.reduce((sum, t) => sum + t.netProfit, 0);

    return {
      state,
      summary: {
        entriesAttempted,
        entriesFilled,
        entriesRejected,
        exitOrdersPlaced,
        positionsClosed: 0, // считается внутри reconcilePositions, отражено в state.closedTrades
        realizedPnlUsd,
      },
    };
  }

  private async hasRestingExitOrder(tokenId: string): Promise<boolean> {
    const paginator = this.client.listOpenOrders({});
    const firstPage = await paginator.firstPage();
    return firstPage.items.some((o) => (o.assetId === tokenId || o.tokenId === tokenId) && o.side === "SELL");
  }

  /**
   * Сверяет наши записи об открытых позициях с реальным размером позиции на
   * Data API (источник истины — раздел 20 ТЗ). Если реальный размер меньше
   * ожидаемого (то есть resting exit ордер частично или полностью
   * исполнился с момента последней проверки), запрашивает реальные matched
   * trades через listAccountTrades и строит honest PaperTrade запись
   * (раздел 26 ТЗ), а не оценку.
   */
  private async reconcilePositions(state: PaperState): Promise<void> {
    const stillOpen: PaperPosition[] = [];

    for (const pos of state.openPositions) {
      const realPositions = await this.dataApi.getPositions(this.funderAddress);
      const realPos = realPositions.find((p) => p.asset === pos.tokenId);
      const realRemainingQty = realPos?.size ?? 0;
      const expectedRemainingQty = pos.filledQty - pos.exitedQty;

      if (realRemainingQty < expectedRemainingQty - 1e-6) {
        // Часть или всё исполнилось с момента последней проверки — забираем
        // реальные trades за этот период.
        const trades = await this.fetchRecentSellTrades(pos.tokenId);
        for (const t of trades) {
          pos.exitFills.push({
            timestamp: t.timestamp,
            side: "SELL",
            quotedPrice: this.cfg.exitTarget,
            filledPrice: t.price,
            qty: t.qty,
            notional: t.price * t.qty,
            fee: t.fee,
          });
        }
        pos.exitedQty = pos.filledQty - realRemainingQty;
      }

      if (pos.filledQty - pos.exitedQty <= 1e-6) {
        pos.status = "CLOSED";
        state.closedTrades.push(this.closePosition(pos));
      } else {
        stillOpen.push(pos);
      }
    }

    state.openPositions = stillOpen;
    this.lastReconciledAt = Date.now();
  }

  private async fetchRecentSellTrades(
    tokenId: string
  ): Promise<{ timestamp: number; price: number; qty: number; fee: number }[]> {
    const paginator = this.client.listAccountTrades({ assetId: tokenId });
    const page = await paginator.firstPage();
    return page.items
      .filter((t) => t.side === "SELL")
      .map((t) => ({
        timestamp: Date.now(), // ClobTrade не всегда несёт удобный timestamp поле напрямую в этой версии — используем момент reconciliation
        price: Number(t.price),
        qty: Number(t.size),
        fee: Number(t.price) * Number(t.size) * (Number(t.feeRateBps) / 10_000),
      }));
  }

  private closePosition(p: PaperPosition): PaperTrade {
    const exitNotional = p.exitFills.reduce((s, f) => s + f.notional, 0);
    const exitFee = p.exitFills.reduce((s, f) => s + f.fee, 0);
    const exitQty = p.exitFills.reduce((s, f) => s + f.qty, 0);
    const avgExitPrice = exitQty > 0 ? p.exitFills.reduce((s, f) => s + f.filledPrice * f.qty, 0) / exitQty : 0;

    const grossProfit = exitNotional - p.totalEntryNotional;
    const netProfit = grossProfit - p.totalEntryFee - exitFee;
    const lastExitTime = p.exitFills.length > 0 ? p.exitFills[p.exitFills.length - 1]!.timestamp : Date.now();

    return {
      tradeId: randomUUID(),
      marketId: p.marketId,
      conditionId: p.conditionId,
      tokenId: p.tokenId,
      outcome: p.outcome,
      entryPrice: p.avgEntryPrice,
      exitPrice: avgExitPrice,
      requestedQuantity: p.filledQty,
      filledQuantity: p.filledQty,
      entryTime: p.openedAt,
      exitTime: lastExitTime,
      entryNotional: p.totalEntryNotional,
      exitNotional,
      fees: p.totalEntryFee + exitFee,
      slippage: 0, // требует котировки на момент запроса ордера, не всегда доступно постфактум для реальных сделок
      grossProfit,
      netProfit,
      signalScore: p.signalScoreAtEntry,
      riskScore: p.riskScoreAtEntry,
      timeToResolutionMs: p.timeToResolutionAtEntryMs,
      liquidity: p.liquidityAtEntry,
      reasonForEntry: `signalScore=${p.signalScoreAtEntry ?? "?"} (live)`,
      reasonForExit: "GTC limit @ EXIT_TARGET matched (реальное исполнение)",
    };
  }
}
