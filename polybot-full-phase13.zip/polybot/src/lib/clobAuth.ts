import { createHmac } from "node:crypto";
import { privateKeyToAccount, type PrivateKeyAccount } from "viem/accounts";

/**
 * Реализация аутентификации CLOB V2 строго по официальной документации:
 * https://docs.polymarket.com/getting-started/api (раздел Authentication).
 *
 * L1 — EIP-712 подпись кошельком, используется один раз, чтобы создать/деривировать
 *      L2 api-key/secret/passphrase.
 * L2 — HMAC-SHA256(secret, timestamp + METHOD + path [+ body]) на каждый приватный запрос.
 *
 * Здесь НИЧЕГО не придумано: набор заголовков (POLY_ADDRESS, POLY_SIGNATURE,
 * POLY_TIMESTAMP, POLY_API_KEY, POLY_PASSPHRASE, POLY_NONCE) и формула L2-подписи
 * взяты дословно из документации.
 */

export interface ClobCreds {
  apiKey: string;
  secret: string;
  passphrase: string;
}

export function accountFromPrivateKey(privateKey: string): PrivateKeyAccount {
  const pk = privateKey.startsWith("0x") ? privateKey : `0x${privateKey}`;
  return privateKeyToAccount(pk as `0x${string}`);
}

/** Строит EIP-712 typed data для L1 ClobAuth и подписывает его. */
export async function signClobAuthL1(
  account: PrivateKeyAccount,
  chainId: number,
  nonce = 0
): Promise<{ signature: `0x${string}`; timestamp: string; nonce: number }> {
  const timestamp = Math.floor(Date.now() / 1000).toString();

  const domain = {
    name: "ClobAuthDomain",
    version: "1",
    chainId,
  } as const;

  const types = {
    ClobAuth: [
      { name: "address", type: "address" },
      { name: "timestamp", type: "string" },
      { name: "nonce", type: "uint256" },
      { name: "message", type: "string" },
    ],
  } as const;

  const message = {
    address: account.address,
    timestamp,
    nonce: BigInt(nonce),
    message: "This message attests that I control the given wallet",
  } as const;

  const signature = await account.signTypedData({
    domain,
    types,
    primaryType: "ClobAuth",
    message,
  });

  return { signature, timestamp, nonce };
}

/** Строит L2 HMAC-подпись для конкретного запроса. */
export function signClobRequestL2(
  secret: string,
  timestampSeconds: string,
  method: string,
  requestPath: string,
  body?: string
): string {
  const message = `${timestampSeconds}${method.toUpperCase()}${requestPath}${body ?? ""}`;
  const key = Buffer.from(secret, "base64");
  const hmac = createHmac("sha256", key).update(message).digest("base64");
  // urlsafe base64 with padding, как указано в документации
  return hmac.replace(/\+/g, "-").replace(/\//g, "_");
}

export function buildL2Headers(params: {
  address: string;
  creds: ClobCreds;
  timestamp: string;
  signature: string;
}): Record<string, string> {
  return {
    POLY_ADDRESS: params.address,
    POLY_SIGNATURE: params.signature,
    POLY_TIMESTAMP: params.timestamp,
    POLY_API_KEY: params.creds.apiKey,
    POLY_PASSPHRASE: params.creds.passphrase,
  };
}
