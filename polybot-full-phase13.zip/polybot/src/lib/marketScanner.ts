import type { GammaClient, GammaMarket } from "./gammaClient.js";
import type { ClobClient, OrderBook } from "./clobClient.js";
import { classifyWeatherMarket } from "./weatherClassifier.js";
import type { ScannedWeatherMarket, TokenQuote } from "../types/market.js";

/**
 * MarketScanner (Phase 4-7, частично).
 *
 * Делает:
 *  - постранично получает активные рынки из Gamma (`active=true&closed=false`);
 *  - классифицирует каждый как weather / не-weather (см. weatherClassifier.ts);
 *  - для weather-рынков достаёт YES/NO token id из `clobTokenIds`;
 *  - для каждого токена запрашивает свежий orderbook через CLOB `/book`
 *    (никогда не полагаемся только на last price — раздел 8 ТЗ) и вычисляет
 *    best bid/ask/midpoint/spread/available size;
 *  - вычисляет time_to_resolution по `endDate`.
 *
 * НЕ делает (сознательно, следующие фазы):
 *  - EntrySignalEngine / scoring — Phase 7;
 *  - сохранение snapshot'ов в PostgreSQL — Phase 6/10 (пока только in-memory);
 *  - order book imbalance и recent executions — требуют /trades и историю,
 *    добавляется вместе с market_snapshots.
 */

const CONCURRENCY = 8;

export interface ScanOptions {
  /** Сколько рынков максимум просмотреть за один проход (защита от рейт-лимитов). */
  maxMarketsToScan?: number;
  /** Пропускать рынки без активного orderbook на хотя бы одной стороне. */
  requireBothSidesQuoted?: boolean;
}

export class MarketScanner {
  constructor(
    private readonly gamma: GammaClient,
    private readonly clob: ClobClient
  ) {}

  async scanActiveWeatherMarkets(opts: ScanOptions = {}): Promise<ScannedWeatherMarket[]> {
    const maxMarkets = opts.maxMarketsToScan ?? 500;
    const rawMarkets = await this.fetchActiveMarkets(maxMarkets);

    const weatherCandidates = rawMarkets
      .map((m) => ({ market: m, classification: classifyWeatherMarket(m.question ?? "") }))
      .filter((x) => x.classification.isWeather);

    const results: ScannedWeatherMarket[] = [];
    for (let i = 0; i < weatherCandidates.length; i += CONCURRENCY) {
      const batch = weatherCandidates.slice(i, i + CONCURRENCY);
      const enriched = await Promise.all(batch.map((x) => this.enrichMarket(x.market, x.classification)));
      results.push(...enriched.filter((r): r is ScannedWeatherMarket => r !== null));
    }

    if (opts.requireBothSidesQuoted) {
      return results.filter((r) => r.yes?.bestBid !== null && r.no?.bestBid !== null);
    }
    return results;
  }

  private async fetchActiveMarkets(maxMarkets: number): Promise<GammaMarket[]> {
    const limit = 100;
    let offset = 0;
    const all: GammaMarket[] = [];

    while (all.length < maxMarkets) {
      const page = await this.gamma.listMarkets({
        active: true,
        closed: false,
        archived: false,
        limit,
        offset,
      });
      all.push(...page);
      if (page.length < limit) break; // последняя страница
      offset += limit;
    }

    return all.slice(0, maxMarkets);
  }

  private async enrichMarket(
    market: GammaMarket,
    classification: ReturnType<typeof classifyWeatherMarket>
  ): Promise<ScannedWeatherMarket | null> {
    const tokenIds = parseClobTokenIds(market.clobTokenIds);
    if (!tokenIds) {
      // Рынок без клоб-токенов (например, ещё не запущен на CLOB) — пропускаем.
      return {
        marketId: market.id,
        conditionId: market.conditionId,
        question: market.question,
        slug: market.slug,
        classification,
        endDate: market.endDate ?? null,
        timeToResolutionMs: computeTimeToResolutionMs(market.endDate),
        active: market.active,
        closed: market.closed,
        liquidityNum: numOrNull(market.liquidity),
        volumeNum: numOrNull(market.volume),
        yes: null,
        no: null,
      };
    }

    const [yesTokenId, noTokenId] = tokenIds;
    const [yesQuote, noQuote] = await Promise.all([
      this.quoteToken(yesTokenId, "YES"),
      this.quoteToken(noTokenId, "NO"),
    ]);

    return {
      marketId: market.id,
      conditionId: market.conditionId,
      question: market.question,
      slug: market.slug,
      classification,
      endDate: market.endDate ?? null,
      timeToResolutionMs: computeTimeToResolutionMs(market.endDate),
      active: market.active,
      closed: market.closed,
      liquidityNum: numOrNull(market.liquidity),
      volumeNum: numOrNull(market.volume),
      yes: yesQuote,
      no: noQuote,
    };
  }

  private async quoteToken(tokenId: string, outcome: "YES" | "NO"): Promise<TokenQuote> {
    const fetchedAt = Date.now();
    try {
      const book = await this.clob.getOrderBook(tokenId);
      return bookToQuote(tokenId, outcome, book, fetchedAt);
    } catch {
      // Токен может не иметь активного orderbook (закрыт/не запущен) — это
      // валидное состояние, не ошибка сканера.
      return {
        tokenId,
        outcome,
        bestBid: null,
        bestAsk: null,
        midpoint: null,
        spread: null,
        bidSize: null,
        askSize: null,
        bookAgeMs: Date.now() - fetchedAt,
      };
    }
  }
}

function bookToQuote(tokenId: string, outcome: "YES" | "NO", book: OrderBook, fetchedAt: number): TokenQuote {
  const bestBid = topOfBook(book.bids, "max");
  const bestAsk = topOfBook(book.asks, "min");
  const midpoint = bestBid !== null && bestAsk !== null ? (bestBid.price + bestAsk.price) / 2 : null;
  const spread = bestBid !== null && bestAsk !== null ? bestAsk.price - bestBid.price : null;

  return {
    tokenId,
    outcome,
    bestBid: bestBid?.price ?? null,
    bestAsk: bestAsk?.price ?? null,
    midpoint,
    spread,
    bidSize: bestBid?.size ?? null,
    askSize: bestAsk?.size ?? null,
    bookAgeMs: Date.now() - fetchedAt,
  };
}

function topOfBook(
  levels: { price: string; size: string }[] | undefined,
  mode: "max" | "min"
): { price: number; size: number } | null {
  if (!levels || levels.length === 0) return null;
  let best: { price: number; size: number } | null = null;
  for (const lvl of levels) {
    const price = Number(lvl.price);
    const size = Number(lvl.size);
    if (best === null) {
      best = { price, size };
      continue;
    }
    if (mode === "max" && price > best.price) best = { price, size };
    if (mode === "min" && price < best.price) best = { price, size };
  }
  return best;
}

function parseClobTokenIds(raw: string | undefined): [string, string] | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as string[];
    if (Array.isArray(parsed) && parsed.length === 2 && parsed[0] && parsed[1]) {
      return [parsed[0], parsed[1]];
    }
    return null;
  } catch {
    return null;
  }
}

function computeTimeToResolutionMs(endDate: string | undefined): number | null {
  if (!endDate) return null;
  const ts = Date.parse(endDate);
  if (Number.isNaN(ts)) return null;
  return ts - Date.now();
}

function numOrNull(v: string | undefined): number | null {
  if (v === undefined) return null;
  const n = Number(v);
  return Number.isNaN(n) ? null : n;
}
