import { readFile, writeFile, mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";

export interface TradingControlState {
  enabled: boolean;
  changedAt: number;
  changedBy: string; // "kill switch" | "manual enable" | ...
  reason: string | null;
}

/**
 * Персистентный флаг "торговля разрешена" (раздел 32 ТЗ). Отдельно от
 * ENABLE_TRADING в .env — .env читается один раз при старте процесса,
 * а kill switch должен работать МЕЖДУ запусками команд (`npm run kill`
 * сейчас, следующий `npm run paper` через минуту должен это увидеть).
 */
export class TradingControlStore {
  constructor(private readonly filePath: string) {}

  async load(): Promise<TradingControlState> {
    if (!existsSync(this.filePath)) {
      return { enabled: true, changedAt: Date.now(), changedBy: "default", reason: null };
    }
    const raw = await readFile(this.filePath, "utf-8");
    return JSON.parse(raw) as TradingControlState;
  }

  async disable(reason: string, changedBy = "kill switch"): Promise<void> {
    await this.write({ enabled: false, changedAt: Date.now(), changedBy, reason });
  }

  async enable(changedBy = "manual enable"): Promise<void> {
    await this.write({ enabled: true, changedAt: Date.now(), changedBy, reason: null });
  }

  private async write(state: TradingControlState): Promise<void> {
    await mkdir(path.dirname(this.filePath), { recursive: true });
    await writeFile(this.filePath, JSON.stringify(state, null, 2), "utf-8");
  }
}
