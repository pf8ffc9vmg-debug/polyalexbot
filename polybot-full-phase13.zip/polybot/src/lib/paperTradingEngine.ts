import { randomUUID } from "node:crypto";
import type { ScannedWeatherMarket, TokenQuote } from "../types/market.js";
import type { EntrySignal } from "../types/signal.js";
import type { PositionSizer } from "./positionSizer.js";
import type {
  PaperCycleSummary,
  PaperFill,
  PaperPosition,
  PaperState,
  PaperTrade,
} from "../types/paperTrading.js";

/**
 * PaperTradingEngine (Phase 9 ТЗ, раздел 23).
 *
 * Что симулируется:
 *  - order creation / fills / partial fills: заявка исполняется НЕ полностью
 *    автоматически, а ограничена реальным available size на нужной стороне
 *    стакана (askSize для входа, bidSize для выхода) — раздел 18 ТЗ.
 *  - fees: FEE_RATE_BPS от notional каждой ноги.
 *  - slippage: цена исполнения хуже котировки на SLIPPAGE_BUFFER_PCT —
 *    BUY исполняется чуть дороже ask, SELL — чуть дешевле bid.
 *  - position: агрегируется по market+token, может состоять из нескольких
 *    fills (scaling, если ALLOW_POSITION_SCALING=true).
 *  - exit: по достижении EXIT_TARGET на bid, тоже частями, если не хватает
 *    bid-глубины — ровно как в реальных данных (Munich: 1 buy → 5 sell fills).
 *  - PnL: realized по закрытым PaperTrade, unrealized по открытым позициям
 *    относительно текущего midpoint.
 *
 * ЧЕСТНОЕ ОГРАНИЧЕНИЕ (не скрываем): это НЕ полная симуляция очереди
 * ордеров. Неисполненный остаток заявки на ВХОД не "висит" до следующего
 * цикла — если PositionSizer порекомендовал больше, чем было в стакане,
 * непокрытая часть просто не покупается в этом цикле (упущенная
 * возможность, а не создание фантомного долга или зависшего ордера).
 * Неисполненный остаток на ВЫХОД, наоборот, остаётся открытым и будет
 * повторно предложен к продаже в следующем цикле — это соответствует
 * наблюдаемому поведению (партиями по мере появления bid-ликвидности) и не
 * требует отдельного "pending order" состояния, потому что позиция и есть
 * это состояние.
 */

export interface PaperEngineConfig {
  feeRateBps: number;
  slippageBufferPct: number;
  exitTarget: number;
  allowPositionScaling: boolean;
}

export class PaperTradingEngine {
  constructor(
    private readonly sizer: PositionSizer,
    private readonly cfg: PaperEngineConfig
  ) {}

  async runCycle(
    state: PaperState,
    markets: ScannedWeatherMarket[],
    buySignals: EntrySignal[]
  ): Promise<{ state: PaperState; summary: PaperCycleSummary }> {
    const quoteByToken = buildQuoteLookup(markets);

    let entriesOpened = 0;
    let entriesSkippedNoFill = 0;
    let exitFillsExecuted = 0;
    let positionsClosed = 0;

    // --- 1) Exits (первыми — освобождаем капитал в этом же цикле) ---
    const stillOpen: PaperPosition[] = [];
    for (const pos of state.openPositions) {
      const quote = quoteByToken.get(pos.tokenId);
      const bestBid = quote?.bestBid ?? null;
      const bidSize = quote?.bidSize ?? null;

      if (bestBid !== null && bestBid >= this.cfg.exitTarget && bidSize !== null && bidSize > 0) {
        const remainingQty = pos.filledQty - pos.exitedQty;
        const fillQty = Math.min(remainingQty, bidSize);

        if (fillQty > 0) {
          const filledPrice = bestBid * (1 - this.cfg.slippageBufferPct);
          const notional = filledPrice * fillQty;
          const fee = notional * (this.cfg.feeRateBps / 10_000);
          const proceeds = notional - fee;

          state.cashBalanceUsd += proceeds;
          pos.exitFills.push({
            timestamp: Date.now(),
            side: "SELL",
            quotedPrice: bestBid,
            filledPrice,
            qty: fillQty,
            notional,
            fee,
          });
          pos.exitedQty += fillQty;
          exitFillsExecuted++;
        }
      }

      if (pos.filledQty - pos.exitedQty <= 1e-9) {
        pos.status = "CLOSED";
        state.closedTrades.push(closePosition(pos));
        positionsClosed++;
      } else {
        stillOpen.push(pos);
      }
    }
    state.openPositions = stillOpen;

    // --- 2) Entries ---
    let runningTotalExposure = sumExposure(state.openPositions);
    const marketExposure = new Map<string, number>();
    for (const p of state.openPositions) {
      marketExposure.set(p.marketId, (marketExposure.get(p.marketId) ?? 0) + openNotional(p));
    }

    for (const signal of buySignals) {
      if (signal.entryPrice === null) continue;

      const existing = state.openPositions.find((p) => p.tokenId === signal.tokenId);
      if (existing && !this.cfg.allowPositionScaling) continue; // раздел 16 ТЗ

      const sizing = this.sizer.size(signal, {
        availableCapitalUsd: state.cashBalanceUsd,
        currentTotalExposureUsd: runningTotalExposure,
        currentMarketExposureUsd: marketExposure.get(signal.marketId) ?? 0,
        hasExistingOpenPosition: !!existing,
      });

      if (sizing.blocked || sizing.finalShares === null || sizing.finalShares <= 0) {
        entriesSkippedNoFill++;
        continue;
      }

      const quote = quoteByToken.get(signal.tokenId);
      const askSize = quote?.askSize ?? 0;
      const requestedQty = sizing.finalShares;
      let fillQty = Math.min(requestedQty, askSize);

      // Не покупаем больше, чем можем себе позволить (fee включена в стоимость).
      const feeMultiplier = 1 + this.cfg.feeRateBps / 10_000;
      const maxAffordableQty = state.cashBalanceUsd / (signal.entryPrice * (1 + this.cfg.slippageBufferPct) * feeMultiplier);
      fillQty = Math.min(fillQty, Math.max(0, maxAffordableQty));

      if (fillQty <= 0) {
        entriesSkippedNoFill++;
        continue;
      }

      const filledPrice = signal.entryPrice * (1 + this.cfg.slippageBufferPct);
      const notional = filledPrice * fillQty;
      const fee = notional * (this.cfg.feeRateBps / 10_000);
      const totalCost = notional + fee;

      state.cashBalanceUsd -= totalCost;
      runningTotalExposure += notional;
      marketExposure.set(signal.marketId, (marketExposure.get(signal.marketId) ?? 0) + notional);

      const fill: PaperFill = {
        timestamp: Date.now(),
        side: "BUY",
        quotedPrice: signal.entryPrice,
        filledPrice,
        qty: fillQty,
        notional,
        fee,
      };

      if (existing) {
        existing.fills.push(fill);
        existing.filledQty += fillQty;
        existing.totalEntryNotional += notional;
        existing.totalEntryFee += fee;
        existing.avgEntryPrice = existing.totalEntryNotional / existing.filledQty;
      } else {
        state.openPositions.push({
          marketId: signal.marketId,
          conditionId: signal.conditionId,
          question: signal.question,
          tokenId: signal.tokenId,
          outcome: signal.outcome,
          openedAt: Date.now(),
          fills: [fill],
          exitFills: [],
          filledQty: fillQty,
          exitedQty: 0,
          avgEntryPrice: filledPrice,
          totalEntryNotional: notional,
          totalEntryFee: fee,
          status: "OPEN",
          signalScoreAtEntry: signal.signalScore,
          riskScoreAtEntry: signal.riskScore,
          timeToResolutionAtEntryMs: signal.timeToResolutionMs,
          liquidityAtEntry: signal.availableLiquidity,
        });
      }

      entriesOpened++;

      if (fillQty < requestedQty - 1e-6) {
        // Partial fill — раздел 18 ТЗ: явно не считаем requested исполненным.
        entriesSkippedNoFill++; // считается и как "opened" (частично), и как "недозаполнено" — обе метрики честны
      }
    }

    state.lastUpdated = Date.now();

    const realizedPnlUsd = state.closedTrades.reduce((sum, t) => sum + t.netProfit, 0);
    const unrealizedPnlUsd = state.openPositions.reduce((sum, p) => {
      const quote = quoteByToken.get(p.tokenId);
      const mark = quote?.midpoint ?? p.avgEntryPrice;
      const remainingQty = p.filledQty - p.exitedQty;
      return sum + (mark - p.avgEntryPrice) * remainingQty;
    }, 0);

    const summary: PaperCycleSummary = {
      entriesOpened,
      entriesSkippedNoFill,
      exitFillsExecuted,
      positionsClosed,
      cashBalanceUsd: state.cashBalanceUsd,
      totalExposureUsd: sumExposure(state.openPositions),
      realizedPnlUsd,
      unrealizedPnlUsd,
    };

    return { state, summary };
  }
}

function buildQuoteLookup(markets: ScannedWeatherMarket[]): Map<string, TokenQuote> {
  const map = new Map<string, TokenQuote>();
  for (const m of markets) {
    if (m.yes) map.set(m.yes.tokenId, m.yes);
    if (m.no) map.set(m.no.tokenId, m.no);
  }
  return map;
}

function sumExposure(positions: PaperPosition[]): number {
  return positions.reduce((sum, p) => sum + openNotional(p), 0);
}

function openNotional(p: PaperPosition): number {
  const remainingQty = p.filledQty - p.exitedQty;
  return remainingQty * p.avgEntryPrice;
}

function closePosition(p: PaperPosition): PaperTrade {
  const exitNotional = p.exitFills.reduce((s, f) => s + f.notional, 0);
  const exitFee = p.exitFills.reduce((s, f) => s + f.fee, 0);
  const exitQty = p.exitFills.reduce((s, f) => s + f.qty, 0);
  const avgExitPrice = exitQty > 0 ? p.exitFills.reduce((s, f) => s + f.filledPrice * f.qty, 0) / exitQty : 0;

  const slippage =
    p.fills.reduce((s, f) => s + Math.abs(f.filledPrice - f.quotedPrice) * f.qty, 0) +
    p.exitFills.reduce((s, f) => s + Math.abs(f.filledPrice - f.quotedPrice) * f.qty, 0);

  const grossProfit = exitNotional - p.totalEntryNotional;
  const netProfit = grossProfit - p.totalEntryFee - exitFee;

  const lastExitTime = p.exitFills.length > 0 ? p.exitFills[p.exitFills.length - 1]!.timestamp : Date.now();

  return {
    tradeId: randomUUID(),
    marketId: p.marketId,
    conditionId: p.conditionId,
    tokenId: p.tokenId,
    outcome: p.outcome,
    entryPrice: p.avgEntryPrice,
    exitPrice: avgExitPrice,
    requestedQuantity: p.filledQty, // на paper v1 requested == filled на входе (см. ограничение выше)
    filledQuantity: p.filledQty,
    entryTime: p.openedAt,
    exitTime: lastExitTime,
    entryNotional: p.totalEntryNotional,
    exitNotional,
    fees: p.totalEntryFee + exitFee,
    slippage,
    grossProfit,
    netProfit,
    signalScore: p.signalScoreAtEntry,
    riskScore: p.riskScoreAtEntry,
    timeToResolutionMs: p.timeToResolutionAtEntryMs,
    liquidity: p.liquidityAtEntry,
    reasonForEntry: `signalScore=${p.signalScoreAtEntry ?? "?"}`,
    reasonForExit: `bid reached EXIT_TARGET`,
  };
}
