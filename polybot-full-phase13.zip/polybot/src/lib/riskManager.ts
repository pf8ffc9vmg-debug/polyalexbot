import type { EntrySignal } from "../types/signal.js";
import type { RiskCheckResult, RiskContext, RiskBlockReason } from "../types/risk.js";

/**
 * RiskManager (Phase "перед Phase 13", раздел 31 ТЗ).
 *
 * Раньше caps (MAX_POSITION_USD, MAX_LIQUIDITY_USAGE, MAX_TOTAL_EXPOSURE,
 * MAX_MARKET_EXPOSURE, duplicate position) жили внутри PositionSizer
 * (Phase 8) — это осталось и продолжает работать (defense in depth). Но
 * раздел 31 ТЗ явно требует ОТДЕЛЬНЫЙ RiskManager с полным списком из 12
 * проверок перед КАЖДЫМ BUY, включая то, чего в PositionSizer нет вообще:
 * daily PnL, drawdown, число открытых позиций, kill switch.
 *
 * Вызывается ПОСЛЕ PositionSizer (когда уже известен предполагаемый notional)
 * и ДО фактического исполнения — раздел 17 ТЗ, шаг "проверить risk limits"
 * как отдельный шаг перед "отправить order".
 *
 * ВАЖНО: этот модуль только проверяет и возвращает причины блокировки — он
 * НЕ решает сам, что делать при блокировке (остановить всю торговлю, только
 * этот сигнал, и т.д.) — это ответственность вызывающего кода
 * (paper.ts / будущий live executor), которая может отличаться в paper и live.
 */

export interface RiskManagerConfig {
  maxOpenPositions: number;
  maxDailyLossUsd: number;
  maxDrawdownPct: number;
  maxTotalExposureUsd: number;
  maxMarketExposureUsd: number;
  minLiquidityUsd: number;
  minNetProfitPct: number;
  maxSlippagePct: number;
  configuredSlippageBufferPct: number; // текущее значение SLIPPAGE_BUFFER_PCT
  orderbookMaxAgeMs: number;
  minTimeToResolutionMs: number;
  maxTimeToResolutionMs: number;
  allowPositionScaling: boolean;
}

export class RiskManager {
  constructor(private readonly cfg: RiskManagerConfig) {}

  checkBuy(signal: EntrySignal, proposedNotionalUsd: number, ctx: RiskContext): RiskCheckResult {
    const blockedBy: RiskBlockReason[] = [];

    // 0 (раздел 32): kill switch / ENABLE_TRADING=false — проверяется первым,
    // раньше остальных, потому что если торговля выключена, остальные
    // проверки не имеют смысла.
    if (!ctx.tradingEnabled) blockedBy.push("TRADING_DISABLED");

    // 1. available balance
    if (proposedNotionalUsd > ctx.availableCapitalUsd) blockedBy.push("INSUFFICIENT_BALANCE");

    // 2. total exposure
    if (ctx.currentTotalExposureUsd + proposedNotionalUsd > this.cfg.maxTotalExposureUsd) {
      blockedBy.push("MAX_TOTAL_EXPOSURE");
    }

    // 3. market exposure
    if (ctx.currentMarketExposureUsd + proposedNotionalUsd > this.cfg.maxMarketExposureUsd) {
      blockedBy.push("MAX_MARKET_EXPOSURE");
    }

    // 4. number of open positions
    if (ctx.openPositionsCount >= this.cfg.maxOpenPositions) blockedBy.push("MAX_OPEN_POSITIONS");

    // 5. daily PnL
    if (ctx.dailyRealizedPnlUsd <= -this.cfg.maxDailyLossUsd) blockedBy.push("DAILY_LOSS_LIMIT");

    // 6. drawdown
    if (ctx.currentDrawdownPct >= this.cfg.maxDrawdownPct) blockedBy.push("MAX_DRAWDOWN");

    // 7. liquidity
    if ((signal.availableLiquidity ?? 0) < this.cfg.minLiquidityUsd) blockedBy.push("INSUFFICIENT_LIQUIDITY");

    // 8. expected net profit
    if ((signal.expectedNetProfitPct ?? -1) < this.cfg.minNetProfitPct) blockedBy.push("NET_PROFIT_TOO_LOW");

    // 9. slippage — проверяем, что сконфигурированная терпимость к slippage
    // не превышает risk-аппетит (MAX_SLIPPAGE_PCT). Это проверка КОНФИГА, а
    // не фактического рыночного slippage (который узнаём только после
    // исполнения) — раздел 31 явно требует эту проверку "перед BUY", когда
    // фактического исполнения ещё не было.
    if (this.cfg.configuredSlippageBufferPct > this.cfg.maxSlippagePct) blockedBy.push("SLIPPAGE_TOO_HIGH");

    // 10. orderbook freshness
    if (ctx.orderbookBookAgeMs > this.cfg.orderbookMaxAgeMs) blockedBy.push("ORDERBOOK_STALE");

    // 11. time to resolution
    const ttr = signal.timeToResolutionMs;
    if (ttr === null || ttr < this.cfg.minTimeToResolutionMs || ttr > this.cfg.maxTimeToResolutionMs) {
      blockedBy.push("TIME_TO_RESOLUTION_INVALID");
    }

    // 12. duplicate position
    if (ctx.hasExistingOpenPosition && !this.cfg.allowPositionScaling) blockedBy.push("DUPLICATE_POSITION");

    return { passed: blockedBy.length === 0, blockedBy };
  }
}
