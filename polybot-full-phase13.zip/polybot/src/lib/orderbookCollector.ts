import type { MarketScanner } from "./marketScanner.js";
import type { SnapshotStore } from "./snapshotStore.js";
import type { MarketSnapshot, ScannedWeatherMarket, TokenQuote } from "../types/market.js";

/**
 * OrderbookCollector (Phase 6 ТЗ).
 *
 * Периодически вызывает MarketScanner, превращает каждый котированный токен
 * (YES и NO) в MarketSnapshot и сохраняет через SnapshotStore.
 *
 * Помечает snapshot как `stale`, если orderbook старше ORDERBOOK_MAX_AGE_MS
 * (раздел 8 ТЗ) — важно: это флаг для последующего анализа/фильтрации, а не
 * причина не сохранять snapshot. Даже stale-данные полезны для
 * reverse-engineering (сколько раз бот видел устаревший стакан).
 *
 * НЕ принимает решений о торговле — это чистый data collection слой,
 * EntrySignalEngine (Phase 7) будет отдельным потребителем этих snapshot'ов.
 */
export class OrderbookCollector {
  private timer: NodeJS.Timeout | null = null;
  private stopped = false;

  constructor(
    private readonly scanner: MarketScanner,
    private readonly store: SnapshotStore,
    private readonly options: {
      scanIntervalMs: number;
      orderbookMaxAgeMs: number;
      maxMarketsToScan?: number;
      onCycle?: (result: { scannedCount: number; snapshotsWritten: number; staleCount: number }) => void;
    }
  ) {}

  /** Один цикл: скан + запись. Возвращает статистику для логов/наблюдения. */
  async runOnce(): Promise<{ scannedCount: number; snapshotsWritten: number; staleCount: number }> {
    const markets = await this.scanner.scanActiveWeatherMarkets({
      maxMarketsToScan: this.options.maxMarketsToScan ?? 300,
    });

    const snapshots: MarketSnapshot[] = [];
    for (const market of markets) {
      if (market.yes) snapshots.push(this.toSnapshot(market, market.yes));
      if (market.no) snapshots.push(this.toSnapshot(market, market.no));
    }

    await this.store.saveMany(snapshots);

    const staleCount = snapshots.filter((s) => s.stale).length;
    const result = { scannedCount: markets.length, snapshotsWritten: snapshots.length, staleCount };
    this.options.onCycle?.(result);
    return result;
  }

  /** Запускает периодический сбор на заданную длительность (мс). Блокирующий промис. */
  async runFor(durationMs: number): Promise<void> {
    const deadline = Date.now() + durationMs;
    this.stopped = false;

    while (!this.stopped && Date.now() < deadline) {
      await this.runOnce();
      const remaining = deadline - Date.now();
      if (remaining <= 0) break;
      const wait = Math.min(this.options.scanIntervalMs, remaining);
      await sleep(wait);
    }
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
  }

  private toSnapshot(market: ScannedWeatherMarket, quote: TokenQuote): MarketSnapshot {
    return {
      timestamp: Date.now(),
      marketId: market.marketId,
      conditionId: market.conditionId,
      question: market.question,
      kind: market.classification.kind,
      tokenId: quote.tokenId,
      outcome: quote.outcome,
      bestBid: quote.bestBid,
      bestAsk: quote.bestAsk,
      midpoint: quote.midpoint,
      spread: quote.spread,
      availableBidSize: quote.bidSize,
      availableAskSize: quote.askSize,
      volumeNum: market.volumeNum,
      timeToResolutionMs: market.timeToResolutionMs,
      bookAgeMs: quote.bookAgeMs,
      stale: quote.bookAgeMs > this.options.orderbookMaxAgeMs,
    };
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
