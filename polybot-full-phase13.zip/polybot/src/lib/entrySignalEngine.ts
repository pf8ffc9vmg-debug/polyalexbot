import type { ScannedWeatherMarket, TokenQuote } from "../types/market.js";
import type { EntrySignal, NoTradeReason } from "../types/signal.js";

/**
 * EntrySignalEngine (Phase 7 ТЗ).
 *
 * Архитектура сознательно двухслойная:
 *
 * 1) ЖЁСТКИЕ ФИЛЬТРЫ (hard filters) — прямо прописаны в ТЗ, это не эвристика:
 *    - entryPrice должен быть в [ENTRY_MIN, ENTRY_MAX]           (раздел 10)
 *    - orderbook не должен быть stale                            (раздел 8)
 *    - должна быть ask-ликвидность вообще                        (раздел 8)
 *    - availableLiquidity >= MIN_LIQUIDITY_USD                   (раздел 14)
 *    - net edge >= MIN_NET_PROFIT_PCT после fee+slippage buffer  (раздел 9)
 *    - timeToResolution в [MIN_TIME_TO_RESOLUTION_MS, MAX_...]   (раздел 13)
 *    Если любой фильтр не проходит → decision = NO_TRADE, reasons заполнены.
 *
 * 2) МЯГКИЕ СКОРЫ (marketScore/confidenceScore/riskScore/signalScore) —
 *    ранжирование КАНДИДАТОВ, которые уже прошли жёсткие фильтры. Это НЕ
 *    реконструкция стратегии наблюдаемого бота (см. предупреждение в
 *    types/signal.ts) — это наша собственная, прозрачная эвристика,
 *    предназначенная для пересмотра на реальных данных backtest (Phase 11).
 *
 * Сторона (YES/NO) выбирается по наблюдению из reverse-engineering doc
 * (раздел 2 анализа): торгуется та сторона, чей ask уже находится в
 * "почти решённом" диапазоне [ENTRY_MIN, ENTRY_MAX] — не хардкодим NO.
 */

export interface SignalEngineConfig {
  entryMin: number;
  entryMax: number;
  exitTarget: number;
  minNetProfitPct: number;
  feeRateBps: number;
  slippageBufferPct: number;
  minLiquidityUsd: number;
  minTimeToResolutionMs: number;
  maxTimeToResolutionMs: number;
  orderbookMaxAgeMs: number;
}

export class EntrySignalEngine {
  constructor(private readonly cfg: SignalEngineConfig) {}

  evaluateMarket(market: ScannedWeatherMarket): EntrySignal[] {
    if (!market.classification.tradableByCurrentStrategy) {
      // Не temperature market — раздел 6 ТЗ: v1 стратегии не торгует этим.
      return [];
    }

    const signals: EntrySignal[] = [];
    if (market.yes) signals.push(this.evaluateSide(market, market.yes));
    if (market.no) signals.push(this.evaluateSide(market, market.no));

    // Возвращаем только сигналы, где entryPrice вообще был доступен ИЛИ где
    // причина отказа информативна (для observe mode / reason). Полностью
    // пустые (нет вообще ask) не отбрасываем — это тоже полезный "reason".
    return signals;
  }

  private evaluateSide(market: ScannedWeatherMarket, quote: TokenQuote): EntrySignal {
    const reasons: NoTradeReason[] = [];

    if (!market.classification.tradableByCurrentStrategy) {
      reasons.push("MARKET_NOT_TRADABLE_TYPE");
    }

    const isStale = quote.bookAgeMs > this.cfg.orderbookMaxAgeMs;
    if (isStale) reasons.push("ORDERBOOK_STALE");

    const entryPrice = quote.bestAsk; // покупаем по ask
    if (entryPrice === null) {
      reasons.push("NO_ASK_LIQUIDITY");
    } else if (entryPrice < this.cfg.entryMin || entryPrice > this.cfg.entryMax) {
      reasons.push("PRICE_OUTSIDE_ENTRY_RANGE");
    }

    const availableLiquidity = entryPrice !== null && quote.askSize !== null ? entryPrice * quote.askSize : null;
    if (availableLiquidity === null || availableLiquidity < this.cfg.minLiquidityUsd) {
      reasons.push("INSUFFICIENT_LIQUIDITY");
    }

    const ttr = market.timeToResolutionMs;
    if (ttr === null || ttr < this.cfg.minTimeToResolutionMs || ttr > this.cfg.maxTimeToResolutionMs) {
      reasons.push("TIME_TO_RESOLUTION_OUT_OF_RANGE");
    }

    const targetPrice = this.cfg.exitTarget;
    const spread = entryPrice !== null ? targetPrice - entryPrice : null;
    const expectedProfitPerShare = spread; // gross, per 1 share @ $1 notional scale

    let expectedNetProfitPerShare: number | null = null;
    let expectedNetProfitPct: number | null = null;
    if (entryPrice !== null && spread !== null) {
      // Round-trip fee approximation: комиссия применяется и на входе, и на
      // выходе, каждая как fee_rate_bps от notional соответствующей ноги.
      // FEE_RATE_BPS=0 по умолчанию (см. env.ts) — текущая практика CLOB,
      // но конфигурируемо, если конкретный рынок берёт комиссию.
      const feeCost = (entryPrice + targetPrice) * (this.cfg.feeRateBps / 10_000);
      const slippageCost = entryPrice * this.cfg.slippageBufferPct;
      expectedNetProfitPerShare = spread - feeCost - slippageCost;
      expectedNetProfitPct = expectedNetProfitPerShare / entryPrice;

      if (expectedNetProfitPct < this.cfg.minNetProfitPct) {
        reasons.push("NET_EDGE_TOO_LOW");
      }
    } else {
      reasons.push("NET_EDGE_TOO_LOW");
    }

    const decision = reasons.length === 0 ? "BUY_CANDIDATE" : "NO_TRADE";

    // --- Мягкие скоры (только осмысленны, если entryPrice известен) ---
    let confidenceScore: number | null = null;
    let riskScore: number | null = null;
    let marketScore: number | null = null;
    let signalScore: number | null = null;

    if (entryPrice !== null) {
      // confidenceScore: proxy "насколько рынок уже почти решён" = сама цена,
      // отмасштабированная в 0-100. Чем ближе к 1.0, тем выше уверенность.
      confidenceScore = clamp(entryPrice * 100, 0, 100);

      // riskScore: выше = рискованнее. Штрафуем за:
      //   - долгое время до резолюции (больше шансов на разворот погоды);
      //   - тонкий net edge относительно buffer'ов (легко уйти в минус);
      //   - устаревший orderbook.
      const timeRiskComponent =
        ttr !== null
          ? clamp((ttr / this.cfg.maxTimeToResolutionMs) * 100, 0, 100)
          : 100; // неизвестное время = максимальный риск
      const edgeRiskComponent =
        expectedNetProfitPct !== null
          ? clamp(100 - (expectedNetProfitPct / (this.cfg.minNetProfitPct * 5)) * 100, 0, 100)
          : 100;
      const staleRiskComponent = isStale ? 100 : 0;
      riskScore = clamp(timeRiskComponent * 0.4 + edgeRiskComponent * 0.4 + staleRiskComponent * 0.2, 0, 100);

      // marketScore: ликвидность важна независимо от текущей цены —
      // рынок с глубоким стаканом надёжнее исполняется.
      const liquidityScore =
        availableLiquidity !== null
          ? clamp((availableLiquidity / (this.cfg.minLiquidityUsd * 5)) * 100, 0, 100)
          : 0;
      marketScore = liquidityScore;

      // signalScore: композит для ранжирования кандидатов, прошедших жёсткие
      // фильтры. Веса — наш выбор, не выведены из данных, подлежат
      // пересмотру на backtest (Phase 11).
      signalScore = clamp(confidenceScore * 0.4 + (100 - riskScore) * 0.4 + marketScore * 0.2, 0, 100);
    }

    return {
      marketId: market.marketId,
      conditionId: market.conditionId,
      question: market.question,
      tokenId: quote.tokenId,
      outcome: quote.outcome,
      entryPrice,
      targetPrice,
      spread,
      availableLiquidity,
      expectedProfitPerShare,
      expectedNetProfitPerShare,
      expectedNetProfitPct,
      timeToResolutionMs: ttr,
      marketScore,
      confidenceScore,
      riskScore,
      signalScore,
      decision,
      reasons,
    };
  }
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}
