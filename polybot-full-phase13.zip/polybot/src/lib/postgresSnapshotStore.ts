import type pg from "pg";
import type { MarketSnapshot } from "../types/market.js";
import type { SnapshotStore } from "./snapshotStore.js";

/**
 * Реализация SnapshotStore поверх PostgreSQL — как и обещано в README Phase 6:
 * OrderbookCollector и всё, что его использует, не нуждается в изменениях,
 * потому что интерфейс тот же самый, что у JsonlSnapshotStore.
 *
 * Дополнительно апсертит запись в `markets` (раздел 27 ТЗ — markets и
 * market_snapshots это разные таблицы: markets — текущее состояние/метаданные,
 * market_snapshots — история).
 */
export class PostgresSnapshotStore implements SnapshotStore {
  constructor(private readonly pool: pg.Pool) {}

  async save(snapshot: MarketSnapshot): Promise<void> {
    await this.saveMany([snapshot]);
  }

  async saveMany(snapshots: MarketSnapshot[]): Promise<void> {
    if (snapshots.length === 0) return;

    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");

      // Upsert markets (по одному market_id может быть несколько snapshot'ов
      // в этом батче — де-дублицируем перед upsert).
      const marketsById = new Map<string, MarketSnapshot>();
      for (const s of snapshots) marketsById.set(s.marketId, s);

      for (const s of marketsById.values()) {
        await client.query(
          `INSERT INTO markets (market_id, condition_id, question, kind, last_seen_at)
           VALUES ($1, $2, $3, $4, now())
           ON CONFLICT (market_id) DO UPDATE SET
             question = EXCLUDED.question,
             kind = EXCLUDED.kind,
             last_seen_at = now()`,
          [s.marketId, s.conditionId, s.question, s.kind]
        );
      }

      for (const s of snapshots) {
        await client.query(
          `INSERT INTO market_snapshots
             (ts, market_id, token_id, outcome, best_bid, best_ask, midpoint, spread,
              available_bid_size, available_ask_size, volume, time_to_resolution_ms, book_age_ms, stale)
           VALUES (to_timestamp($1/1000.0), $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
          [
            s.timestamp,
            s.marketId,
            s.tokenId,
            s.outcome,
            s.bestBid,
            s.bestAsk,
            s.midpoint,
            s.spread,
            s.availableBidSize,
            s.availableAskSize,
            s.volumeNum,
            s.timeToResolutionMs,
            s.bookAgeMs,
            s.stale,
          ]
        );
      }

      await client.query("COMMIT");
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
  }

  async loadAll(): Promise<MarketSnapshot[]> {
    const { rows } = await this.pool.query(
      `SELECT s.ts, s.market_id, s.token_id, s.outcome, s.best_bid, s.best_ask, s.midpoint, s.spread,
              s.available_bid_size, s.available_ask_size, s.volume, s.time_to_resolution_ms, s.book_age_ms, s.stale,
              m.question, m.kind
       FROM market_snapshots s
       JOIN markets m ON m.market_id = s.market_id
       ORDER BY s.ts`
    );

    return rows.map((r) => ({
      timestamp: new Date(r.ts).getTime(),
      marketId: r.market_id,
      conditionId: "", // не хранится в market_snapshots напрямую, см. markets.condition_id при необходимости
      question: r.question,
      kind: r.kind,
      tokenId: r.token_id,
      outcome: r.outcome,
      bestBid: r.best_bid !== null ? Number(r.best_bid) : null,
      bestAsk: r.best_ask !== null ? Number(r.best_ask) : null,
      midpoint: r.midpoint !== null ? Number(r.midpoint) : null,
      spread: r.spread !== null ? Number(r.spread) : null,
      availableBidSize: r.available_bid_size !== null ? Number(r.available_bid_size) : null,
      availableAskSize: r.available_ask_size !== null ? Number(r.available_ask_size) : null,
      volumeNum: r.volume !== null ? Number(r.volume) : null,
      timeToResolutionMs: r.time_to_resolution_ms !== null ? Number(r.time_to_resolution_ms) : null,
      bookAgeMs: r.book_age_ms,
      stale: r.stale,
    }));
  }
}
