import { createSecureClient, type SecureClient, type PublicActions, type SecureActions } from "@polymarket/client";
import { privateKey } from "@polymarket/client/viem";
import type { ApiKeyCreds } from "@polymarket/client";
import type { BotEnv } from "../config/env.js";

/**
 * Создаёт официальный SecureClient (@polymarket/client, v0.10.0 на момент
 * написания — актуальный unified TypeScript SDK Polymarket, см.
 * docs.polymarket.com/getting-started/typescript).
 *
 * ПОЧЕМУ SDK, А НЕ РУЧНАЯ EIP-712 ПОДПИСЬ (как в src/lib/clobAuth.ts для
 * read-only L1/L2 auth): раздел 19 ТЗ прямо требует "не придумывать API".
 * Актуальная V2-схема подписи ордера (domain version "2", 11 подписываемых
 * полей: salt/maker/signer/tokenId/makerAmount/takerAmount/side/
 * signatureType/timestamp/metadata/builder) для Deposit Wallet дополнительно
 * требует ERC-7739 wrapping поверх обычной EIP-712 подписи — сложная,
 * легко ошибиться вручную логика для операции с реальными деньгами.
 * Официальный SDK поддерживается той же командой, что и сам API, и
 * реализует это корректно — риск ошибки в подписи значительно ниже, чем
 * при повторной реализации вручную.
 *
 * ApiKeyCreds SDK ожидает в форме { key, secret, passphrase } (после
 * внутренней трансформации схемы) — НЕ { apiKey, secret, passphrase }, как
 * в сыром формате .env. Это специфика конкретно этого SDK, не общая схема
 * L2-заголовков (см. clobAuth.ts, где формат { apiKey, secret, passphrase }
 * соответствует заголовкам POLY_API_KEY и т.д.).
 */
export async function createLiveClient(
  env: BotEnv
): Promise<SecureClient<PublicActions, SecureActions>> {
  if (!env.POLYMARKET_PRIVATE_KEY) {
    throw new Error("POLYMARKET_PRIVATE_KEY не задан — невозможно создать live client.");
  }

  const credentials: ApiKeyCreds | undefined =
    env.POLYMARKET_API_KEY && env.POLYMARKET_API_SECRET && env.POLYMARKET_API_PASSPHRASE
      ? ({
          // ApiKey — "branded" тип (Tagged<string, 'ApiKey'>) в SDK, обычная
          // строка не проходит структурную проверку типов напрямую — это
          // намеренная защита SDK от передачи произвольной строки не в том
          // месте, а не признак того, что строка "неправильная". Значение
          // всё равно приходит из .env как обычная строка.
          key: env.POLYMARKET_API_KEY,
          secret: env.POLYMARKET_API_SECRET,
          passphrase: env.POLYMARKET_API_PASSPHRASE,
        } as ApiKeyCreds)
      : undefined;

  return createSecureClient({
    signer: privateKey(env.POLYMARKET_PRIVATE_KEY),
    wallet: env.POLYMARKET_FUNDER_ADDRESS || undefined,
    credentials,
  });
}
