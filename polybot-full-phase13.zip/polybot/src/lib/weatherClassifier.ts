import type { WeatherClassification, WeatherMarketKind } from "../types/market.js";

/**
 * Классификация построена на тексте `question` из Gamma API, а НЕ на Gamma
 * tags/tag_id — потому что таксономия тегов Polymarket не документирована
 * достаточно надёжно для weather-подкатегорий (highest/lowest/range) и может
 * отличаться от инстанса к инстансу. Текст вопроса — единственный источник,
 * стабильность которого мы можем проверить прямо сейчас (см. 14 наблюдаемых
 * сделок — все имеют однотипную формулировку).
 *
 * Наблюдаемые в задаче формулировки (дословно):
 *   "Will the lowest temperature in <City> be between X-Y°F on <Date>?"
 *   "Will the lowest temperature in <City> be X°C or higher on <Date>?"
 *   "Will the highest temperature in <City> be X°C on <Date>?"
 *   "Will the lowest temperature in <City> be X°C on <Date>?"
 *
 * Паттерны ниже покрывают именно эти формы. Rain/precipitation/snow/wind/
 * humidity детектируются по ключевым словам на уровне "это weather market",
 * но НЕ парсятся в структурированные threshold — это осознанно оставлено
 * как `tradableByCurrentStrategy: false`, потому что раздел 6 ТЗ явно говорит:
 * "первоначальная стратегия должна работать именно с temperature markets".
 */

const TEMP_RANGE_RE =
  /will the (lowest|highest) temperature in ([a-zA-Z .'-]+?) be between\s*(-?\d+(?:\.\d+)?)\s*-\s*(-?\d+(?:\.\d+)?)\s*°?\s*([fc])/i;

const TEMP_THRESHOLD_RE =
  /will the (lowest|highest) temperature in ([a-zA-Z .'-]+?) be\s*(-?\d+(?:\.\d+)?)\s*°?\s*([fc])\s*(or higher|or above|or below|or lower)?/i;

const RAIN_KEYWORDS = /\brain\b/i;
const PRECIP_KEYWORDS = /\bprecipitation\b/i;
const SNOW_KEYWORDS = /\bsnow(fall)?\b/i;
const WIND_KEYWORDS = /\bwind(speed| speed)?\b/i;
const HUMIDITY_KEYWORDS = /\bhumidity\b/i;
const GENERIC_WEATHER_HINT = /\btemperature\b|\bweather\b/i;

export function classifyWeatherMarket(question: string): WeatherClassification {
  const q = question.trim();

  const rangeMatch = q.match(TEMP_RANGE_RE);
  if (rangeMatch) {
    const [, direction, city, lowStr, highStr, unit] = rangeMatch;
    return {
      isWeather: true,
      kind: "temperature_range",
      city: city?.trim() ?? null,
      threshold: {
        low: lowStr !== undefined ? Number(lowStr) : null,
        high: highStr !== undefined ? Number(highStr) : null,
        unit: (unit?.toUpperCase() as "F" | "C") ?? null,
      },
      tradableByCurrentStrategy: true,
    };
  }

  const thresholdMatch = q.match(TEMP_THRESHOLD_RE);
  if (thresholdMatch) {
    const [, direction, city, valStr, unit, qualifier] = thresholdMatch;
    const value = valStr !== undefined ? Number(valStr) : null;
    const isOrHigher = qualifier ? /higher|above/i.test(qualifier) : false;
    const isOrLower = qualifier ? /lower|below/i.test(qualifier) : false;

    const kind: WeatherMarketKind =
      direction?.toLowerCase() === "highest" ? "temperature_highest" : "temperature_lowest";

    return {
      isWeather: true,
      kind,
      city: city?.trim() ?? null,
      threshold: {
        low: isOrHigher ? value : isOrLower ? null : value,
        high: isOrLower ? value : isOrHigher ? null : value,
        unit: (unit?.toUpperCase() as "F" | "C") ?? null,
      },
      tradableByCurrentStrategy: true,
    };
  }

  if (RAIN_KEYWORDS.test(q)) {
    return unclassifiedWeather("rain");
  }
  if (PRECIP_KEYWORDS.test(q)) {
    return unclassifiedWeather("precipitation");
  }
  if (SNOW_KEYWORDS.test(q)) {
    return unclassifiedWeather("snow");
  }
  if (WIND_KEYWORDS.test(q)) {
    return unclassifiedWeather("wind");
  }
  if (HUMIDITY_KEYWORDS.test(q)) {
    return unclassifiedWeather("humidity");
  }
  if (GENERIC_WEATHER_HINT.test(q)) {
    return {
      isWeather: true,
      kind: "unknown_weather",
      city: null,
      threshold: { low: null, high: null, unit: null },
      tradableByCurrentStrategy: false,
    };
  }

  return {
    isWeather: false,
    kind: null,
    city: null,
    threshold: { low: null, high: null, unit: null },
    tradableByCurrentStrategy: false,
  };
}

function unclassifiedWeather(kind: WeatherMarketKind): WeatherClassification {
  return {
    isWeather: true,
    kind,
    city: null,
    threshold: { low: null, high: null, unit: null },
    // Явно НЕ торгуем этими типами в первой версии стратегии (раздел 6 ТЗ):
    // детектируем, логируем, но сигналы не генерируем, пока не будет отдельного
    // reverse-engineering для этих типов рынков.
    tradableByCurrentStrategy: false,
  };
}
