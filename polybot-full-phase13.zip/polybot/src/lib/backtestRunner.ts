import type { MarketSnapshot, ScannedWeatherMarket, TokenQuote } from "../types/market.js";
import type { PaperState } from "../types/paperTrading.js";
import type { BacktestParams, BacktestResult } from "../types/backtest.js";
import { classifyWeatherMarket } from "./weatherClassifier.js";
import { EntrySignalEngine, type SignalEngineConfig } from "./entrySignalEngine.js";
import { PositionSizer, type PositionSizerConfig } from "./positionSizer.js";
import { PaperTradingEngine, type PaperEngineConfig } from "./paperTradingEngine.js";

/**
 * BacktestRunner (Phase 11 ТЗ, раздел 36).
 *
 * ПРИНЦИПИАЛЬНОЕ РЕШЕНИЕ: backtest использует РОВНО ТЕ ЖЕ КЛАССЫ, что и paper
 * trading (Phase 9) — EntrySignalEngine, PositionSizer, PaperTradingEngine.
 * Не отдельная "облегчённая" реализация стратегии для бэктеста, которая
 * могла бы разойтись с тем, что реально исполняется в paper/live — риск,
 * прямо запрещённый духом раздела 39 ТЗ ("корректно исполнять orders" важнее,
 * чем красивый бэктест на несовместимой логике).
 *
 * Единственное новое здесь — группировка исторических MarketSnapshot в
 * "циклы" (эмуляция того, что видел бы OrderbookCollector в реальном
 * времени) и прогон через runCycle() в хронологическом порядке.
 *
 * ОГРАНИЧЕНИЕ (честно): snapshot'ы не хранят явный cycle_id (в схеме БД его
 * нет — см. db/schema.sql). Группировка по времени — приближение
 * (BACKTEST_CYCLE_BUCKET_MS), а не точное восстановление реальных циклов
 * сканера. Для более точного бэктеста в будущем стоит добавить cycle_id в
 * market_snapshots.
 */

export function groupSnapshotsIntoCycles(
  snapshots: MarketSnapshot[],
  bucketMs: number
): MarketSnapshot[][] {
  const byBucket = new Map<number, MarketSnapshot[]>();
  for (const s of snapshots) {
    const bucket = Math.floor(s.timestamp / bucketMs);
    const arr = byBucket.get(bucket) ?? [];
    arr.push(s);
    byBucket.set(bucket, arr);
  }
  return [...byBucket.entries()].sort((a, b) => a[0] - b[0]).map(([, v]) => v);
}

export function snapshotsToScannedMarkets(cycleSnapshots: MarketSnapshot[]): ScannedWeatherMarket[] {
  const byMarket = new Map<string, MarketSnapshot[]>();
  for (const s of cycleSnapshots) {
    const arr = byMarket.get(s.marketId) ?? [];
    arr.push(s);
    byMarket.set(s.marketId, arr);
  }

  const result: ScannedWeatherMarket[] = [];
  for (const [marketId, snaps] of byMarket) {
    const first = snaps[0]!;
    const yesSnap = snaps.find((s) => s.outcome === "YES");
    const noSnap = snaps.find((s) => s.outcome === "NO");

    result.push({
      marketId,
      conditionId: "", // не хранится в market_snapshots (см. ограничение postgresSnapshotStore.ts)
      question: first.question,
      slug: "",
      classification: classifyWeatherMarket(first.question),
      endDate: null,
      timeToResolutionMs: first.timeToResolutionMs,
      active: true,
      closed: false,
      liquidityNum: null,
      volumeNum: first.volumeNum,
      yes: yesSnap ? snapshotToQuote(yesSnap) : null,
      no: noSnap ? snapshotToQuote(noSnap) : null,
    });
  }
  return result;
}

function snapshotToQuote(s: MarketSnapshot): TokenQuote {
  return {
    tokenId: s.tokenId,
    outcome: s.outcome,
    bestBid: s.bestBid,
    bestAsk: s.bestAsk,
    midpoint: s.midpoint,
    spread: s.spread,
    bidSize: s.availableBidSize,
    askSize: s.availableAskSize,
    bookAgeMs: s.bookAgeMs,
  };
}

export interface BacktestRunnerConfig {
  signalEngine: SignalEngineConfig;
  positionSizer: PositionSizerConfig;
  paperEngine: PaperEngineConfig;
  startingBalanceUsd: number;
  cycleBucketMs: number;
  /** Ниже этого числа уникальных дней в выборке — явное предупреждение про overfitting. */
  minDistinctDaysForConfidence: number;
}

export class BacktestRunner {
  constructor(private readonly cfg: BacktestRunnerConfig) {}

  async run(allSnapshots: MarketSnapshot[]): Promise<BacktestResult> {
    const signalEngine = new EntrySignalEngine(this.cfg.signalEngine);
    const sizer = new PositionSizer(this.cfg.positionSizer);
    const paperEngine = new PaperTradingEngine(sizer, this.cfg.paperEngine);

    const cycles = groupSnapshotsIntoCycles(allSnapshots, this.cfg.cycleBucketMs);

    let state: PaperState = {
      cashBalanceUsd: this.cfg.startingBalanceUsd,
      startingBalanceUsd: this.cfg.startingBalanceUsd,
      openPositions: [],
      closedTrades: [],
      lastUpdated: Date.now(),
    };

    const equityCurve: number[] = [];

    for (const cycleSnapshots of cycles) {
      const markets = snapshotsToScannedMarkets(cycleSnapshots);
      const signals = markets.flatMap((m) => signalEngine.evaluateMarket(m));
      const buyCandidates = signals.filter((s) => s.decision === "BUY_CANDIDATE");

      const { state: newState, summary } = await paperEngine.runCycle(state, markets, buyCandidates);
      state = newState;

      equityCurve.push(summary.cashBalanceUsd + summary.totalExposureUsd + summary.unrealizedPnlUsd);
    }

    const { maxDrawdownUsd, maxDrawdownPct } = computeMaxDrawdown(equityCurve, this.cfg.startingBalanceUsd);

    const wins = state.closedTrades.filter((t) => t.netProfit > 0).length;
    const losses = state.closedTrades.filter((t) => t.netProfit <= 0).length;
    const grossPnlUsd = state.closedTrades.reduce((s, t) => s + t.grossProfit, 0);
    const feesUsd = state.closedTrades.reduce((s, t) => s + t.fees, 0);
    const netPnlUsd = state.closedTrades.reduce((s, t) => s + t.netProfit, 0);

    const distinctDays = new Set(allSnapshots.map((s) => new Date(s.timestamp).toISOString().slice(0, 10))).size;

    const overfitWarning =
      distinctDays < this.cfg.minDistinctDaysForConfidence
        ? `Выборка покрывает только ${distinctDays} день(дня) — раздел 37 ТЗ прямо запрещает выбирать параметры ` +
          `только потому, что они лучше всего совпадают с такой маленькой выборкой. Результаты этого прогона ` +
          `НЕ следует использовать для выбора финальных параметров без out-of-sample проверки на большем периоде.`
        : null;

    return {
      params: {
        entryMin: this.cfg.signalEngine.entryMin,
        entryMax: this.cfg.signalEngine.entryMax,
        exitTarget: this.cfg.signalEngine.exitTarget,
        positionSizingModel: this.cfg.positionSizer.model,
      },
      cyclesProcessed: cycles.length,
      distinctDaysCovered: distinctDays,
      tradesCount: state.closedTrades.length,
      wins,
      losses,
      winRate: state.closedTrades.length > 0 ? wins / state.closedTrades.length : null,
      grossPnlUsd,
      feesUsd,
      netPnlUsd,
      maxDrawdownUsd,
      maxDrawdownPct,
      finalEquityUsd: equityCurve.length > 0 ? equityCurve[equityCurve.length - 1]! : this.cfg.startingBalanceUsd,
      equityCurve,
      trades: state.closedTrades,
      overfitWarning,
    };
  }
}

export function computeMaxDrawdown(
  equityCurve: number[],
  startingEquity: number
): { maxDrawdownUsd: number; maxDrawdownPct: number } {
  let peak = startingEquity;
  let maxDrawdownUsd = 0;
  let maxDrawdownPct = 0;

  for (const equity of equityCurve) {
    if (equity > peak) peak = equity;
    const drawdownUsd = peak - equity;
    // % считается от пика НА МОМЕНТ этой конкретной просадки, а не от
    // итогового пика по всей кривой — иначе просадка задним числом
    // "разбавляется" более поздним ростом, которого в момент просадки ещё
    // не было.
    const drawdownPct = peak > 0 ? drawdownUsd / peak : 0;
    if (drawdownUsd > maxDrawdownUsd) maxDrawdownUsd = drawdownUsd;
    if (drawdownPct > maxDrawdownPct) maxDrawdownPct = drawdownPct;
  }

  return { maxDrawdownUsd, maxDrawdownPct };
}
