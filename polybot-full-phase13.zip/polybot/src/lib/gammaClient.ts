import type { BotEnv } from "../config/env.js";

/**
 * Gamma API — публичный, авторизация не требуется.
 * https://gamma-api.polymarket.com
 * Используется для discovery рынков и метаданных (resolution date, вопрос, токены).
 */

export interface GammaMarket {
  id: string;
  question: string;
  slug: string;
  conditionId: string;
  clobTokenIds?: string; // JSON-строка вида '["yesTokenId","noTokenId"]'
  outcomes?: string; // JSON-строка вида '["Yes","No"]'
  endDate?: string;
  closed?: boolean;
  active?: boolean;
  liquidity?: string;
  volume?: string;
  [key: string]: unknown;
}

export class GammaClient {
  constructor(private readonly baseUrl: string) {}

  async listMarkets(params: Record<string, string | number | boolean> = {}): Promise<GammaMarket[]> {
    const url = new URL("/markets", this.baseUrl);
    for (const [k, v] of Object.entries(params)) url.searchParams.set(k, String(v));

    const res = await fetch(url, { method: "GET" });
    if (!res.ok) {
      throw new Error(`Gamma /markets вернул ${res.status}: ${await res.text()}`);
    }
    return (await res.json()) as GammaMarket[];
  }
}

export function createGammaClient(env: BotEnv): GammaClient {
  return new GammaClient(env.GAMMA_API_URL);
}
