import type { EntrySignal } from "../types/signal.js";
import type {
  PositionSizingContext,
  PositionSizingModel,
  PositionSizingResult,
  SizingCapReason,
} from "../types/positionSizing.js";

/**
 * PositionSizer (Phase 8 ТЗ, раздел 5 + 30).
 *
 * ЧЕСТНАЯ ОТПРАВНАЯ ТОЧКА: docs/strategy-reverse-engineering.md прямо
 * констатирует "Insufficient data to identify exact position sizing" по
 * наблюдаемым 14 сделкам. Модели A/B/E статистически неотличимы друг от
 * друга и не объясняют разброс notional в 27× при entry_price в узком
 * диапазоне. Модель C (spread-proportional) даёт слабое соответствие.
 * Модель D (liquidity-proportional) правдоподобна, но НЕ проверяема без
 * orderbook snapshot на момент исторических сделок.
 *
 * Поэтому: все 6 моделей реализованы как переключаемые стратегии
 * (`POSITION_SIZING_MODEL`), но дефолт — Model A (`fixed_usd`), самая
 * консервативная и единственная, которую не нужно "верить" — она buy делает
 * ровно то, что сконфигурировано, без скрытых предположений о рынке.
 *
 * ЖЁСТКИЕ RISK-CAPS (раздел 30-31 ТЗ) применяются ПОСЛЕ модели и НЕЗАВИСИМО
 * от того, какая модель выбрана — они не являются частью "гипотезы о
 * стратегии", это защита капитала:
 *   - MAX_POSITION_USD — абсолютный потолок на одну позицию;
 *   - MAX_LIQUIDITY_USAGE — не более X% доступной ask-ликвидности (раздел 14);
 *   - MAX_TOTAL_EXPOSURE — не более X суммарной экспозиции по всем позициям;
 *   - MAX_MARKET_EXPOSURE — не более X на одном рынке;
 *   - available capital — нельзя купить больше, чем есть свободных средств;
 *   - duplicate position — раздел 16: если уже есть открытая позиция на этом
 *     market+token и ALLOW_POSITION_SCALING=false, размер = 0.
 */

export interface PositionSizerConfig {
  model: PositionSizingModel;
  fixedPositionUsd: number;
  positionPctCapital: number;
  liquiditySizingFactor: number;
  spreadSizingReference: number;
  edgeSizingReferencePct: number;
  hybridLiquidityWeight: number;

  maxPositionUsd: number;
  maxLiquidityUsage: number;
  maxTotalExposureUsd: number;
  maxMarketExposureUsd: number;
  allowPositionScaling: boolean;
}

export class PositionSizer {
  constructor(private readonly cfg: PositionSizerConfig) {}

  size(signal: EntrySignal, ctx: PositionSizingContext): PositionSizingResult {
    const appliedCaps: SizingCapReason[] = [];

    // --- Duplicate position check (раздел 16) — блокирует ДО расчёта модели ---
    if (ctx.hasExistingOpenPosition && !this.cfg.allowPositionScaling) {
      return {
        model: this.cfg.model,
        rawNotionalUsd: 0,
        finalNotionalUsd: 0,
        finalShares: 0,
        appliedCaps: ["DUPLICATE_POSITION_BLOCKED"],
        blocked: true,
      };
    }

    if (signal.entryPrice === null) {
      return {
        model: this.cfg.model,
        rawNotionalUsd: 0,
        finalNotionalUsd: 0,
        finalShares: 0,
        appliedCaps: [],
        blocked: true,
      };
    }

    const rawNotionalUsd = this.computeRaw(signal, ctx);

    // --- Применяем caps последовательно, фиксируя, какие реально сработали ---
    let notional = rawNotionalUsd;

    if (notional > this.cfg.maxPositionUsd) {
      notional = this.cfg.maxPositionUsd;
      appliedCaps.push("MAX_POSITION_USD");
    }

    if (signal.availableLiquidity !== null) {
      const liquidityCap = signal.availableLiquidity * this.cfg.maxLiquidityUsage;
      if (notional > liquidityCap) {
        notional = liquidityCap;
        appliedCaps.push("MAX_LIQUIDITY_USAGE");
      }
    }

    const remainingTotalBudget = this.cfg.maxTotalExposureUsd - ctx.currentTotalExposureUsd;
    if (notional > remainingTotalBudget) {
      notional = Math.max(0, remainingTotalBudget);
      appliedCaps.push("MAX_TOTAL_EXPOSURE");
    }

    const remainingMarketBudget = this.cfg.maxMarketExposureUsd - ctx.currentMarketExposureUsd;
    if (notional > remainingMarketBudget) {
      notional = Math.max(0, remainingMarketBudget);
      appliedCaps.push("MAX_MARKET_EXPOSURE");
    }

    if (notional > ctx.availableCapitalUsd) {
      notional = Math.max(0, ctx.availableCapitalUsd);
      appliedCaps.push("AVAILABLE_CAPITAL");
    }

    const finalNotionalUsd = Math.max(0, notional);
    const finalShares = finalNotionalUsd > 0 ? finalNotionalUsd / signal.entryPrice : 0;

    return {
      model: this.cfg.model,
      rawNotionalUsd,
      finalNotionalUsd,
      finalShares,
      appliedCaps,
      blocked: finalNotionalUsd <= 0,
    };
  }

  private computeRaw(signal: EntrySignal, ctx: PositionSizingContext): number {
    switch (this.cfg.model) {
      case "fixed_usd":
        // Model A: константа. Не зависит ни от чего — самая предсказуемая.
        return this.cfg.fixedPositionUsd;

      case "pct_capital":
        // Model B: доля свободного капитала. При постоянном капитале внутри
        // дня статистически неотличима от A (см. reverse-engineering doc).
        return ctx.availableCapitalUsd * this.cfg.positionPctCapital;

      case "spread_proportional": {
        // Model C: чем больше gross edge (targetPrice - entryPrice), тем
        // больше позиция. Слабое соответствие историческим данным — см. doc
        // (Paris spread 0.05/$136.75 vs Singapore spread 0.03/$269.91,
        // немонотонно). Оставлено как опция, не как рекомендация.
        const spread = signal.spread ?? 0;
        const scale = spread / this.cfg.spreadSizingReference;
        return this.cfg.fixedPositionUsd * scale;
      }

      case "liquidity_proportional": {
        // Model D: пропорционально доступной ликвидности на этом токене.
        // Правдоподобная гипотеза, но НЕ проверена на исторических данных
        // (нет orderbook snapshot на момент тех 14/49 сделок). Обратите
        // внимание: это ОТДЕЛЬНЫЙ коэффициент (LIQUIDITY_SIZING_FACTOR) от
        // жёсткого MAX_LIQUIDITY_USAGE cap, который применяется всегда,
        // независимо от модели.
        const liquidity = signal.availableLiquidity ?? 0;
        return liquidity * this.cfg.liquiditySizingFactor;

      }

      case "edge_proportional": {
        // Model E: пропорционально net edge. Поскольку target почти всегда
        // константа (0.99), net edge варьируется мало между сделками — эта
        // модель на практике вырождается в модель, близкую к A/B, что и
        // показал анализ (см. doc, вывод по Model E).
        const netPct = signal.expectedNetProfitPct ?? 0;
        const scale = netPct / this.cfg.edgeSizingReferencePct;
        return this.cfg.fixedPositionUsd * scale;
      }

      case "hybrid": {
        // Model F: взвешенная комбинация liquidity-proportional и fixed_usd.
        // Наиболее гибкая, но и наименее обоснованная без данных — вес
        // конфигурируем и должен пересматриваться на backtest (Phase 11).
        const liquidity = signal.availableLiquidity ?? 0;
        const liquidityComponent = liquidity * this.cfg.liquiditySizingFactor;
        const fixedComponent = this.cfg.fixedPositionUsd;
        const w = this.cfg.hybridLiquidityWeight;
        return liquidityComponent * w + fixedComponent * (1 - w);
      }
    }
  }
}
