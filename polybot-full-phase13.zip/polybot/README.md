# polybot — Phase 1-3: read-only фундамент

Это НЕ торговый бот (ещё). Это то, что было запрошено как "FIRST TASK":
актуальная архитектура + read-only клиент + диагностика аккаунта, прежде чем
писать хоть строчку торговой логики.

## Что сделано

1. **Исследована актуальная документация Polymarket CLOB V2** (2026 год,
   после миграции с legacy V1) — см. `docs/architecture.md`.
2. **Reverse engineering 14 наблюдаемых сделок** — см.
   `docs/strategy-reverse-engineering.md`. Честно помечено, что можно
   заключить, а что `UNKNOWN / CONFIGURABLE`.
3. **Read-only клиенты**: Gamma (discovery), CLOB (price/book/midpoint +
   L1/L2 auth для balance/orders), Data API (positions/trades).
4. **`npm run account`** — диагностика: signer address, funder address,
   баланс/allowance, открытые позиции, открытые ордера. **Ни при каких
   условиях не создаёт и не отменяет ордера.**
5. **`npm run geocheck`** — проверка гео-ограничений по текущему IP.

## Установка

```bash
npm install
cp .env.example .env
# заполните .env своими данными — см. комментарии в .env.example
```

## Обязательно перед первым запуском

- `POLYMARKET_PRIVATE_KEY` — приватный ключ signer'а. **Никогда не коммитьте
  `.env`**, он в `.gitignore`.
- `POLYMARKET_FUNDER_ADDRESS` — адрес, где реально лежат ваши средства.
  Для EOA/MetaMask обычно совпадает с адресом ключа. Для email/Magic-логина
  или браузерного прокси-кошелька — это ДРУГОЙ адрес, возьмите его из
  интерфейса Polymarket (Profile → Deposit), не угадывайте.
- Запустите `npm run geocheck` с той сети/сервера, откуда бот будет
  торговать. Polymarket блокирует размещение ордеров (полностью или
  close-only) из ряда юрисдикций по IP — это ограничение может измениться,
  проверяйте `GET https://polymarket.com/api/geoblock` актуально на момент
  запуска, а не полагайтесь на список из документа.

## Запуск диагностики аккаунта

```bash
npm run account
```

Команда выведет:
- signer address и funder address;
- L2 API credentials (создаст/деривирует их через L1-подпись, если их ещё
  нет в `.env` — сохраните вывод в `.env`, чтобы не пересоздавать каждый раз);
- баланс и allowance (collateral);
- список открытых позиций;
- список открытых ордеров.

## Режимы бота (заложены в конфиг, движки ещё не реализованы)

- `BOT_MODE=observe` (по умолчанию) — сканирование и сигналы без сделок.
- `BOT_MODE=paper` — симуляция без реальных ордеров.
- `BOT_MODE=live` — реальные ордера. Требует `LIVE_CONFIRM=true` и в
  будущей реализации — интерактивное подтверждение вводом слова `LIVE`.
  **На этом этапе `live`-логика вообще не реализована — она появится только
  после backtest → paper → observe, как явно указано в исходном ТЗ.**

## Phase 4-5: MarketScanner + weather-классификатор

```bash
npm run scan
```

Не требует credentials (Gamma + CLOB read — публичные). Делает:

1. Постранично тянет активные рынки Gamma (`active=true&closed=false`).
2. Классифицирует каждый по тексту `question` (`src/lib/weatherClassifier.ts`) —
   проверено на всех 9 уникальных формулировках из наблюдаемых 14 сделок,
   все распознаются корректно (`temperature_highest`, `temperature_lowest`,
   `temperature_range`).
3. Для рынков типа rain/precipitation/snow/wind/humidity — детектирует и
   логирует, но **не торгует ими** (`tradableByCurrentStrategy: false`),
   как явно требует раздел 6 исходного ТЗ ("первоначальная стратегия
   должна работать именно с temperature markets").
4. Для temperature-рынков забирает YES/NO token id и запрашивает свежий
   orderbook через `GET /book` — best bid/ask/midpoint/spread, а не last price
   (раздел 8 ТЗ).

Классификатор — по тексту вопроса, а не по Gamma tags: таксономия тегов
Polymarket недостаточно документирована для надёжного различения
highest/lowest/range на уровне тегов, тогда как формулировки вопросов
оказались единообразны на всех 14 наблюдаемых сделках.

**Ещё не реализовано (следующие фазы):** scoring/signal engine (Phase 7),
сохранение orderbook snapshot'ов в PostgreSQL (Phase 6/10 — сейчас всё
только в памяти процесса и теряется при перезапуске), order book imbalance
и recent trades (требуют `/trades` + историю).

## Phase 6: Orderbook collector

```bash
npm run collect
```

Периодически (`SCAN_INTERVAL_MS`, по умолчанию 30с) сканирует weather markets
и пишет snapshot каждого YES/NO токена в JSONL-файл
(`SNAPSHOTS_DIR/snapshots-<дата>.jsonl`) — формат ровно по разделу 28 ТЗ:
timestamp, market, token, best_bid, best_ask, midpoint, spread,
available_bid_size, available_ask_size, volume, time_to_resolution.

Каждый snapshot помечается `stale: true/false` по `ORDERBOOK_MAX_AGE_MS`
(раздел 8 ТЗ) — но **записывается в любом случае**, стейл-снимки тоже важны
для дальнейшего анализа "почему бот не вошёл в сделку".

Останавливается по `DATA_COLLECTION_HOURS` или Ctrl+C — уже записанное не
теряется. Это реализация `DATA_COLLECTION_MODE` из раздела 29 ТЗ: **только
запись, никакой торговли**.

**Почему JSONL, а не сразу PostgreSQL**: по исходному плану (раздел 40 ТЗ)
`Database` — это Phase 10, которая идёт ПОСЛЕ orderbook collector (Phase 6)
и paper trading (Phase 9). `SnapshotStore` — интерфейс с одной
JSONL-реализацией сейчас; PostgreSQL-реализация в Phase 10 будет
имплементировать тот же интерфейс, так что `OrderbookCollector` и будущий
backtest не потребуют переписывания.

## Phase 7: EntrySignalEngine

```bash
npm run signals
```

Реализует раздел 9 ТЗ: для каждого temperature-рынка (YES и NO по
отдельности) считает `entryPrice`, `targetPrice`, `spread`,
`availableLiquidity`, `expectedProfit`/`expectedNetProfit`,
`timeToResolution`, и скоры `marketScore`/`confidenceScore`/`riskScore`/
`signalScore`.

Архитектура — два слоя:

1. **Жёсткие фильтры** (`src/types/signal.ts` → `NoTradeReason`) — это прямые
   требования ТЗ, не эвристика: цена в `[ENTRY_MIN, ENTRY_MAX]`, orderbook не
   stale, есть ask-ликвидность, `availableLiquidity >= MIN_LIQUIDITY_USD`,
   чистый edge после комиссий/slippage `>= MIN_NET_PROFIT_PCT`,
   `timeToResolution` в допустимом окне. Любой провал → `NO_TRADE` с
   конкретной причиной (нужно для `reason` в будущем observe mode, раздел 24).
2. **Мягкие скоры** — **наша собственная эвристика для ранжирования**, а НЕ
   реконструкция логики наблюдаемого бота (это прямо помечено в коде и
   типах). Формулы прозрачны, веса — предположения, подлежат пересмотру на
   реальном backtest (Phase 11), когда появятся данные для калибровки.

Сторона (YES/NO) не хардкодится — берётся та, чей `bestAsk` уже находится в
диапазоне `[ENTRY_MIN, ENTRY_MAX]`, что соответствует выводу reverse-engineering
документа (раздел 2 анализа).

**Проверено юнит-тестами** на 4 синтетических кейсах: валидная сделка (аналог
реальной #6 из выборки, NO@0.97→0.99) проходит все фильтры; цена вне
диапазона (0.79, как во второй пачке из чата), stale orderbook и
недостаточная ликвидность — каждый корректно блокируется своим reason, при
этом скор всё равно считается (видно "почти прошёл, но...").

`npm run signals` — read-only превью: показывает BUY-кандидатов, отранжированных
по `signalScore`, и агрегированную статистику причин отказа. **Это ещё не
полноценный observe mode** (раздел 24 ТЗ) — там нужен ещё `recommended
quantity` от `PositionSizer` (Phase 8), которого пока нет.

## Phase 8: Position Sizing

`npm run signals` теперь показывает и `signalScore`, и рекомендованный размер
позиции (`recommended: $X (Y shares)`), используя `PositionSizer`
(`src/lib/positionSizer.ts`).

Реализованы все 6 моделей из раздела 5 ТЗ как переключаемые стратегии
(`POSITION_SIZING_MODEL`):

| Модель | env-значение | Что делает |
|---|---|---|
| A. Fixed USD | `fixed_usd` (дефолт) | Константа `FIXED_POSITION_USD` |
| B. % капитала | `pct_capital` | `availableCapital * POSITION_PCT_CAPITAL` |
| C. ∝ spread | `spread_proportional` | Слабо обосновано данными — см. doc |
| D. ∝ liquidity | `liquidity_proportional` | Правдоподобно, но не проверено на истории |
| E. ∝ edge | `edge_proportional` | Вырождается в A/B, т.к. target почти constant |
| F. Hybrid | `hybrid` | Взвешенная комбинация D и A |

**Дефолт — Model A (`fixed_usd`)**, самая консервативная, единственная, не
требующая веры в непроверенную гипотезу — прямое следствие вывода
reverse-engineering документа ("Insufficient data to identify exact position
sizing").

**Жёсткие risk-caps применяются ПОСЛЕ модели и независимо от неё**
(раздел 30-31 ТЗ) — это не часть гипотезы о стратегии, а защита капитала:
`MAX_POSITION_USD`, `MAX_LIQUIDITY_USAGE` (раздел 14, доля от доступной
ask-ликвидности), `MAX_TOTAL_EXPOSURE_USD`, `MAX_MARKET_EXPOSURE_USD`,
доступный капитал, и duplicate-position блокировка (раздел 16,
`ALLOW_POSITION_SCALING`).

**Проверено юнит-тестами**: все 6 моделей на одном сигнале дают разные, но
ожидаемые числа; каждый из 5 caps (`MAX_POSITION_USD`, `MAX_LIQUIDITY_USAGE`,
`MAX_TOTAL_EXPOSURE`, `MAX_MARKET_EXPOSURE`, `AVAILABLE_CAPITAL`) по
отдельности корректно урезает позицию и помечается в `appliedCaps`;
`DUPLICATE_POSITION_BLOCKED` блокирует размер до нуля при
`ALLOW_POSITION_SCALING=false` и корректно пропускает при `true`.

**Ограничение на этом этапе**: `npm run signals` считает sizing "с нуля"
(без реального учёта открытых позиций между запусками) — настоящий
position tracking появится в Phase 9 (paper trading), где позиции реально
хранятся между циклами.

## Phase 9: Paper Trading

```bash
# .env: BOT_MODE=paper (обязательно, иначе команда откажется работать)
npm run paper
```

Первая команда с реальной персистентностью между запусками
(`PAPER_STATE_FILE`, по умолчанию `./data/paper-state.json`) — то, чего не
хватало `npm run signals` (Phase 7-8), который каждый раз считал "с нуля".

Реализует раздел 23 ТЗ: `PaperTradingEngine` (`src/lib/paperTradingEngine.ts`)
симулирует:

- **order creation / partial fills** — заявка ограничена реальной глубиной
  стакана (askSize на входе, bidSize на выходе), раздел 18 ТЗ;
- **fees** — `FEE_RATE_BPS` от notional каждой ноги;
- **slippage** — исполнение хуже котировки на `SLIPPAGE_BUFFER_PCT`;
- **position** — агрегируется по market+token, может расти из нескольких
  fills при `ALLOW_POSITION_SCALING=true`;
- **exit** — по достижении `EXIT_TARGET` на bid, тоже частями, если не
  хватает bid-глубины;
- **PnL** — realized (по закрытым `PaperTrade`) и unrealized (по открытым
  позициям к текущему midpoint).

**Честно задокументированное упрощение**: это не полная симуляция очереди
ордеров. Неисполненный остаток заявки на ВХОД не "висит" до следующего
цикла — считается упущенной возможностью в этом цикле, а не зависшим
ордером. Остаток на ВЫХОД, наоборот, остаётся открытой позицией и снова
предлагается к продаже в следующем цикле — это соответствует наблюдаемому
паттерну (Munich: один BUY → пять SELL fills по мере появления bid-глубины).

**Проверено интеграционным тестом на 4 циклах**, воспроизводящим ровно
Munich-паттерн из ваших данных: BUY 100 запрошено → 60 исполнено (ask
depth=60, partial fill корректно зафиксирован); цикл без движения цены —
ничего не происходит; SELL партиями (20 затем 40) по мере появления
bid-глубины; после полного закрытия — gross profit = 60×(0.99−0.97) = **$1.20
ровно**, cash balance = $1001.20 (при FEE_RATE_BPS=0). Плюс отдельно
проверено, что состояние переживает создание нового `PaperStateStore`
(эмуляция перезапуска процесса) — записанный cash balance читается обратно
корректно, а не сбрасывается на стартовый.

`npm run typecheck` — чисто.

## Phase 10: Database (PostgreSQL)

```bash
# .env: DATABASE_URL=postgres://user:pass@localhost:5432/polybot
npm run db:migrate
npm run collect   # теперь автоматически пишет в PostgreSQL, а не в JSONL
```

`db/schema.sql` — все 13 таблиц из раздела 27 ТЗ: `markets`,
`market_snapshots`, `orderbook_snapshots`, `signals`, `orders`, `fills`,
`positions`, `trades`, `pnl`, `risk_events`, `bot_events`,
`strategy_parameters`, `backtest_runs`. Миграция идемпотентна
(`CREATE TABLE IF NOT EXISTS`) — безопасно запускать повторно.

**`PostgresSnapshotStore`** (`src/lib/postgresSnapshotStore.ts`) — вторая
реализация интерфейса `SnapshotStore`, заявленного ещё в Phase 6. `collect.ts`
теперь сам выбирает хранилище: PostgreSQL, если задан `DATABASE_URL`, иначе
JSONL-fallback — `OrderbookCollector` не потребовал ни единой правки, как и
было обещано.

**Реально протестировано на локальном PostgreSQL 16** (не только typecheck):
- `npm run db:migrate` создал все 13 таблиц на живой БД;
- round-trip тест `PostgresSnapshotStore`: запись двух snapshot'ов (один
  fresh, один stale) → чтение обратно → все поля (bestBid/bestAsk/stale/
  question) совпали;
- **в процессе теста нашёлся и был исправлен реальный баг**: `JOIN` между
  `market_snapshots` и `markets` вызывал `column reference "market_id" is
  ambiguous` — обе таблицы содержат эту колонку. Исправлено явной
  квалификацией `s.market_id`/`m.market_id` во всех полях `SELECT`.
- upsert в `markets` подтверждён (запись создаётся при первом snapshot,
  обновляется `last_seen_at` при повторных).

**Что пока НЕ перенесено в БД** (честно, не скрываю): `PaperStateStore`
(Phase 9) всё ещё пишет в один JSON-файл, а не в таблицы `positions`/`trades`/
`pnl`. Это осознанное упрощение на этом шаге — перенос paper-состояния в БД
не меняет логику `PaperTradingEngine`, только слой персистентности, и
будет сделан отдельно, когда понадобится (например, перед Phase 11
backtest, которому нужны исторические `trades` в БД для сравнения прогонов).

## Phase 11: Backtest

```bash
npm run backtest              # один прогон с текущими .env параметрами
BACKTEST_GRID=true npm run backtest   # grid search ENTRY_MIN × EXIT_TARGET
```

**Ключевое архитектурное решение**: `BacktestRunner` использует **ровно те
же классы**, что и paper trading (Phase 9) — `EntrySignalEngine`,
`PositionSizer`, `PaperTradingEngine`. Никакой отдельной "упрощённой" копии
логики стратегии для бэктеста — риск того, что бэктест покажет одно, а
paper/live будут делать другое, исключён архитектурно, а не обещанием.

Единственное новое: `groupSnapshotsIntoCycles()` группирует исторические
`MarketSnapshot` по времени в "циклы" (эмуляция того, что видел бы
`OrderbookCollector` в реальном времени), затем каждый цикл прогоняется через
`paperEngine.runCycle()` последовательно, в хронологическом порядке.

**Честное ограничение**: группировка по времени (`BACKTEST_CYCLE_BUCKET_MS`)
— приближение, потому что в схеме БД нет явного `cycle_id`. Для точной
реконструкции реальных циклов сканера это стоит добавить отдельной миграцией
в будущем.

`npm run backtest` явно откажется работать на пустых данных (**не выдумывает
результат**) — сначала нужен `npm run collect`, накопивший snapshot'ы.

**Grid search** (раздел 36 ТЗ) перебирает `ENTRY_MIN` × `EXIT_TARGET`,
каждый прогон опционально пишется в таблицу `backtest_runs` (если задан
`DATABASE_URL`) — результаты не теряются между запусками.

**Overfitting guard** (раздел 37 ТЗ): если выборка покрывает меньше
`BACKTEST_MIN_DISTINCT_DAYS` уникальных дней, результат сопровождается явным
предупреждением не использовать эти параметры как финальные без
out-of-sample проверки.

**Проверено тестами, и на этом шаге найдены и исправлены два реальных бага**:
1. `computeMaxDrawdown` считал `%` от **финального** пика кривой эквити, а не
   от пика **на момент конкретной просадки** — тест с последовательностью
   `[1000, 1100, 1200, 1150, 1050, 1100, 1300]` показал 11.54% вместо
   правильных 12.50% (просадка 150 от пика 1200, а не от 1300, который
   случился позже). Исправлено — процент теперь считается на каждом шаге
   отдельно. Дополнительно проверено на последовательности с двумя разными
   просадками (одна больше в $, другая в %) — обе метрики корректно берут
   свой максимум независимо.
2. Сквозной тест (4 синтетических цикла: entry NO@0.97 partial fill 60/103 →
   exit двумя частями 20+40 @0.99) дал **тот же результат, что и прямой
   paper trading тест Phase 9** ($1.20 gross/net profit) — подтверждает,
   что backtest и paper trading не разошлись в арифметике.

`npm run typecheck` — чисто.

## Phase 12: Observe mode

```bash
# .env: BOT_MODE=observe (обязательно)
npm run observe
```

Раздел 24 ТЗ: сканирует, считает сигналы (Phase 7) и recommended quantity
(Phase 8), показывает **все** сигналы (не только BUY-кандидатов) с полями
ровно по ТЗ: market, token, side, best bid, best ask, spread, liquidity,
score, expected profit, recommended quantity, reason. Ничего не покупает и
не продаёт.

**Отличие от `npm run signals` (Phase 7-8 превью)**: `observe` пытается
использовать **реальный** баланс и **реальные** открытые позиции аккаунта
(те же read-only вызовы, что `npm run account`, Phase 3) — если заданы
credentials, duplicate-position проверка (раздел 16 ТЗ) идёт по настоящим
позициям с Data API, а не предполагает "открытых позиций нет". Без
credentials честно откатывается на `ASSUMED_CAPITAL_USD` с явным
предупреждением в выводе.

**Найден и исправлен баг при подготовке этого шага** (юнит-тестом, до того
как он попал бы в вывод): отображение `best bid` для сигнала брало сторону
**YES** независимо от того, идёт ли речь о YES или NO сигнале — то есть NO-
сигнал показывал бы совершенно нерелевантную цену. Исправлено: bid/ask
теперь берутся именно со стороны (`market.yes` или `market.no`), которой
принадлежит конкретный сигнал. Проверено тестом: NO-сигнал с YES bid=0.02 и
NO bid=0.96 теперь корректно показывает 0.96, а не 0.02.

`npm run typecheck` — чисто.

## RiskManager (раздел 31) + Kill Switch (раздел 32)

Реализовано между Phase 12 и Phase 13 — по вашему запросу, потому что раздел
41 ТЗ прямо требует работающий risk manager и kill switch **до** live.

```bash
npm run kill "почему выключаю"   # немедленно останавливает НОВЫЕ входы
npm run resume                     # снова разрешает торговлю
```

**`RiskManager`** (`src/lib/riskManager.ts`) — все 12 проверок раздела 31 (available
balance, total exposure, market exposure, число открытых позиций, daily PnL,
drawdown, liquidity, expected net profit, slippage, orderbook freshness, time
to resolution, duplicate position) плюс 13-я — kill switch/`ENABLE_TRADING`
(раздел 32). Вызывается в `npm run paper` **после** `PositionSizer` (когда уже
известен предполагаемый notional) и **до** фактического исполнения — ровно
как требует раздел 17 ТЗ (`проверить risk limits` как отдельный шаг).

Важно: caps внутри `PositionSizer` (Phase 8) никуда не делись — это defense
in depth. `RiskManager` добавляет то, чего в `PositionSizer` в принципе нет:
daily PnL, drawdown (на основе `equityPeakUsd`, high-water mark, персистится
в `PaperState`), число открытых позиций, kill switch.

**`TradingControlStore`** (`src/lib/tradingControlStore.ts`) — файловый флаг
"торговля разрешена", **переживающий перезапуск процесса** — то есть `npm run
kill` сейчас реально остановит следующий вызов `npm run paper` через минуту,
а не только в рамках текущего запуска.

**Честное ограничение**: "cancel open orders" из раздела 32 в буквальном
смысле (отмена реальных ордеров на бирже) пока не применимо — реального
исполнения ордеров ещё нет (это Phase 13). Когда она появится, execution-
модуль обязан проверять тот же `TradingControlStore` перед каждой отправкой
ордера — архитектурно это уже заложено, не отложено на потом. Открытые
PAPER-позиции kill switch не закрывает принудительно (осознанное решение:
паническая ликвидация добавляет риск, а не убирает) — только показывает их
и останавливает НОВЫЙ риск; exit-логика по существующим позициям продолжает
работать даже при выключенной торговле.

**Проверено юнит-тестами**: все 13 причин блокировки (12 из раздела 31 +
kill switch) сработали изолированно на синтетических кейсах; множественная
блокировка одновременно (kill switch + лимит позиций + дубль) вернула все
три причины сразу, а не только первую найденную; `TradingControlStore`
подтверждённо переживает создание нового экземпляра (эмуляция перезапуска
процесса) — записанное состояние `disabled` корректно читается обратно.

`npm run typecheck` — чисто.

## Phase 13: Live Execution

```bash
# .env: BOT_MODE=live, LIVE_CONFIRM=true, все credentials заданы
npm run live
```

**Использует официальный `@polymarket/client` SDK (v0.10.0)**, а не ручную
EIP-712 подпись — раздел 19 ТЗ прямо требует "не придумывать API", а
актуальная V2-схема подписи ордера для Deposit Wallet дополнительно требует
ERC-7739 wrapping поверх обычного EIP-712 (см. `docs.polymarket.com/trading/
orders/create` — 11 подписываемых полей: salt/maker/signer/tokenId/
makerAmount/takerAmount/side/signatureType/timestamp/metadata/builder,
domain version "2"). Ручная реализация — существенный риск ошибки в подписи
для операции с реальными деньгами; официальный SDK поддерживается той же
командой, что и API.

**Активация — раздел 22 ТЗ буквально**:
1. Требует `BOT_MODE=live` **и** `LIVE_CONFIRM=true` одновременно.
2. Печатает предупреждающий баннер.
3. Требует интерактивный ввод ровно `LIVE` (case-sensitive) — любой другой
   ввод останавливает выполнение **до первого сетевого запроса**.
4. Kill switch и `ENABLE_TRADING` проверяются сразу после подтверждения —
   раньше, чем создаётся live client или запрашивается баланс.

**Исполнение (разделы 17-19 ТЗ)**:
- **Entry**: FAK (Fill and Kill) market-ордер, не GTC limit. Это делает
  "отменить stale order" (раздел 17) атомарным на стороне биржи — FAK сам
  исполняет то, что доступно по цене не хуже `maxPrice` и отменяет остаток,
  без гонки состояний между нашим процессом и биржей. `maxPrice = entryPrice
  × (1 + MAX_ENTRY_SLIPPAGE_PCT)` защищает от исполнения по существенно
  худшей цене.
- **Exit**: GTC limit @ `EXIT_TARGET` — дословно по разделу 19
  ("для exit: limit order @ 0.99"). Может исполняться частями по мере
  появления встречной ликвидности — воспроизводит наблюдаемый паттерн
  (Munich: 1 buy, 5 sell fills). Перед каждым циклом проверяется, нет ли уже
  висящего exit-ордера на токен — не дублируется.
- **Reconciliation**: реальные fills резидентного exit-ордера приходят
  асинхронно (могут исполниться не в момент запуска нашего процесса).
  Перед каждым циклом сверяем реальный размер позиции через Data API
  (источник истины) с тем, что помним сами; если он уменьшился — забираем
  настоящие matched trades через `listAccountTrades` и строим trade record
  (раздел 26 ТЗ) по реальным данным, а не оценочно.

**RiskManager и kill switch не ослаблены для live** — `npm run live`
использует ровно ту же последовательность проверок (`RiskManager.checkBuy`,
`TradingControlStore`), что и `npm run paper` (Phase 9), с реальным балансом
аккаунта вместо paper cash.

**Проверено вручную (без реальной сети — она недоступна в этой песочнице,
но последовательность проверок протестирована полностью)**:
- `BOT_MODE=observe` (дефолт) → останавливается до баннера, без единого
  запроса — ✅.
- `BOT_MODE=live, LIVE_CONFIRM=true`, неверное подтверждение ("yes" вместо
  "LIVE") → останавливается сразу после баннера — ✅.
- Точное подтверждение "LIVE", но без приватного ключа → останавливается
  до создания любого клиента — ✅.
- С валидным по формату ключом, но без L2 credentials → останавливается до
  создания live client — ✅ (после рефакторинга порядка проверок).
- **Kill switch, активированный через `npm run kill`, останавливает `npm run
  live` сразу после подтверждения "LIVE", до создания live client и запроса
  баланса** — протестировано и подтверждено: `🛑 Kill switch активен... 
  Останавливаюсь.`
- Реальный сетевой вызов (`createSecureClient` → relayer-v2.polymarket.com)
  подтверждённо происходит и упирается в сетевые ограничения песочницы (не в
  ошибку кода) — это ожидаемо и корректно свидетельствует, что до этой точки
  вся логика (gating, credentials, баланс) отработала правильно.

**Честное ограничение**: этот код ни разу не исполнял реальный ордер на
реальном рынке — сеть в этой песочнице этого не позволяет. Вся
последовательность проверок и конструирование запросов протестированы
максимально возможным образом без прямого сетевого доступа к
`clob.polymarket.com`. Первый реальный прогон — на вашей стороне,
настоятельно рекомендуется начать с минимального `FIXED_POSITION_USD`
(несколько долларов) и внимательно следить за первым циклом.

`npm run typecheck` — чисто.

## Проверка типов

```bash
npm run typecheck
```

## Что дальше

Согласно исходному плану (Phase 4-13): `MarketScanner`, weather-классификатор,
сбор orderbook/market snapshots в PostgreSQL, `EntrySignalEngine`,
`PositionSizer` (с моделями из `docs/strategy-reverse-engineering.md`),
paper trading, backtest, `RiskManager`, observe mode, dashboard, Telegram,
и только в самом конце — live. Каждая фаза — отдельная точка проверки
(тесты, typecheck, lint, ручная инспекция логов) перед переходом к следующей.
