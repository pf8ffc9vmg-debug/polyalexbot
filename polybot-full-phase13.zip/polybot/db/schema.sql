-- Phase 10: полная схема из раздела 27 ТЗ.
-- Идемпотентно: безопасно запускать повторно (npm run db:migrate).

CREATE TABLE IF NOT EXISTS markets (
    market_id           TEXT PRIMARY KEY,
    condition_id         TEXT NOT NULL,
    question              TEXT NOT NULL,
    slug                   TEXT,
    kind                   TEXT, -- WeatherMarketKind | null
    city                   TEXT,
    end_date               TIMESTAMPTZ,
    active                  BOOLEAN,
    closed                  BOOLEAN,
    yes_token_id            TEXT,
    no_token_id             TEXT,
    first_seen_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Раздел 28 ТЗ: снимки рынка (агрегированный уровень — YES+NO пара).
CREATE TABLE IF NOT EXISTS market_snapshots (
    id                     BIGSERIAL PRIMARY KEY,
    ts                      TIMESTAMPTZ NOT NULL,
    market_id               TEXT NOT NULL REFERENCES markets(market_id),
    token_id                 TEXT NOT NULL,
    outcome                  TEXT NOT NULL CHECK (outcome IN ('YES', 'NO')),
    best_bid                 NUMERIC,
    best_ask                 NUMERIC,
    midpoint                 NUMERIC,
    spread                   NUMERIC,
    available_bid_size       NUMERIC,
    available_ask_size       NUMERIC,
    volume                   NUMERIC,
    time_to_resolution_ms    BIGINT,
    book_age_ms              INTEGER,
    stale                    BOOLEAN NOT NULL DEFAULT false
);
CREATE INDEX IF NOT EXISTS idx_market_snapshots_token_ts ON market_snapshots(token_id, ts);

-- Сырые уровни стакана (опционально, глубже одного best bid/ask), на будущее.
CREATE TABLE IF NOT EXISTS orderbook_snapshots (
    id           BIGSERIAL PRIMARY KEY,
    ts            TIMESTAMPTZ NOT NULL,
    token_id       TEXT NOT NULL,
    side            TEXT NOT NULL CHECK (side IN ('BID', 'ASK')),
    price           NUMERIC NOT NULL,
    size            NUMERIC NOT NULL,
    level_index     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orderbook_snapshots_token_ts ON orderbook_snapshots(token_id, ts);

-- Раздел 9 ТЗ: EntrySignalEngine выход.
CREATE TABLE IF NOT EXISTS signals (
    id                       BIGSERIAL PRIMARY KEY,
    ts                        TIMESTAMPTZ NOT NULL DEFAULT now(),
    market_id                  TEXT NOT NULL REFERENCES markets(market_id),
    token_id                    TEXT NOT NULL,
    outcome                     TEXT NOT NULL CHECK (outcome IN ('YES', 'NO')),
    entry_price                  NUMERIC,
    target_price                 NUMERIC NOT NULL,
    spread                       NUMERIC,
    available_liquidity           NUMERIC,
    expected_net_profit_pct       NUMERIC,
    time_to_resolution_ms         BIGINT,
    market_score                  NUMERIC,
    confidence_score               NUMERIC,
    risk_score                     NUMERIC,
    signal_score                   NUMERIC,
    decision                       TEXT NOT NULL CHECK (decision IN ('BUY_CANDIDATE', 'NO_TRADE')),
    reasons                         TEXT[] NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts);

-- Разделы 17/19 ТЗ: реальные ордера. Пусто, пока нет execution (Phase 13+).
CREATE TABLE IF NOT EXISTS orders (
    order_id        TEXT PRIMARY KEY,
    market_id        TEXT NOT NULL REFERENCES markets(market_id),
    token_id          TEXT NOT NULL,
    side               TEXT NOT NULL CHECK (side IN ('BUY', 'SELL')),
    order_type          TEXT NOT NULL DEFAULT 'LIMIT',
    requested_price      NUMERIC NOT NULL,
    requested_qty         NUMERIC NOT NULL,
    status                TEXT NOT NULL, -- OPEN | FILLED | PARTIALLY_FILLED | CANCELLED
    is_paper               BOOLEAN NOT NULL DEFAULT true,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Раздел 18 ТЗ: partial fills.
CREATE TABLE IF NOT EXISTS fills (
    id              BIGSERIAL PRIMARY KEY,
    order_id          TEXT REFERENCES orders(order_id),
    market_id          TEXT NOT NULL REFERENCES markets(market_id),
    token_id            TEXT NOT NULL,
    side                 TEXT NOT NULL CHECK (side IN ('BUY', 'SELL')),
    quoted_price          NUMERIC NOT NULL,
    filled_price           NUMERIC NOT NULL,
    qty                     NUMERIC NOT NULL,
    notional                 NUMERIC NOT NULL,
    fee                       NUMERIC NOT NULL DEFAULT 0,
    is_paper                  BOOLEAN NOT NULL DEFAULT true,
    ts                         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_fills_market_token ON fills(market_id, token_id);

-- Текущие открытые позиции (paper и, в будущем, live).
CREATE TABLE IF NOT EXISTS positions (
    id                    BIGSERIAL PRIMARY KEY,
    market_id              TEXT NOT NULL REFERENCES markets(market_id),
    token_id                TEXT NOT NULL,
    outcome                  TEXT NOT NULL CHECK (outcome IN ('YES', 'NO')),
    status                    TEXT NOT NULL CHECK (status IN ('OPEN', 'CLOSED')),
    filled_qty                 NUMERIC NOT NULL DEFAULT 0,
    exited_qty                  NUMERIC NOT NULL DEFAULT 0,
    avg_entry_price               NUMERIC NOT NULL,
    total_entry_notional          NUMERIC NOT NULL,
    total_entry_fee                NUMERIC NOT NULL DEFAULT 0,
    is_paper                        BOOLEAN NOT NULL DEFAULT true,
    opened_at                        TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at                         TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_positions_status ON positions(status, is_paper);

-- Раздел 26 ТЗ: TRADE RECORD, закрытые сделки.
CREATE TABLE IF NOT EXISTS trades (
    trade_id               UUID PRIMARY KEY,
    market_id                TEXT NOT NULL REFERENCES markets(market_id),
    condition_id               TEXT,
    token_id                    TEXT NOT NULL,
    outcome                      TEXT NOT NULL CHECK (outcome IN ('YES', 'NO')),
    entry_price                   NUMERIC NOT NULL,
    exit_price                     NUMERIC NOT NULL,
    requested_quantity               NUMERIC NOT NULL,
    filled_quantity                   NUMERIC NOT NULL,
    entry_time                         TIMESTAMPTZ NOT NULL,
    exit_time                           TIMESTAMPTZ NOT NULL,
    entry_notional                       NUMERIC NOT NULL,
    exit_notional                         NUMERIC NOT NULL,
    fees                                   NUMERIC NOT NULL DEFAULT 0,
    slippage                                NUMERIC NOT NULL DEFAULT 0,
    gross_profit                             NUMERIC NOT NULL,
    net_profit                                NUMERIC NOT NULL,
    signal_score                               NUMERIC,
    risk_score                                  NUMERIC,
    time_to_resolution_ms                        BIGINT,
    liquidity                                     NUMERIC,
    reason_for_entry                               TEXT,
    reason_for_exit                                 TEXT,
    is_paper                                         BOOLEAN NOT NULL DEFAULT true
);
CREATE INDEX IF NOT EXISTS idx_trades_exit_time ON trades(exit_time);

-- Раздел 35 ТЗ: дневная агрегация PnL.
CREATE TABLE IF NOT EXISTS pnl (
    day                DATE PRIMARY KEY,
    trades_count         INTEGER NOT NULL DEFAULT 0,
    wins                   INTEGER NOT NULL DEFAULT 0,
    losses                  INTEGER NOT NULL DEFAULT 0,
    gross_pnl                 NUMERIC NOT NULL DEFAULT 0,
    fees                        NUMERIC NOT NULL DEFAULT 0,
    net_pnl                      NUMERIC NOT NULL DEFAULT 0,
    win_rate                      NUMERIC,
    avg_trade                      NUMERIC,
    max_drawdown                    NUMERIC,
    is_paper                         BOOLEAN NOT NULL DEFAULT true
);

-- Раздел 31-32 ТЗ: события риск-менеджера (блокировки, stop loss, kill switch).
CREATE TABLE IF NOT EXISTS risk_events (
    id           BIGSERIAL PRIMARY KEY,
    ts            TIMESTAMPTZ NOT NULL DEFAULT now(),
    event_type     TEXT NOT NULL, -- RISK_BLOCK | STOP_LOSS | DAILY_LOSS_LIMIT | KILL_SWITCH | ...
    market_id       TEXT REFERENCES markets(market_id),
    details           JSONB
);

-- Общие события бота (старт/стоп/ошибки/дисконнекты) — раздел 34 ТЗ.
CREATE TABLE IF NOT EXISTS bot_events (
    id         BIGSERIAL PRIMARY KEY,
    ts          TIMESTAMPTZ NOT NULL DEFAULT now(),
    event_type   TEXT NOT NULL, -- BOT_START | BOT_STOP | ERROR | API_DISCONNECTED | ...
    details       JSONB
);

-- Раздел 30 ТЗ: параметры стратегии как данные, а не только .env — чтобы
-- backtest мог логировать, с какими параметрами шёл конкретный прогон
-- (см. backtest_runs), и чтобы дашборд (Phase будущая) мог их читать/менять
-- без передеплоя. .env остаётся источником правды для живого запуска —
-- эта таблица используется явно, когда параметры сохраняются намеренно
-- (например, после backtest), не читается автоматически при каждом старте.
CREATE TABLE IF NOT EXISTS strategy_parameters (
    key           TEXT PRIMARY KEY,
    value           TEXT NOT NULL,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by        TEXT
);

-- Раздел 36 ТЗ: результаты backtest-прогонов.
CREATE TABLE IF NOT EXISTS backtest_runs (
    run_id             UUID PRIMARY KEY,
    started_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at           TIMESTAMPTZ,
    params_json            JSONB NOT NULL, -- снимок всех параметров стратегии для этого прогона
    trades_count             INTEGER,
    win_rate                  NUMERIC,
    total_pnl                  NUMERIC,
    max_drawdown                 NUMERIC,
    notes                          TEXT
);
