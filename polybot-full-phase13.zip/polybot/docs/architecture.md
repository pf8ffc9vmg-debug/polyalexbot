# Архитектура (Phase 1-3: read-only фундамент)

## Три HTTP-сервиса Polymarket + on-chain слой

| Сервис | Base URL | Авторизация | Что используем сейчас |
|---|---|---|---|
| Gamma API | `https://gamma-api.polymarket.com` | не требуется | `GET /markets` — discovery рынков, метаданные, `clobTokenIds` |
| CLOB API | `https://clob.polymarket.com` | публичные reads — нет; приватные — L1 (разово) + L2 (HMAC на каждый запрос) | `GET /price`, `GET /midpoint`, `GET /book` (публично); `POST /auth/api-key`, `GET /auth/derive-api-key` (L1); `GET /balance-allowance`, `GET /data/orders` (L2) |
| Data API | `https://data-api.polymarket.com` | не требуется (данные по адресу публичны) | `GET /positions?user=`, `GET /trades?user=` |
| Polygon RPC | внешний RPC-провайдер | нет (чтение он-чейн) | **не подключено на этом этапе** — понадобится в Phase 6+ для проверки on-chain balance/allowance как источника истины и для redeemPositions после резолюции |

`POST /order` (создание ордеров) **сознательно не реализован в этой фазе** —
по ТЗ (раздел 42/FIRST TASK) первая фаза read-only.

## Аутентификация — как это реально работает (CLOB V2)

1. **L1**: приватный ключ подписывает EIP-712 `ClobAuth` typed message
   (domain `ClobAuthDomain`, chainId 137). Signature + address + timestamp +
   nonce отправляются на `POST /auth/api-key` (создать) или
   `GET /auth/derive-api-key` (получить существующие). В ответ приходят
   `apiKey` / `secret` / `passphrase` — это делается **один раз**, дальше
   креды сохраняются в `.env` и переиспользуются.
2. **L2**: на каждый приватный запрос собираются 5 заголовков
   (`POLY_ADDRESS`, `POLY_SIGNATURE`, `POLY_TIMESTAMP`, `POLY_API_KEY`,
   `POLY_PASSPHRASE`). Подпись — `HMAC-SHA256(base64decode(secret), timestamp + METHOD + path + body)`,
   результат — urlsafe base64.

Реализовано в `src/lib/clobAuth.ts` дословно по
`https://docs.polymarket.com/getting-started/api`.

## Важные детали 2026 года (учтены)

- **CLOB V2** — единственная поддерживаемая версия production (V2 введён
  28 апреля 2026, легаси `py-clob-client`/`clob-client` архивированы 25 мая
  2026 в пользу `-v2` пакетов). Мы ориентируемся на актуальные REST-эндпоинты,
  а не на архивные SDK.
- **signature_type**: 0 = EOA/MetaMask/hardware, 1 = email/Magic login,
  2 = браузерный прокси-кошелёк. Для EOA `funder address` обычно = адресу
  подписывающего ключа; для 1 и 2 — это отдельный proxy-адрес, который нужно
  явно взять из интерфейса Polymarket, не вычислять/угадывать.
- **Гео-ограничения**: Polymarket блокирует размещение ордеров по IP в ряде
  юрисдикций (полный блок или close-only), проверяется через
  `GET https://polymarket.com/api/geoblock` (домен `polymarket.com`, НЕ API-хосты).
  Публичные read-запросы (Gamma/CLOB reads/Data API) это ограничение обычно не
  затрагивает — только размещение и (в close-only режиме) частично закрытие
  ордеров. **Перед включением paper/live режима обязательно прогнать
  `npm run geocheck` с того же сервера/сети, откуда бот будет торговать.**
  Список ограничений периодически меняется — не полагайтесь на список стран
  из этого документа, смотрите официальный geoblock-эндпоинт и
  `docs.polymarket.com/api-reference/geoblock` на момент запуска.

## Структура проекта на этом этапе

```
polybot/
├── .env.example
├── package.json
├── tsconfig.json
├── docs/
│   ├── architecture.md
│   └── strategy-reverse-engineering.md
└── src/
    ├── config/
    │   └── env.ts          # загрузка/валидация .env через zod, без хардкода секретов
    ├── lib/
    │   ├── clobAuth.ts      # L1/L2 подпись запросов
    │   ├── clobClient.ts    # CLOB: price/midpoint/book (public) + balance/orders (L2)
    │   ├── gammaClient.ts   # Gamma: discovery рынков
    │   └── dataApiClient.ts # Data API: positions/trades по адресу
    └── commands/
        ├── account.ts       # npm run account — диагностика, БЕЗ создания ордеров
        └── geocheck.ts       # npm run geocheck — проверка гео-ограничений
```

## Что дальше (Phase 4+, не реализовано в этой фазе)

`MarketScanner`, weather-классификатор, `EntrySignalEngine`, `RiskManager`,
paper/observe движки, PostgreSQL-схема, backtest, dashboard, Telegram —
всё это по плану (разделы 6-36 исходного ТЗ), но сознательно не начато,
пока не пройдена явная точка синхронизации после account diagnostic
(см. раздел 42 ТЗ: "После успешного account diagnostic остановись").
